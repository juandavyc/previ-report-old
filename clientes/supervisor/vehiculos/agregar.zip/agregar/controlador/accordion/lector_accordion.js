const botones_tabla_certificado = {
  botones: [
    {
      id: 'btn_info',
      icon: 'fas fa-info-circle',
    },
    {
      id: 'btn_delete',
      icon: 'fas fa-times',
    },
  ],
};

export function accordion_lector_datos(_response, _id_accordion) {
  //////////////////////////////////
  //// INFORMACION DEL VEHICULO
  // //////////////////////////////////
  // $global_placa = _response[0].placa_vehiculo;

  if (_id_accordion == 1) {
    // informacion basica del vehiculo
    $('#form_0_placa').html(_response[0].placa_vehiculo);
    $('#form_1_placa').html(_response[0].placa_vehiculo);

    $('#form_1_fecha_matricula').val(
      formatdateui(_response[0].fecha_matricula_vehiculo)
    );
    $('#form_1_licencia_transito').val(_response[0].numero_licencia_vehiculo);

    // Dispara el evento change
    $('#form_1_tipo_vehiculo').val(_response[0].id_tipo_vehiculo).change();

    $('#form_1_servicio_vehiculo').val(_response[0].id_servicio);

    $('#form_1_clase_vehiculo_input').val(_response[0].nombre_clase);
    $('#form_1_clase_vehiculo_select').val(_response[0].id_clase);
    // informacion detallada del vehiculo
    $('#form_1_marca_vehiculo_input').val(_response[0].nombre_marca);
    $('#form_1_marca_vehiculo_select').val(_response[0].id_marca);
    $('#form_1_linea_vehiculo_input').val(_response[0].nombre_linea);
    $('#form_1_linea_vehiculo_select').val(_response[0].id_linea);

      console.log(_response[0].id_marca);
      console.log(_response[0].id_linea);


    $('#form_1_modelo_vehiculo').val(_response[0].modelo_vehiculo);
    $('#form_1_color_vehiculo_input').val(_response[0].nombre_color);
    $('#form_1_color_vehiculo_select').val(_response[0].id_color);
    $('#form_1_serie_vehiculo').val(_response[0].numero_serie_vehiculo);
    $('#form_1_motor_vehiculo').val(_response[0].numero_motor_vehiculo);
    $('#form_1_vin_vehiculo').val(_response[0].vin_vehiculo);
    $('#form_1_cilindraje_vehiculo').val(_response[0].cilindraje_vehiculo);
    $('#form_1_potencia_vehiculo').val(_response[0].potencia_vehiculo);
    $('#form_1_kilometraje_vehiculo').val(_response[0].kilometraje_vehiculo);

    $('#form_1_carroceria_vehiculo_input').val(
      _response[0].nombre_tipo_carroceria
    );
    $('#form_1_carroceria_vehiculo_select').val(
      _response[0].id_tipo_carroceria
    );

    $('#form_1_pasajeros_vehiculo').val(_response[0].pasajeros_vehiculo);

    if (_response[0].id_catalizador == '1') {
      $('#form_1_catalizador_vehiculo_no').prop('checked', true);
    } else {
      $('#form_1_catalizador_vehiculo_si').prop('checked', true);
    }

    // tiempos del motor
    if (_response[0].id_tiempos_motor == '1') {
      $('#form_1_tiempos_motor_vehiculo_4t').prop('checked', true);
    } else {
      $('#form_1_tiempos_motor_vehiculo_2t').prop('checked', true);
    }
    // desenio
    if (_response[0].id_disenio == '1') {
      $('#form_1_disenio_vehiculo_convencional').prop('checked', true);
    } else {
      $('#form_1_disenio_vehiculo_scooter').prop('checked', true);
    }
    if (_response[0].blindado_vehiculo == '1') {
      $('#form_1_blindado_vehiculo_no').prop('checked', true);
    } else {
      $('#form_1_blindado_vehiculo_si').prop('checked', true);
    }

    if (_response[0].polarizado_vehiculo == '1') {
      $('#form_1_polarizado_vehiculo_no').prop('checked', true);
    } else {
      $('#form_1_polarizado_vehiculo_si').prop('checked', true);
    }

    $('#form_1_exostos_vehiculo').val(_response[0].numero_exostos_vehiculo);
    $('#form_1_ejes_vehiculo').val(_response[0].numero_ejes_vehiculo);

    $('#form_1_combustible_vehiculo').val(_response[0].id_combustible);

    if (_response[0].id_tipo_caja == '1') {
      $('#form_1_tipo_caja_vehiculo_manual').prop('checked', true);
    } else if (_response[0].id_tipo_caja == '2') {
      $('#form_1_tipo_caja_vehiculo_automatico').prop('checked', true);
    } else {
      $('#form_1_tipo_caja_vehiculo_semiautomatico').prop('checked', true);
    }

    $('#form_1_numero_puertas').val(_response[0].numero_puertas);
    // nacionalidad y pais
    $('#form_1_nacionalidad_vehiculo').val(_response[0].id_nacionalidad);
    $('#form_1_pais_vehiculo_input').val(_response[0].nombre_pais);
    $('#form_1_pais_vehiculo_select').val(_response[0].id_pais);

    // pintar la placa
    $('#form_0_placa')
      .removeClass()
      .addClass(vh_placa_css(_response[0].id_servicio));
  }
  //////////////////////////////////
  //// Certificado RTM
  //////////////////////////////////
  else if (_id_accordion == 2) {
    const table_thead = [
      'id',
      'Certificado',
      'Expedicion',
      'Vencimiento',
      'CDA',
      'Opciones',
    ];

    $('#form_2_certificado_rtm_resultados').html(
      '<table class="alt">' +
        '<thead>' +
        getTheadTable(table_thead, 'id', 'desc') +
        '</thead>' +
        '<tbody>' +
        getTbodyTable(_response, botones_tabla_certificado) +
        '</tbody></table>'
    );
  } else if (_id_accordion == 3) {
    const table_thead = [
      'id',
      'Certificado',
      'Expedicion',
      'Vencimiento',
      'CDA',
      'Opciones',
    ];

    $('#form_3_poliza_soat_resultados').html(
      '<table class="alt">' +
        '<thead>' +
        getTheadTable(table_thead, 'id', 'desc') +
        '</thead>' +
        '<tbody>' +
        getTbodyTable(_response, botones_tabla_certificado) +
        '</tbody></table>'
    );
  }
}
