import './autocomplete.js';
import { fun_accordion_busqueda } from './accordion.js';
import { fun_informacion_vehiculo_rtm_accordion } from './form_informacion_del_vehiculo.js';
import { fun_certificado_rtm_accordion } from './form_certificado_rtm.js';
import { fun_poliza_soat_accordion } from './form_poliza_soat.js';

let return_camera = fun_camera_photo(
  'https://192.168.1.50/modulos/vehiculos/agregar/index.php?id=' +
    $('meta[name="csrf-id"]').attr('content'),
  $('meta[name="csrf-id"]').attr('content'),
  0
);

if (return_camera == true) {
  // fun_accordion_busqueda(1, false);
  fun_informacion_vehiculo_rtm_accordion(fun_accordion_busqueda);
  fun_certificado_rtm_accordion(fun_accordion_busqueda);
  fun_poliza_soat_accordion(fun_accordion_busqueda);
}

// Acordion para cmodulos

/*
import * as infomarcion_vehiculo_js from './form_informacion_del_vehiculo.js'; 
import * as certificado_rtm_js from './form_certificado_rtm.js';


var xx = new infomarcion_vehiculo_js();*/

// informacion del vehiculo

// import './save_basic_information_form.js';

/*
//elementos de inicio, get form data
default_start();
//codigos de autocomplete
autocomplete();
// save form
save_basic_information_form();*/
