const json_autocomplete_clase = {
  id_input_text: 'form_1_clase_vehiculo_input',
  id_input_select: 'form_1_clase_vehiculo_select',
  url_select_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/clase_vehiculo/buscar_clase.php',
  url_insert_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/clase_vehiculo/crear_clase.php',
  input_value_default: 'SIN_CLASE',
  input_select_default: '1',
  input_childs: [],
};

autocomplete_with_insert_father(json_autocomplete_clase);

const json_autocomplete_marca = {
  id_input_text: 'form_1_marca_vehiculo_input',
  id_input_select: 'form_1_marca_vehiculo_select',
  url_select_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/marca_vehiculo/buscar_marca.php',
  url_insert_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/marca_vehiculo/crear_marca.php',
  input_value_default: 'SIN_MARCA',
  input_select_default: '0',
  input_childs: [
    {
      id_input_text: 'form_1_linea_vehiculo_input',
      id_input_select: 'form_1_linea_vehiculo_select',
      input_value_default: 'SIN_LINEA',
      input_select_default: '0',
    },
  ],
};

autocomplete_with_insert_father(json_autocomplete_marca);

const json_autocomplete_datos_linea = {
  id_input_text: 'form_1_linea_vehiculo_input',
  id_input_select: 'form_1_linea_vehiculo_select',
  url_select_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/linea_vehiculo/buscar_linea.php',
  url_insert_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/linea_vehiculo/crear_linea.php',
  input_value_default: 'SIN_LINEA',
  input_select_default: '0',
  input_father_name: 'MARCA ',
  input_father_text: 'form_1_marca_vehiculo_input',
  input_father_select: 'form_1_marca_vehiculo_select',
};

autocomplete_with_insert_child(json_autocomplete_datos_linea);

const json_autocomplete_color = {
  id_input_text: 'form_1_color_vehiculo_input',
  id_input_select: 'form_1_color_vehiculo_select',
  url_select_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/color_general/buscar_color.php',
  url_insert_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/color_general/crear_color.php',
  input_value_default: 'SIN_COLOR',
  input_select_default: '1',
  input_childs: [],
};

autocomplete_with_insert_father(json_autocomplete_color);

const json_autocomplete_carroceria = {
  id_input_text: 'form_1_carroceria_vehiculo_input',
  id_input_select: 'form_1_carroceria_vehiculo_select',
  url_select_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/carroceria_vehiculo/buscar_carroceria.php',
  url_insert_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/carroceria_vehiculo/crear_carroceria.php',
  input_value_default: 'SIN_CARROCERIA',
  input_select_default: '1',
  input_childs: [],
};

autocomplete_with_insert_father(json_autocomplete_carroceria);

const json_autocomplete_pais = {
  id_input_text: 'form_1_pais_vehiculo_input',
  id_input_select: 'form_1_pais_vehiculo_select',
  url_select_ajax:
    PROTOCOL_HOST + '/modulos/assets/autocomplete/pais_general/buscar_pais.php',
  url_insert_ajax:
    PROTOCOL_HOST + '/modulos/assets/autocomplete/pais_general/crear_pais.php',
  input_value_default: 'COLOMBIA',
  input_select_default: '90',
  input_childs: [],
};

autocomplete_with_insert_father(json_autocomplete_pais);

const json_autocomplete_cda = {
  id_input_text: 'form_2_nombre_cda_input',
  id_input_select: 'form_2_nombre_cda_select',
  url_select_ajax:
    PROTOCOL_HOST + '/modulos/assets/autocomplete/cda_general/buscar_cda.php',
  url_insert_ajax:
    PROTOCOL_HOST + '/modulos/assets/autocomplete/cda_general/crear_cda.php',
  input_value_default: 'SIN_CDA',
  input_select_default: '1',
  input_childs: [],
};

autocomplete_with_insert_father(json_autocomplete_cda);

const json_autocomplete_aseguradora = {
  id_input_text: 'form_3_aseguradora_soat_input',
  id_input_select: 'form_3_aseguradora_soat_select',
  url_select_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/aseguradora_soat_general/buscar_aseguradora_soat.php',
  url_insert_ajax:
    PROTOCOL_HOST +
    '/modulos/assets/autocomplete/aseguradora_soat_general/crear_aseguradora_soat.php',
  input_value_default: 'SIN_ASEGURADORA',
  input_select_default: '1',
  input_childs: [],
};

autocomplete_with_insert_father(json_autocomplete_aseguradora);
