<?php session_start();
header('Content-Type: application/json');
require $_SERVER["DOCUMENT_ROOT"] . '/modulos/assets/php/hoja_private_config.php';
$headers = apache_request_headers();
if (
    isset($_POST['id_accordion']) &&
    isset($_POST['id_vehiculo']) &&
    isset($_SESSION["session_user"]) &&
    count($_SESSION["session_user"]) == 5 &&
    count($_POST) == 2
) {

    include DOCUMENT_ROOT . '/modulos/assets/php/hdv_database.php';
    include DOCUMENT_ROOT . '/modulos/assets/php/hdv_resources.php';

    $json_status = "error";
    $json_message = "inicio";
    $json_host = getposturl($headers['Origin']);

    if ($json_host['status'] == "ok") {

        if (
            isset($headers['csrf-token']) &&
            hash_equals($headers['csrf-token'], $_SESSION['csrf_token'])
        ) {

            $database = new dbconnection();
            $database->connect();

            if (strcmp($database->status(), "bien") == 0) {

                $id_vehiculo = htmlspecialchars($_POST['id_vehiculo']);
                $id_accordion = htmlspecialchars($_POST['id_accordion']);

                /* data-id = 1 */
                /* Información del vehículo */

                $mysql_query = "SELECT ";

                if ($id_accordion == 1) {

                    $mysql_query = "SELECT ";
                    $mysql_query .= "veh.placa_vehiculo, ";
                    $mysql_query .= "veh.fecha_matricula_vehiculo, ";
                    $mysql_query .= "veh.numero_licencia_vehiculo, tveh.id_tipo_vehiculo, ";
                    $mysql_query .= "ser.id_servicio, cla.nombre_clase, cla.id_clase, ";
                    $mysql_query .= "lin.nombre_linea,lin.id_linea,  mar.nombre_marca, mar.id_marca, ";
                    $mysql_query .= "veh.modelo_vehiculo, col.nombre_color,col.id_color, ";
                    $mysql_query .= "veh.numero_serie_vehiculo, veh.numero_motor_vehiculo,  ";
                    $mysql_query .= "veh.vin_vehiculo, veh.cilindraje_vehiculo,  ";
                    $mysql_query .= "veh.potencia_vehiculo, veh.kilometraje_vehiculo, ";
                    $mysql_query .= "car.nombre_tipo_carroceria,car.id_tipo_carroceria, veh.pasajeros_vehiculo,  ";
                    $mysql_query .= "veh.id_catalizador, veh.blindado_vehiculo,  ";
                    $mysql_query .= "veh.polarizado_vehiculo, veh.numero_exostos_vehiculo, ";
                    $mysql_query .= "veh.numero_ejes_vehiculo, tcom.id_combustible, ";
                    $mysql_query .= "veh.numero_puertas, tca.id_tipo_caja, ";
                    $mysql_query .= "nac.id_nacionalidad, pai.nombre_pais, pai.id_pais, ";
                    $mysql_query .= "veh.id_tiempos_motor,veh.id_disenio ";
                    $mysql_query .= "FROM vehiculo veh ";
                    $mysql_query .= "LEFT JOIN tipo_vehiculo tveh ON veh.id_tipo_vehiculo = tveh.id_tipo_vehiculo ";
                    $mysql_query .= "LEFT JOIN servicio ser ON veh.id_servicio = ser.id_servicio ";
                    $mysql_query .= "LEFT JOIN clase cla ON cla.id_clase = veh.id_clase ";
                    $mysql_query .= "LEFT JOIN linea lin ON lin.id_linea = veh.id_linea ";
                    $mysql_query .= "LEFT JOIN marca mar ON mar.id_marca = lin.id_marca ";
                    $mysql_query .= "LEFT JOIN color col ON col.id_color = veh.id_color ";
                    $mysql_query .= "LEFT JOIN tipo_carroceria car ON car.id_tipo_carroceria = veh.id_tipo_carroceria  ";
                    $mysql_query .= "LEFT JOIN combustible tcom ON tcom.id_combustible = veh.id_combustible ";
                    $mysql_query .= "LEFT JOIN tipo_caja tca ON tca.id_tipo_caja = veh.id_tipo_caja ";
                    $mysql_query .= "LEFT JOIN nacionalidad nac ON nac.id_nacionalidad = veh.id_nacionalidad ";
                    $mysql_query .= "LEFT JOIN pais pai ON pai.id_pais = veh.id_pais ";

                    $mysql_query .= "WHERE veh.id_vehiculo LIKE ? ;";

                } else if ($id_accordion == 2) {

                    $mysql_query = "SELECT ";
                    $mysql_query .= "cer.id_certificado_rtm As id, ";
                    $mysql_query .= "cer.numero_rtm As certificado, ";
                    $mysql_query .= "cer.fecha_expedicion_rtm As expedicion, ";
                    $mysql_query .= "cer.fecha_vencimiento_rtm As vecimiento, ";
                    $mysql_query .= "cda.nombre_cda As cda, ";
                    $mysql_query .= "cer.id_certificado_rtm As opciones ";
                    $mysql_query .= "FROM certificado_rtm cer ";
                    $mysql_query .= "LEFT JOIN cda ON cer.id_cda = cda.id_cda ";
                    $mysql_query .= "WHERE cer.id_vehiculo = ? ";
                    $mysql_query .= "ORDER BY cer.id_certificado_rtm DESC;";
                    // echo $mysql_query;
                } else if ($id_accordion == 3) {

                    $mysql_query = "SELECT ";
                    $mysql_query .= "soat.id_poliza_soat As id, ";
                    $mysql_query .= "soat.numero_poliza_soat As Poliza, ";
                    $mysql_query .= "soat.fecha_expedicion_soat As expedicion, ";
                    $mysql_query .= "soat.fecha_vencimiento_soat As vecimiento, ";
                    $mysql_query .= "ase.nombre_aseguradora_soat As aseguradora, ";
                    $mysql_query .= "soat.id_poliza_soat As opciones ";
                    $mysql_query .= "FROM poliza_soat soat ";
                    $mysql_query .= "LEFT JOIN aseguradora_soat ase ON soat.id_aseguradora_soat = ase.id_aseguradora_soat ";
                    $mysql_query .= "WHERE soat.id_vehiculo = ? ";
                    $mysql_query .= "ORDER BY soat.id_poliza_soat DESC;";
                    // echo $mysql_query;
                }

                $mysql_stmt = mysqli_prepare($database->myconn, $mysql_query);
                $mysql_stmt->bind_param('s', $id_vehiculo);

                if ($mysql_stmt->execute()) {

                    $mysql_result = $mysql_stmt->get_result();
                    $mysql_rowcount = mysqli_num_rows($mysql_result);
                    // Con resultados
                    if ($mysql_rowcount > 0) {
                        $json_status = "bien";
                        $json_message = (mysqli_fetch_all($mysql_result, MYSQLI_ASSOC));
                    }
                    // Sin resultados
                    else {
                        $json_status = "sin_resultados";
                        $json_message = "Sin resultados";
                    }
                } else {
                    $json_status = "error";
                    $json_message = "Error en la consulta " . htmlspecialchars($mysql_stmt->error);
                }

                $database->close();
            } else {
                $json_status = "error";
                $json_message = "Imposible conectar a la base de datos";
            }
        } else {
            $json_status = "csrf";
            $json_message = htmlspecialchars("Wrong CSRF token.");
        }
    } else {
        $json_status = "error";
        $json_message = htmlspecialchars($json_host['message']);
    }

    $json_array = array(
        'status' => $json_status,
        'message' => $json_message,
    );

    echo json_encode($json_array, JSON_FORCE_OBJECT);
    exit;
} else if (!isset($_SESSION["session_user"])) {
    $datos = array(
        'status' => "session",
        'results' => "La sesión fue cerrada, inicie sesión nuevamente.",
    );
    echo json_encode($datos, JSON_FORCE_OBJECT);
    exit;
} else {
    $json_array = array(
        'status' => "Error",
        'message' => "Formulario incompleto",
    );
    echo json_encode($json_array, JSON_FORCE_OBJECT);
    exit;
}