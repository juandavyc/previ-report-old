<?php session_start();
header('Content-Type: application/json');
require $_SERVER["DOCUMENT_ROOT"] . '/modulos/assets/php/hoja_private_config.php';

$headers = apache_request_headers();
if (
    isset($_POST["form_1_id_vehiculo"]) &&
    isset($_POST["form_1_fecha_matricula"]) &&
    isset($_POST["form_1_licencia_transito"]) &&
    isset($_POST["form_1_tipo_vehiculo"]) &&
    isset($_POST["form_1_servicio_vehiculo"]) &&
    isset($_POST["form_1_clase_vehiculo"]) &&
    isset($_POST["form_1_marca_vehiculo"]) &&
    isset($_POST["form_1_linea_vehiculo"]) &&
    isset($_POST["form_1_modelo_vehiculo"]) &&
    isset($_POST["form_1_color_vehiculo"]) &&
    isset($_POST["form_1_serie_vehiculo"]) &&
    isset($_POST["form_1_motor_vehiculo"]) &&
    isset($_POST["form_1_vin_vehiculo"]) &&
    isset($_POST["form_1_cilindraje_vehiculo"]) &&
    isset($_POST["form_1_potencia_vehiculo"]) &&
    isset($_POST["form_1_kilometraje_vehiculo"]) &&
    isset($_POST["form_1_tiempos_motor_vehiculo"]) &&
    isset($_POST["form_1_carroceria_vehiculo"]) &&
    isset($_POST["form_1_pasajeros_vehiculo"]) &&
    isset($_POST["form_1_disenio_vehiculo"]) &&
    isset($_POST["form_1_catalizador_vehiculo"]) &&
    isset($_POST["form_1_blindado_vehiculo"]) &&
    isset($_POST["form_1_polarizado_vehiculo"]) &&
    isset($_POST["form_1_exostos_vehiculo"]) &&
    isset($_POST["form_1_ejes_vehiculo"]) &&
    isset($_POST["form_1_combustible_vehiculo"]) &&
    isset($_POST["form_1_tipo_caja_vehiculo"]) &&
    isset($_POST["form_1_numero_puertas"]) &&
    isset($_POST["form_1_nacionalidad_vehiculo"]) &&
    isset($_POST["form_1_pais_vehiculo"]) &&
    isset($_SESSION["session_user"]) &&
    count($_SESSION["session_user"]) == 5 &&
    count($_POST) == 30
) {

    include DOCUMENT_ROOT . '/modulos/assets/php/hdv_database.php';
    include DOCUMENT_ROOT . '/modulos/assets/php/hdv_resources.php';

    $json_status = "error";
    $json_message = "inicio";
    $json_host = getposturl($headers['Origin']);

    if ($json_host['status'] == "ok") {

        if (
            isset($headers['csrf-token']) &&
            hash_equals($headers['csrf-token'], $_SESSION['csrf_token'])
        ) {

            $database = new dbconnection();
            $database->connect();

            if (strcmp($database->status(), "bien") == 0) {

                # $form_1_placa_datos = htmlspecialchars($_POST['form_1_placa']);
                $form_1_fecha_matricula_datos = getspecialdate($_POST['form_1_fecha_matricula']);
                $form_1_licencia_transito_datos = htmlspecialchars($_POST['form_1_licencia_transito']);
                $form_1_tipo_vehiculo_datos = htmlspecialchars($_POST['form_1_tipo_vehiculo']);
                $form_1_servicio_vehiculo_datos = htmlspecialchars($_POST['form_1_servicio_vehiculo']);
                $form_1_clase_vehiculo_datos = htmlspecialchars($_POST['form_1_clase_vehiculo']);
                $form_1_marca_vehiculo_datos = htmlspecialchars($_POST['form_1_marca_vehiculo']);
                $form_1_linea_vehiculo_datos = htmlspecialchars($_POST['form_1_linea_vehiculo']);
                $form_1_modelo_vehiculo_datos = htmlspecialchars($_POST['form_1_modelo_vehiculo']);
                $form_1_color_vehiculo_datos = htmlspecialchars($_POST['form_1_color_vehiculo']);
                $form_1_serie_vehiculo_datos = htmlspecialchars($_POST['form_1_serie_vehiculo']);
                $form_1_motor_vehiculo_datos = htmlspecialchars($_POST['form_1_motor_vehiculo']);
                $form_1_vin_vehiculo_datos = htmlspecialchars($_POST['form_1_vin_vehiculo']);
                $form_1_cilindraje_vehiculo_datos = htmlspecialchars($_POST['form_1_cilindraje_vehiculo']);
                $form_1_potencia_vehiculo_datos = htmlspecialchars($_POST['form_1_potencia_vehiculo']);
                $form_1_kilometraje_vehiculo_datos = htmlspecialchars($_POST['form_1_kilometraje_vehiculo']);
                $form_1_tiempos_motor_vehiculo_datos = htmlspecialchars($_POST['form_1_tiempos_motor_vehiculo']);
                $form_1_carroceria_vehiculo_datos = htmlspecialchars($_POST['form_1_carroceria_vehiculo']);
                $form_1_pasajeros_vehiculo_datos = htmlspecialchars($_POST['form_1_pasajeros_vehiculo']);
                $form_1_disenio_vehiculo_datos = htmlspecialchars($_POST['form_1_disenio_vehiculo']);
                $form_1_catalizador_vehiculo_datos = htmlspecialchars($_POST['form_1_catalizador_vehiculo']);
                $form_1_blindado_vehiculo_datos = htmlspecialchars($_POST['form_1_blindado_vehiculo']);
                $form_1_polarizado_vehiculo_datos = htmlspecialchars($_POST['form_1_polarizado_vehiculo']);
                $form_1_exostos_vehiculo_datos = htmlspecialchars($_POST['form_1_exostos_vehiculo']);
                $form_1_ejes_vehiculo_datos = htmlspecialchars($_POST['form_1_ejes_vehiculo']);
                $form_1_combustible_vehiculo_datos = htmlspecialchars($_POST['form_1_combustible_vehiculo']);
                $form_1_tipo_caja_vehiculo_datos = htmlspecialchars($_POST['form_1_tipo_caja_vehiculo']);
                $form_1_numero_puertas_datos = htmlspecialchars($_POST['form_1_numero_puertas']);
                $form_1_nacionalidad_vehiculo_datos = htmlspecialchars($_POST['form_1_nacionalidad_vehiculo']);
                $form_1_pais_vehiculo_datos = htmlspecialchars($_POST['form_1_pais_vehiculo']);
                $form_1_id_vehiculo_datos = htmlspecialchars($_POST['form_1_id_vehiculo']);

                $mysql_query = "CALL proc_vehiculo_informacion_detallada (";
                $mysql_query .= "?,?,?,?,?,?,?,?,?,?,"; // 10
                $mysql_query .= "?,?,?,?,?,?,?,?,?,?,"; // 10
                $mysql_query .= "?,?,?,?,?,?,?,?,?,?,@respuesta);";

                $mysql_stmt = mysqli_prepare($database->myconn, $mysql_query);

                $mysql_stmt->bind_param(
                    'ssiiiiiiissssssiiiiiiiiiiiiiis',
                    $form_1_fecha_matricula_datos,
                    $form_1_licencia_transito_datos,
                    $form_1_tipo_vehiculo_datos,
                    $form_1_servicio_vehiculo_datos,
                    $form_1_clase_vehiculo_datos,
                    $form_1_marca_vehiculo_datos,
                    $form_1_linea_vehiculo_datos,
                    $form_1_modelo_vehiculo_datos,
                    $form_1_color_vehiculo_datos,
                    $form_1_serie_vehiculo_datos,
                    $form_1_motor_vehiculo_datos,
                    $form_1_vin_vehiculo_datos,
                    $form_1_cilindraje_vehiculo_datos,
                    $form_1_potencia_vehiculo_datos,
                    $form_1_kilometraje_vehiculo_datos,
                    $form_1_tiempos_motor_vehiculo_datos,
                    $form_1_carroceria_vehiculo_datos,
                    $form_1_pasajeros_vehiculo_datos,
                    $form_1_disenio_vehiculo_datos,
                    $form_1_catalizador_vehiculo_datos,
                    $form_1_blindado_vehiculo_datos,
                    $form_1_polarizado_vehiculo_datos,
                    $form_1_exostos_vehiculo_datos,
                    $form_1_ejes_vehiculo_datos,
                    $form_1_combustible_vehiculo_datos,
                    $form_1_tipo_caja_vehiculo_datos,
                    $form_1_numero_puertas_datos,
                    $form_1_nacionalidad_vehiculo_datos,
                    $form_1_pais_vehiculo_datos,
                    $form_1_id_vehiculo_datos,
                );

                if ($mysql_stmt->execute()) {
                    $mysql_stmt->close();
                    $json_status = "ok";
                    $mysql_query = "SELECT @respuesta As json_proc;";
                    $mysql_stmt = mysqli_prepare($database->myconn, $mysql_query);

                    if ($mysql_stmt->execute()) {
                        $mysql_result = $mysql_stmt->get_result();
                        $row = $mysql_result->fetch_assoc();
                        $array_decode = json_decode($row['json_proc']);
                        $json_status = $array_decode[0];
                        $json_message = $array_decode[1];
                        $mysql_stmt->close();
                    } else {
                        $json_status = "error";
                        $json_message = "Error al consultar 2 " . htmlspecialchars($mysql_stmt->error);
                    }
                } else {
                    $json_status = "error";
                    $json_message = "Error al consultar 1 " . htmlspecialchars($mysql_stmt->error);
                }

                $database->close();
            } else {
                $json_status = "error";
                $json_message = "Imposible conectar a la base de datos";
            }
        } else {
            $json_status = "csrf";
            $json_message = htmlspecialchars("Wrong CSRF token.");
        }
    } else {
        $json_status = "error";
        $json_message = htmlspecialchars($json_host['message']);
    }

    $json_array = array(
        'status' => $json_status,
        'message' => $json_message,
    );

    echo json_encode($json_array, JSON_FORCE_OBJECT);
    exit;

} else if (!isset($_SESSION["session_user"])) {
    $datos = array(
        'status' => "session",
        'message' => "La sesión fue cerrada, inicie sesión nuevamente.",
    );
    echo json_encode($datos, JSON_FORCE_OBJECT);
    exit;
} else {
    $json_array = array(
        'status' => "Error",
        'message' => "Formulario incompleto",
    );
    echo json_encode($json_array, JSON_FORCE_OBJECT);
    exit;
}