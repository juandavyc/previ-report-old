<?php

require_once 'models/connection.php';
require_once 'controllers/post.controller.php';
require_once 'controllers/get.controller.php';

if (isset($_POST)) {
    //
    //                                                                               LOGIN
    //
    //peticion post para login
    if (isset($_POST['login']) && $_POST['login'] == true) {
        //Nombre de la tabla
        $suffix = $_POST['suffix'] ?? 'usuario';

        $response = new PostController();

        $UserResponse = $response->postLogin($table, $_POST, $suffix);

        //
        //                                                                               CONSULTAS
        //

    } else if (isset($_POST['query']) && $_POST['query'] == true) {
        
        //peticion de consulta
        // confirma que exista el token
        if (isset($_POST['token']) && !empty($_POST['token'])) {
            
            $response = new PostController();
            
            $tokenResponse = $response->validatePostToken($_POST['token']);
            
            // return;
            // si aqí llega bien la respuesta de el token pasamos a darle acceso para hacer la consulta o lo que vaya a hacer

            if ($tokenResponse['comment'] === "bien") {
                
                // echo "OKOKO";

                // columnas que se van a seleccionar
                $select = $_POST["select"] ?? "*";
                //ordenamiento
                $orderBy = $_POST["orderBy"] ?? null;
                // Limit 
                $startAt = $_POST["startAt"] ?? null;
                $endAt = $_POST["endAt"] ?? null;
                // asc/desc
                $orderMode = $_POST["orderMode"] ?? null;
                // static public function getDataFilter($table, $select, $linkTo, $equalTo, $orderBy, $orderMode, $startAt, $endAt)
                $response = new GetController();

                //consulta con where
                if (isset($_POST["linkTo"]) && isset($_POST["equalTo"])) {
                    $response->getDataFilter($table, $select, $_POST["linkTo"], $_POST["equalTo"], $orderBy, $orderMode, $startAt, $endAt);
                    //consulta sin where
                } else {
                    // echo "GETDATA";
                    $response->getData($table, $select, $orderBy, $orderMode, $startAt, $endAt);
                }
            } else if ($tokenResponse['comment'] === "expired") {

                $json = array(
                    'statusCode' => 303,
                    'result' => 'Token Expirado',


                );
                echo json_encode($json, http_response_code($json["statusCode"]));
                return;
            } else {
                $json = array(
                    'statusCode' => 303,
                    'result' => 'Token invalido',

                );
                echo json_encode($json, http_response_code($json["statusCode"]));
                return;
            }
        } else {
            $json = array(
                'statusCode' => 303,
                'result' => 'Token no suministrado',

            );
            echo json_encode($json, http_response_code($json["statusCode"]));
            return;
        }

//
//                                                                               CREATE
//
    } else if (isset($_POST['create']) && $_POST['create'] == true) {

        if (isset($_POST['token']) && !empty($_POST['token'])) {

            //falta confirmar los nombres de las columnas


 

 
            $response = new PostController();

            $tokenResponse = $response->validatePostToken($_POST['token']);
            // si aqí llega bien la respuesta de el token pasamos a darle acceso para hacer la consulta o lo que vaya a hacer
            if ($tokenResponse['comment'] === "bien") {
                // manera de agregar los datos
                unset($_POST["token"]);
                unset($_POST["create"]);








                $response_create = $response -> postData($table, $_POST);


// var_dump($response_create); return;











                // var_dump($response_create);
            
            } else if ($tokenResponse['comment'] === "expired") {

                $json = array(
                    'statusCode' => 303,
                    'result' => 'Token Expirado',


                );
                echo json_encode($json, http_response_code($json["statusCode"]));
                return;
            } else {
                $json = array(
                    'statusCode' => 303,
                    'result' => 'Token invalido',

                );
                echo json_encode($json, http_response_code($json["statusCode"]));
                return;
            }
        } else {
            $json = array(
                'statusCode' => 303,
                'result' => 'Token no suministrado',

            );
            echo json_encode($json, http_response_code($json["statusCode"]));
            return;
        }
    } else {

        $json = array(
            'statusCode' => 400,
            'result' => 'Bad Request',

        );
        echo json_encode($json, http_response_code($json["statusCode"]));
        return;
    }
} else {
    $json = array(
        'statusCode' => 404,
        'result' => 'Not Found',

    );
    echo json_encode($json, http_response_code($json["statusCode"]));
    return;
}
// devolver un not found
