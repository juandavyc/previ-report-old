<?php

require_once 'models/get.model.php';
require_once 'models/post.model.php';
require_once 'models/connection.php';

class PostController
{

    static public function validatePostToken($token)
    {
       
        $response_token = Connection::validateToken($token);


        return $response_token;
    }
 

    static public function postData($table, $data)
    {
 
        $response = PostModel::postData($table, $data);
        $return = new PostController();

        // var_dump($response['comment'] == "column_name_error");

        if($response['comment'] == "column_name_error"){

            $return->fncResponse(null, "Los nombres de columna no coinciden en la base de datos", null);
        } else{

            $return->fncResponse($response, null, null);

        }

        // return;


        return $response;
    }

    static public function postLogin($table, $data, $suffix)
    {

        // SI vienen los datos
        if (
            isset($data['usuario']) &&
            isset($data['contrasenia']) &&
            isset($data['empresa'])
        ) {

            $response = GetModel::UserLogin($data['usuario'], $data['contrasenia'], $data['empresa']);

            if (!empty($response)) {

                // verifico que el ingreso sea satisfactorio
                // si esta bien creo el token y hago el update con el id que tengo de vuelta y hago una consulta para usuario que me devuelva todos los datos como un array

                $temp_data = json_decode($response);

                if ($temp_data[0] === "bien") {

                    $token = Connection::getToken($temp_data[2], $table);

                    if ($token == "OK, Query were succesfull") {
                        $response_user = GetModel::getUserData($temp_data[2]);

                        $return = new PostController();
                        $return->fncResponse($response_user, null, $suffix);
                    }
                } else {

                    $return = new PostController();
                    $return->fncResponse(null, 'Parametros incorrectos', $suffix);
                }
            } else {
                $return = new PostController();
                $return->fncResponse(null, 'Parametros incorrectos', $suffix);
            }
            // si el user existe
        } else {
            $return = new PostController();
            $return->fncResponse(null, 'Usuario Incorrecto', $suffix);
        }
        // echo json_encode($json), http_response_code($json["statusCode"]);
    }


    public function fncResponse($response, $error, $suffix)
    {

        // return;
        if (!empty($response)) {

            if (isset($response[0]->{"contrasenia_usuario"})) {

                unset($response[0]->{"contrasenia_usuario"});
            }

            $json = array(
                'statusCode' => 200,
                'total' => count($response),
                'results' => $response
            );
        } else {

            if ($error != null) {
                $json = array(
                    'statusCode' => 400,
                    'results' =>  $error
                );
            } else {

                $json = array(
                    'statusCode' => 404,
                    'results' =>  $error
                );
            }
        }

        echo json_encode($json), http_response_code($json["statusCode"]);
    }
}
