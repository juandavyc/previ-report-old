<?php

require_once "models/put.model.php";


class PutController
{

    static public function getData($table, $data)
    {
        $response = PutModel::putData($table, $data);

        $return = new PutController();
        $return_response = $return->fncResponse($response);

        return $return_response;
    }


    public function fncResponse($response)
    {
        // return;
        if (!empty($response)) {

            $json = array(
                'statusCode' => 200,
                'results' => $response
            );
        } else {

            $json = array(
                'statusCode' => 404,
                'results' =>  "error"
            );
        }

        echo json_encode($json), http_response_code($json["statusCode"]);
    }
}
