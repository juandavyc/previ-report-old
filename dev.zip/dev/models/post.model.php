<?php


require_once "connection.php";

class PostModel
{



    static public function postData($table, $data)
    {

        $columns = "";
        $params = "";

        //cofirmar los nombres de las columnas

        foreach ($data as $key => $value) {

            $columns .= $key . ',';
            $params .= ':' . $key . ',';
        }

        $columns = substr($columns, 0, -1);
        $params = substr($params, 0, -1);


// var_dump(Connection::getColumnsDataPost($table,$columns));

        if(empty(Connection::getColumnsDataPost($table,$columns))){
            $response = array(
                "comment" => "column_name_error",
                // "id" => $link->lastInsertId()
            );
            return $response;
        }

        // return;

        $sql =  " INSERT INTO $table ($columns) VALUES ($params)";

        $link = Connection::connect();
        $stmt = $link->prepare($sql);

        foreach ($data as $key => $value) {
            // var_dump("key -> ".$key,"value -> ". $value);
            $stmt->bindParam(":" . $key, $data[$key], PDO::PARAM_STR);
        }

        if ($stmt->execute()) {

            $response = array(
                "comment" => "Agregrado Correctamente",
                "id" => $link->lastInsertId()
            );
        } else {
            return Connection::connect()->errorInfo();
        }

        return $response;
    }

 
    static public function getToken($token)
    {
 
        $sql =  "SELECT token_exp_user FROM usuario WHERE token_user = :token_user";

        // echo $sql;
        $link = Connection::connect();
        $stmt = $link->prepare($sql);

        $stmt->bindParam(":token_user", $token, PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            // contar que el numero de resultados sea mayor a uno.
            if($stmt->rowCount() > 0){

                $response = array(
                    "comment" => "bien",
                    "results" => $stmt->fetchAll(PDO::FETCH_CLASS)
                );
            } else {

                $response = array(
                    "comment" => "error",
                    "results" => "Token invalido"
                );
            }

        } else {
            return Connection::connect()->errorInfo();
        }

        return $response;
    }
}
