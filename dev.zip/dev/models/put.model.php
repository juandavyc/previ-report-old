<?php

require_once "connection.php";

class PutModel
{


    static public function putDataToken($id, $table, $token, $exp)
    {

        $sql =  " UPDATE usuario SET token_user = :token,token_exp_user = :token_exp WHERE id_usuario = :id_usuario ;";
// var_dump($sql);
        $link = Connection::connect();
        $stmt = $link->prepare($sql);
     
            // var_dump("key -> ".$key,"value -> ". $value);
            $stmt->bindParam(":token", $token, PDO::PARAM_STR);
            // $stmt->bindParam(":table", $table, PDO::PARAM_STR);
            $stmt->bindParam(":token_exp", $exp, PDO::PARAM_STR);
            $stmt->bindParam(":id_usuario", $id, PDO::PARAM_STR);
        

        if($stmt -> execute()){

            $response = array(
                "comment" => "OK, Query were succesfull"
            );
        } else {
            return Connection::connect()->errorInfo();
        } 

        return $response;

    } 

    static public function putData($table, $data){

        //validar las columnas a las que se va a hacer update
        if(isset($data['id'])){

            $tempid_update = $data['id'];

            unset($data['id']);
            if(isset($data['token'])){
                unset($data['token']);
            }

            $columns = "";
            $params = "";
            //cofirmar los nombres de las columnas
            foreach ($data as $key => $value) {
                $columns .= $key . ',';
                $params .= ':' . $key . ',';
            }
            $columns = substr($columns, 0, -1);
            $params = substr($params, 0, -1);
    
    
//confirma los datos de las columnas antes d ehacer el update

            $column_confirm = Connection::getColumnsDataPost($table,$columns);

            if(empty($column_confirm)){
                $response = array(
                    "comment" => "column_name_error",
                );
                return $response;
            } else {

                $tempname_id = $column_confirm[0]->{"item"};
                //obtiene el nombre de la columna del id            
            }

            
            $column_update = "";
            
            foreach ($data as $key => $value) {
                
                $column_update .= $key .' = :' . $key . ',';
                
            }
            
            $column_update = substr($column_update, 0,-1) ;
            
            $sql =  "UPDATE $table SET $column_update WHERE $tempname_id = $tempid_update";

            $link = Connection::connect();
            $stmt = $link->prepare($sql);
            foreach ($data as $key => $value) {
                // var_dump("key -> ".$key,"value -> ". $value);
                $stmt->bindParam(":" . $key, $data[$key], PDO::PARAM_STR);
            }

            if ($stmt->execute()) {

                // confirmar quer la columna fué editada o devolver otro mensaje
                if($stmt->rowCount() > 0){
                    $response = array(
                        "comment" => "Editado Correctamente",
                    );
                } else {

                    $response = array(
                        "comment" => "La columna no fue afectada",
                    );
                }
             
            } else {
                return Connection::connect()->errorInfo();
            }

            return $response;

        } else {
            $response = array(
                "comment" => "id no suministrado",
                // "id" => $link->lastInsertId()
            );
            return $response;

        }


    }
}
