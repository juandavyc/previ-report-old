  <?php


    require_once "connection.php";

    class GetModel
    {

        static public function getData($table, $select, $orderBy, $orderMode, $startAt, $endAt)
        {

        // var_dump($table, $select, $orderBy, $orderMode, $startAt, $endAt);

            $selectArray = explode(",", $select);


            // Si el numero de columnas que se solicitan en la consulta coinciden con las de la tabla No entra aqui
            if (empty(Connection::getColumnsData($table, $selectArray))) {
                return null;
            }

            //Validar existencia de la tabla

            $sql = "SELECT $select FROM $table ";
            
            // echo $sql;

            // Solo ordenar
            if ($orderBy != null && $orderMode != null) {

                $sql = "SELECT $select FROM $table ORDER BY $orderBy $orderMode ";
            }

            //Solo limitar sin ordenar
            if ($startAt != null && $endAt != null) {

                $sql = "SELECT $select FROM $table LIMIT $startAt,$endAt ";
            }
            // ordenar y limitar
            if ($orderBy != null && $orderMode != null && $startAt != null && $endAt != null) {

                $sql = "SELECT $select FROM $table ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ";
            }

            $stmt = Connection::connect()->prepare($sql);

            $stmt->execute();

            // var_dump($stmt->fetchAll(PDO::FETCH_CLASS));


            return $stmt->fetchAll(PDO::FETCH_CLASS);
        }
 
        static public function getDataFilter($table, $select, $linkTo, $equalTo, $orderBy, $orderMode, $startAt, $endAt)
        {
// var_dump($table, $select);

            // var_dump($table, $select, $linkTo, $equalTo, $orderBy, $orderMode, $startAt, $endAt);
            //Validar existencia de la tabla y de las columnas
            $selectArray = explode(",", $select);
            if (empty(Connection::getColumnsData($table, $selectArray))) {
                return null;
            }

            $linkToArray = explode(",", $linkTo);
            $equalToArray = explode(",", $equalTo);
            $linkToText = "";


            if (count($linkToArray) > 1) {

                foreach ($linkToArray as $key => $value) {
                    if ($key > 0) {

                        $linkToText .= "AND " . $value . "= :" . $value . " ";
                    }
                }
            }

            $sql = "SELECT $select FROM $table WHERE $linkToArray[0] = :$linkToArray[0] $linkToText";

            //  Order
            if ($orderBy != null && $orderMode != null) {
                $sql = "SELECT $select FROM $table WHERE $linkToArray[0] = :$linkToArray[0] $linkToText ORDER BY $orderBy $orderMode ";
            }
            // limitar datos sin ordenar
            if ($startAt != null && $endAt != null) {
                $sql = "SELECT $select FROM $table WHERE $linkToArray[0] = :$linkToArray[0] $linkToText LIMIT $startAt, $endAt ";
            }
            // order and limit
            if ($orderBy != null && $orderMode != null && $startAt != null && $endAt != null) {
                $sql = "SELECT $select FROM $table WHERE $linkToArray[0] = :$linkToArray[0] $linkToText ORDER BY $orderBy $orderMode ";
            }
            // echo $sql;

            $stmt = Connection::connect()->prepare($sql);
            foreach ($linkToArray as $key => $value) {
                $stmt->bindParam(":" . $value, $equalToArray[$key], PDO::PARAM_STR);
            }

            try {
                $stmt->execute();
            } catch (PDOException $th) {
                return null;
            }

            return $stmt->fetchAll(PDO::FETCH_CLASS);
        }


        static public function getUserData($id)
        {
            $sql = "SELECT * FROM usuario WHERE id_usuario = :id_usuario ;";

            $stmt = Connection::connect()->prepare($sql);
         
                $stmt->bindParam(":id_usuario", $id, PDO::PARAM_STR);


            try {
                $stmt->execute();
            } catch (PDOException $th) {
                return null;
            }

            return $stmt->fetchAll(PDO::FETCH_CLASS);
        }




        static public function UserLogin($cedula, $contrasenia, $empresa)
        {
            $cedula_1 = $cedula;
            $contrasenia_t = $contrasenia;
            $empresa = $empresa;

            $database = Connection::connect();

            $sql = "CALL proc_iniciar_sesion_webservice ( :empresa , :usuario , :contrasenia , @respuesta); ";

            $stmt = $database->prepare($sql);
            $stmt->bindParam(":empresa", $empresa, PDO::PARAM_STR);
            $stmt->bindParam(":usuario", $cedula_1, PDO::PARAM_STR);
            $stmt->bindParam(":contrasenia", $contrasenia_t, PDO::PARAM_STR);
            // $stmt->bindParam(":empresa",  $empresa, PDO::PARAM_INT);

            if ($stmt->execute()) {
                $sql = "SELECT @respuesta As JSON_PROC";
                $stmt = $database->prepare($sql);
                if ($stmt->execute()) {
                    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
            }

            return $rows[0]['JSON_PROC'];
        }

        //como empresa = 24
        //como ip = SpartanGgs
    }
