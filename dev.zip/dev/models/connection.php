<?php
require_once 'models/put.model.php';
require_once 'models/post.model.php';
class Connection
{

    static public function infoDatabase()
    {

        $infoDB = array(
            "database" => "u508857687_hoja_de_vida",
            "user" => "u508857687_previreport",
            "pass" => "Previ2022**report"
        );

        return $infoDB;
    }

    static public function connect()
    {

        try {

            $link = new PDO(
                "mysql:host=localhost;dbname=" . Connection::infoDatabase()["database"],
                Connection::infoDatabase()["user"],
                Connection::infoDatabase()["pass"],
            );

            $link->exec("set names utf8");
        } catch (PDOException $e) {

            die("Error: " . $e->getMessage());
        }

        return $link;
    }

    //Validar existencia de una tabla en la base de datos

    static public function getColumnsData($table, $columns)
    {

        $database = Connection::infoDatabase()["database"];

        $validate = Connection::connect()
            ->query("SELECT COLUMN_NAME AS item FROM information_schema.columns WHERE table_schema = '$database' AND table_name = '$table'")
            ->fetchAll(PDO::FETCH_OBJ);


        // Si la tabla no existe
        if (empty($validate)) {

            return null;
        } else {



            if ($columns[0] == "*") {
                array_shift($columns);
            }

            $sum = 0;
            foreach ($validate as $key => $value) {

                $sum += in_array($value->item, $columns);
            }

            return $sum == count($columns) ? $validate : null;
        }
    }


    static public function getColumnsDataPost($table, $columns)
    {

        $columns_array = explode(",", $columns);


        $database = Connection::infoDatabase()["database"];

        $validate = Connection::connect()
            ->query("SELECT COLUMN_NAME AS item FROM information_schema.columns WHERE table_schema = '$database' AND table_name = '$table'")
            ->fetchAll(PDO::FETCH_OBJ);


        // Si la tabla no existe
        if (empty($validate)) {

            return null;
        } else {

            $sum = 0;
            foreach ($validate as $key => $value) {

                // var_dump(in_array($value->item, $columns_array));

                $sum += in_array($value->item, $columns_array);
            }

            return $sum == count($columns_array) ? $validate : null;


        }
    }
    // token

    static public function getToken($id, $table)
    {
        //falta sumarle a el tiempo lo que le doy al token para ser usado
        $time = time() + (60 * 60 * 24); // un dia de expiracion
        $token = bin2hex(random_bytes(32));

        $update = PutModel::putDataToken($id, $table, $token, $time);

        return $update['comment'];
    }

    static public function validateToken($token)
    {

        // consulta en base a el token
        // devolvemos respuestas dependiendo
        // tomamos el tiempo de expiracion
        $response = PostModel::getToken($token);

        if ($response['comment'] === "bien") {

            $exp_token = $response['results'][0]->{"token_exp_user"};

            if ($exp_token < time()) {
                // valida el tiempo de el token 12 horas
                $response['comment'] = "expired";
            }
        } else {
            $response['comment'] = "error";
        }

        return $response;
    }
}
