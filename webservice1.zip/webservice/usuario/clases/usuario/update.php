<?php

class UpdateUsuario
{
    private $databaseConnection = null;
    private $arrayResponse = array();

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }
  

        public function setDatosUsuario(
            $_datos_ = array(
                'ID' => 0,
                'FOTO' => '/images/sin_imagen.png',
                'NOMBRE' => '',
                'APELLIDO' => '',
                'FIRMA' => '/images/sin_firma.png',
                'TELEFONO' => '',
                'CORREO' => 'sin_correo@sin_correo.com',
                'FECHA_NACIMIENTO' => '2999-01-01',
                'ID_EMPRESA' => 1,
                'ID_TALLER' => 1,
                'ID_RANGO' => 6,
                'ID_USUARIO' => 1,
            )
        ) { 

            $mysqlQuery = "CALL proc_usuario_crear_informacion (";
            $mysqlQuery .= "?,?,?,?,?,?,?,?,?,?,?,?,@respuesta);";

            $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
            $mysqlStmt->bind_param(
                'ssssssisiiii',
                $_datos_['FOTO'],
                $_datos_['NOMBRE'],
                $_datos_['APELLIDO'],
                $_datos_['FIRMA'],
                $_datos_['TELEFONO'],
                $_datos_['CORREO'],
                $_datos_['ID_EMPRESA'],
                $_datos_['FECHA_NACIMIENTO'],
                $_datos_['ID_TALLER'],
                $_datos_['ID_RANGO'],
                $_datos_['ID_USUARIO'],
                $_datos_['ID']
            );

            if ($mysqlStmt->execute()) {
                $mysqlStmt->close();

                $mysqlQuery = "SELECT @respuesta As JSON_PROC; ";
                $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
                if ($mysqlStmt->execute()) {

                    $mysqlResult = $mysqlStmt->get_result();
                    $row = $mysqlResult->fetch_assoc();
                    $mysqlDecode = json_decode($row['JSON_PROC']);

                    $mysqlStmt->close();

                    $this->arrayResponse = array(
                        'status' => $mysqlDecode[0],
                        'message' => $mysqlDecode[1],
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'error',
                        'message' => 'Error en la consulta #2 : ' . htmlspecialchars($mysqlStmt->error),
                    );
                }
            }  else {
                $this->arrayResponse = array(
                    'status' => 'error',
                    'message' => 'Error en la consulta 1 : ' . htmlspecialchars($mysqlStmt->error),
                );
            }
            return $this->arrayResponse;
        }
    }