<?php
class ReadUsuario
{
    private $databaseConnection = null;

    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }

    public function getUsuarioInformacion(
        $_condicional_ = array(
            'TYPE' => 'ID',
            'VALUE' => 1,
        ),
        $_limite_ = '0,5',
        $_empresa_ = '%%'
    ) {

        $arrayCondicional = array(
            'ID' => 'usua.id_usuario',
            'DOCUMENTO' => 'usua.cedula_usuario',
        );

        //$arrayCondicional = $arrayCondicional[];
        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        #tabla empresa
        $mysqlQuery .= "empr.id_empresa,empr.nit,empr.nombre_empresa, ";
        #tabla usuario
        $mysqlQuery .= "usua.id_usuario,usua.nombre_usuario,usua.apellido_usuario, ";
        $mysqlQuery .= "usua.correo_usuario,usua.telefono_usuario,usua.firma_usuario, ";
        $mysqlQuery .= "usua.fecha_formulario,usua.cedula_usuario,usua.fecha_nacimiento_usuario, ";
        $mysqlQuery .= "usua.foto_usuario, usua.fecha_contrasenia, ";
        #tabla rango
        $mysqlQuery .= "rang.id_rango,rang.nombre_rango, ";
        #tabla estado
        $mysqlQuery .= "estd.id_estado,estd.nombre_estado, ";
        #tabla taller
        $mysqlQuery .= "talle.id_taller,talle.nombre_taller, ";
        #tabla usuario - responsable
        $mysqlQuery .= "usac.id_usuario As id_responsable, ";
        $mysqlQuery .= "usac.nombre_usuario As nombre_responsable, ";
        $mysqlQuery .= "usac.apellido_usuario As apellido_responsable ";
        ## FROM ##
        $mysqlQuery .= "FROM ";
        $mysqlQuery .= "usuario usua ";
        #JOIN
        $mysqlQuery .= "INNER JOIN empresa empr ON empr.id_empresa = usua.id_empresa ";
        $mysqlQuery .= "INNER JOIN rango rang ON rang.id_rango = usua.id_rango ";
        $mysqlQuery .= "INNER JOIN estado_usuario estd ON estd.id_estado = usua.id_estado ";
        $mysqlQuery .= "INNER JOIN usuario usac ON usac.id_usuario = usua.id_usuario_formulario ";
        $mysqlQuery .= "INNER JOIN taller talle ON talle.id_taller = usua.id_taller ";
        #Condicion
        $mysqlQuery .= "WHERE ";
        $mysqlQuery .= $arrayCondicional[$_condicional_['TYPE']] . " LIKE ? ";
        $mysqlQuery .= "AND usua.id_rango > 1 ";
        $mysqlQuery .= "AND usua.id_empresa LIKE ? ";
        #Ordenamiento
        $mysqlQuery .= "ORDER BY usua.id_usuario DESC; ";

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('ss', $_condicional_['VALUE'], $_empresa_);
        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {
                    array_push(
                        $mysqlArray,
                        array(
                            "id" => ($row['id_usuario']),
                            "cedula" => htmlspecialchars($row['cedula_usuario']),
                            "nombre" => htmlspecialchars($row['nombre_usuario']),
                            "apellido" => htmlspecialchars($row['apellido_usuario']),
                            "correo" => htmlspecialchars($row['correo_usuario']),
                            "telefono" => htmlspecialchars($row['telefono_usuario']),
                            "fecha_contrasenia" => htmlspecialchars($row['fecha_contrasenia']),
                            #"fecha_nacimiento" => htmlspecialchars($row['fecha_nacimiento_usuario']),
                            "firma" => htmlspecialchars($row['firma_usuario']),
                            "foto" => htmlspecialchars($row['foto_usuario']),
                            "empresa" => array(
                                "id" => ($row['id_empresa']),
                                "nit" => htmlspecialchars($row['nit']),
                                "nombre" => htmlspecialchars($row['nombre_empresa']),
                            ),
                            "rango" => array(
                                "id" => htmlspecialchars($row['id_rango']),
                                "rango" => htmlspecialchars($row['nombre_rango']),
                            ),
                            "estado" => array(
                                "id" => htmlspecialchars($row['id_estado']),
                                "estado" => htmlspecialchars($row['nombre_estado']),
                            ),
                            "taller" => array(
                                "id" => htmlspecialchars($row['id_taller']),
                                "nombre" => htmlspecialchars($row['nombre_taller']),
                            ),
                            "usuario" => htmlspecialchars($row['nombre_responsable'] . " " . $row['apellido_responsable']),
                            "fecha" => htmlspecialchars($row['fecha_formulario']),
                        )
                    );
                }

                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Resultados encontrados',
                    'usuario' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }

}