<?php
header("Content-Type: application/json; charset=UTF-8");

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'GET') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );

    if (COUNT($_GET) > 1 &&
        isset($_GET['acct']) &&
        isset($_GET['type']) &&
        isset($_GET['usuario']) &&
        isset($_GET['empresa'])
    ) {

        require '../auth_database.php';
        require '../auth_user.php';

        # usuario esta autorizado
        $_user = htmlspecialchars($_GET['acct']);

        $database = new dbconnection();
        $database->connect();
        if (strcmp($database->status(), "bien") == 0) {

            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            if (strcmp($responseAcct['status'], 'bien') == 0) {

                $_type = strtoupper(htmlspecialchars($_GET['type']));
                $value = htmlspecialchars($_GET['usuario']);
                $empresa = htmlspecialchars($_GET['empresa']);

                require DOCUMENT_ROOT . '/webservice/usuario/clases/usuario/read.php';

                $usuario = new ReadUsuario($database->myconn);
                $arrayUsuario = $usuario->getUsuarioInformacion(
                    array(
                        'VALUE' => $value,
                        'TYPE' => $_type,
                    ),
                    '0,1000',
                    $empresa,
                );

                if (strcmp($arrayUsuario['status'], 'bien') == 0) {

                    $_array_response = array(
                        'status' => $arrayUsuario['status'],
                        'message' => $arrayUsuario['message'],
                        'usuario' => $arrayUsuario['usuario'],

                    );
                    $_ID_usuario = $arrayUsuario['usuario']['0']['id'];

                } else {
                    $_array_response = array(
                        'status' => $arrayUsuario['status'],
                        'message' => $arrayUsuario['message'],
                    );
                }
            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }
            $database->close();

        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}