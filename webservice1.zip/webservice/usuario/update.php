<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

// var_dump($_POST);

if (strcmp($methodRequest, 'POST') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );
    # los obligatorios
    if (
        isset($_POST['acct']) &&
        isset($_POST['nombre']) &&
        isset($_POST['apellido']) &&
        isset($_POST['id_empresa']) &&
        isset($_POST['correo']) &&
        isset($_POST['telefono']) &&
        isset($_POST['firma']) &&
        isset($_POST['fecha_nacimiento']) &&
        isset($_POST['id_rango']) &&
        isset($_POST['id_taller']) &&
        isset($_POST['id_usuario']) &&
        isset($_POST['foto']) &&
        COUNT($_POST) == 12

    ) {

        require DOCUMENT_ROOT . '/webservice/auth_resources.php';
        //db

        require DOCUMENT_ROOT . '/webservice/auth_database.php';
        require DOCUMENT_ROOT . '/webservice/auth_user.php';

        # usuario esta autorizado
        $_user = htmlspecialchars($_POST['acct']);

        // photo64
        require DOCUMENT_ROOT . '/webservice/uploader/create.php';

        $database = new dbconnection();
        $database->connect();

        if (strcmp($database->status(), "bien") == 0) {

            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            if (strcmp($responseAcct['status'], 'bien') == 0) {

                $idUser = $responseAcct['id_user'];

                // clase photo
                $base64 = new CreateBase64($idUser);

                $responseFoto = $base64->setBase64($_POST["foto"], 'conductores');
                $responseFirma = $base64->setBase64($_POST["firma"], 'firmas/usuarios');

                require DOCUMENT_ROOT . '/webservice/usuario/clases/usuario/update.php';
                $usuario = new UpdateUsuario($database->myconn);
                $arrayUsuario = $usuario->setDatosUsuario(
                    array(
                        'NOMBRE' => htmlspecialchars($_POST['nombre']),
                        'APELLIDO' => htmlspecialchars($_POST['apellido']),
                        'ID_EMPRESA' => htmlspecialchars($_POST['id_empresa']),
                        'CORREO' => htmlspecialchars($_POST['correo']),
                        'TELEFONO' => htmlspecialchars($_POST['telefono']),
                        'FIRMA' => $responseFoto['message'],
                        'FECHA_NACIMIENTO' => getspecialdate($_POST['fecha_nacimiento']),
                        'ID_RANGO' => htmlspecialchars($_POST['id_rango']),
                        'ID_TALLER' => htmlspecialchars($_POST['id_taller']),
                        'ID_USUARIO' => $idUser,
                        'FOTO' => $responseFirma['message'],
                        'ID' => htmlspecialchars($_POST['id_usuario']),
                    )

                );

                if ($arrayUsuario['status'] == 'bien') {
                    $_array_response = array(
                        'status' => $arrayUsuario['status'],
                        'message' => $arrayUsuario['message'],
                    );
                } else {
                    $_array_response = array(
                        'status' => $arrayUsuario['status'],
                        'message' => $arrayUsuario['message'],
                    );
                }

            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

            $database->connect();
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}