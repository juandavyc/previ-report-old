<?php
class ReadEmpresa
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }
    public function getEmpresa(
        $_condicional_ = array(
            'TYPE' => 'ID',
            'VALUE' => 0,
            'LIMIT' => '0,5',
        )
    ) {

        // var_dump($_condicional_);

        $_array_empresa_default = array(
            0 => array(
                'id' => 0,
            ),
        );

        $arrayCondicional = array(
            'ID' => 'empr.id_empresa',
            'NIT' => 'empr.nit',
            'NOMBRE' => 'empr.nombre_empresa',
        );

        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        #tabla empresa
        $mysqlQuery .= "empr.id_empresa,empr.nit,empr.nombre_empresa,empr.direccion, ";
        $mysqlQuery .= "empr.fecha_formulario,empr.telefono,empr.correo,";
        #tabla ciudad
        $mysqlQuery .= "ciud.nombre_ciudad,ciud.id_ciudad, ";
        #tabla departamento
        $mysqlQuery .= "dept.nombre_departamento,dept.id_departamento, ";
        #tabla usuario
        $mysqlQuery .= "usua.id_usuario,usua.nombre_usuario,usua.apellido_usuario ";
        ## FROM ##
        $mysqlQuery .= "FROM ";
        $mysqlQuery .= "empresa empr ";
        #JOIN
        $mysqlQuery .= "LEFT JOIN ciudad ciud ON empr.id_ciudad = ciud.id_ciudad ";
        $mysqlQuery .= "LEFT JOIN departamento dept ON dept.id_departamento = ciud.id_departamento ";
        $mysqlQuery .= "LEFT JOIN usuario usua ON empr.id_usuario = usua.id_usuario ";
        #Condicion
        $mysqlQuery .= "WHERE ";
        $mysqlQuery .= $arrayCondicional[$_condicional_['TYPE']] . " LIKE ? ";
        #Ordenamiento
        $mysqlQuery .= "ORDER BY empr.id_empresa DESC ";
        $mysqlQuery .= "LIMIT " . $_condicional_['LIMIT'] . " ;";

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_condicional_['VALUE']);
        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {
                    array_push(
                        $mysqlArray,
                        array(
                            "id" => ($row['id_empresa']),
                            "nit" => htmlspecialchars($row['nit']),
                            "nombre" => htmlspecialchars($row['nombre_empresa']),
                            "telefono" => htmlspecialchars($row['telefono']),
                            "direccion" => htmlspecialchars($row['direccion']),
                            "correo" => htmlspecialchars($row['correo']),
                            'ciudad' => array(
                                "id" => ($row['id_ciudad']),
                                "nombre" => htmlspecialchars($row['nombre_ciudad']),
                            ),
                            'departamento' => array(
                                "id" => ($row['id_departamento']),
                                "nombre" => htmlspecialchars($row['nombre_departamento']),
                            ),
                            "usuario" => array(
                                'id' => ($row['id_usuario']),
                                'nombre' => htmlspecialchars($row['nombre_usuario'] . ' ' . $row['apellido_usuario']),
                            ),
                            "fecha" => htmlspecialchars($row['fecha_formulario']),
                        )
                    );
                }
                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Resultados encontrados',
                    'empresa' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                    'empresa' => $_array_empresa_default,
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }

}