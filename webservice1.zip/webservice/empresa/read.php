<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'GET') == 0) {
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );
    # los obligatorios
    if (
        COUNT($_GET) > 1 &&
        isset($_GET['acct']) &&
        isset($_GET['type']) &&
        isset($_GET['value'])
    ) {

        require '../auth_database.php';
        require '../auth_user.php';

        # usuario esta autorizado
        $_user = htmlspecialchars($_GET['acct']);

        $database = new dbconnection();
        $database->connect();
        if (strcmp($database->status(), "bien") == 0) {

            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            if (strcmp($responseAcct['status'], 'bien') == 0) {

                $_limit = '0,1';

                $_type = strtoupper(htmlspecialchars($_GET['type']));

                # si tiene empresa
                $value = htmlspecialchars($_GET['value']);
                $value == '%%' ? $_limit = '0,100' : $_limit = '0,1';

                require DOCUMENT_ROOT . '/webservice/empresa/clases/empresa/read.php';

                $empresa = new Readempresa($database->myconn);
                $arrayempresa = $empresa->getempresa(
                    array(
                        'VALUE' => $value,
                        'TYPE' => $_type,
                        'LIMIT' => $_limit,
                    ),
                );

                # empresa ENCONTRADO
                if (strcmp($arrayempresa['status'], 'bien') == 0) {
                    $_array_response = array(
                        'status' => $arrayempresa['status'],
                        'message' => $arrayempresa['message'],
                        'empresa' => $arrayempresa['empresa'],
                    );
                    // ID vehiculo
                    $_ID_empresa = $arrayempresa['empresa']['0']['id'];

                }
                # vehiculo NO ENCONTRADO
                else {
                    $_array_response = array(
                        'status' => $arrayVehiculo['status'],
                        'message' => $arrayVehiculo['message'],
                    );
                }
            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

            $database->close();
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }
    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}