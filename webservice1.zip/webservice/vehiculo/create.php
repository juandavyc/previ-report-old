<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'POST') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );
    # los obligatorios
    if (
        isset($_POST['acct']) &&
        isset($_POST['placa']) &&
        isset($_POST['empresa']) &&
        COUNT($_POST) == 3
    ) {

        require '../auth_database.php';
        require '../auth_user.php';

        # usuario esta autorizado
        $_user = htmlspecialchars($_POST['acct']);

        $database = new dbconnection();
        $database->connect();

        if (strcmp($database->status(), "bien") == 0) {

            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            if (strcmp($responseAcct['status'], 'bien') == 0) {

                $idUser = $responseAcct['id_user'];
                $idEmpresa = 1;

                $formPlaca = htmlspecialchars($_POST['placa']);
                $formEmpresa = htmlspecialchars($_POST['empresa']);

                # verificar empresa
                $typeEmpresa = is_numeric($formEmpresa) ? 'ID' : 'NIT';
                require DOCUMENT_ROOT . '/webservice/empresa/clases/empresa/read.php';
                $empresa = new ReadEmpresa($database->myconn);
                $arrayEmpresa = $empresa->getEmpresa(
                    array(
                        'TYPE' => $typeEmpresa,
                        'VALUE' => $formEmpresa,
                        'LIMIT' => '0,1',
                    ),
                );

                if (strcmp($arrayEmpresa['status'], 'bien') == 0) {
                    $idEmpresa = $arrayEmpresa['empresa'][0]['id'];

                    require DOCUMENT_ROOT . '/webservice/vehiculo/clases/vehiculo/create.php';
                    $vehiculo = new CreateVehiculo($database->myconn);
                    $arrayVehiculo = $vehiculo->setVehiculoPlaca(
                        $formPlaca,
                        $formEmpresa,
                        $idUser
                    );

                    if ($arrayVehiculo['status'] == 'bien') {

                        $_array_response = array(
                            'status' => $arrayVehiculo['status'],
                            'message' => $arrayVehiculo['message'],
                            'id' => $arrayVehiculo['id'],
                            'placa' => $arrayVehiculo['placa'],
                        );
                    } else {
                        $_array_response = array(
                            'status' => $arrayVehiculo['status'],
                            'message' => $arrayVehiculo['message'],
                        );
                    }
                } else {
                    $_array_response = array(
                        'status' => 'error',
                        'message' => 'La empresa no existe',
                    );
                }
            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

            $database->close();
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}