<?php
class ReadSolicitud
{

    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }

    public function getSolicitud($_id_vehiculo_)
    {

        $mysqlArray = array();


        $mysqlQuery = "SELECT ";
        $mysqlQuery .= "sol.id_solicitud,sol.numero_solicitud, ";
        $mysqlQuery .= "sol.fecha_solicitud,sol.foto_solicitud,sol.fecha_formulario, ";
        $mysqlQuery .= "enta.id_entidad_transito,enta.nombre_entidad_transito,  ";
        $mysqlQuery .= "tisol.id_tipo_solicitud,tisol.nombre_tipo_solicitud, ";
        $mysqlQuery .= "essol.id_estado_solicitud, essol.nombre_estado_solicitud, ";
        $mysqlQuery .= "usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";
        $mysqlQuery .= "FROM solicitud sol ";
        $mysqlQuery .= "LEFT JOIN tipo_solicitud tisol ON sol.id_tipo_solicitud = tisol.id_tipo_solicitud ";
        $mysqlQuery .= "LEFT JOIN entidad_transito enta ON sol.id_entidad_transito = enta.id_entidad_transito ";
        $mysqlQuery .= "LEFT JOIN estado_solicitud essol ON sol.id_estado_solicitud = essol.id_estado_solicitud ";
        $mysqlQuery .= "LEFT JOIN usuario usu ON usu.id_usuario = sol.id_usuario ";
        $mysqlQuery .= "WHERE sol.id_vehiculo = ? ";
        $mysqlQuery .= "AND sol.is_visible = 1 ";
        $mysqlQuery .= "ORDER BY sol.id_solicitud DESC; ";


        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_vehiculo_);
        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {
                    array_push(
                        $mysqlArray,
                        array(
                            "id" => htmlspecialchars($row['id_solicitud']),
                            "numero" => htmlspecialchars($row['numero_solicitud']),
                            "fecha" => htmlspecialchars($row['fecha_solicitud']),
                            "archivo" => htmlspecialchars($row['foto_solicitud']),
                            "tipo" => array(
                                "id" => htmlspecialchars($row['id_tipo_solicitud']),
                                "nombre" => htmlspecialchars($row['nombre_tipo_solicitud']),
                            ),
                            "entidad" => array(
                                "id" => htmlspecialchars($row['id_entidad_transito']),
                                "nombre" => htmlspecialchars($row['nombre_entidad_transito']),
                            ),
                            "estado" => array(
                                "id" => htmlspecialchars($row['id_estado_solicitud']),
                                "nombre" => htmlspecialchars($row['nombre_estado_solicitud']),
                            ),
                            "responsable" => htmlspecialchars($row['nombre_usuario'] . " " . $row['apellido_usuario']),
                            "creado" => htmlspecialchars($row['fecha_formulario']),
                        )
                    );
                }
                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Solicitud(s) encontrado(s)',
                    'solicitud' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}