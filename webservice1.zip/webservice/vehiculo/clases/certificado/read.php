<?php
class ReadCertificado
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getCertificado($_id_vehiculo_)
    {


        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        $mysqlQuery .= "cert.id_certificado,cert.numero_certificado,cert.foto_certificado, ";
        $mysqlQuery .= "enti.id_entidad_certificado,enti.nombre_entidad_certificado, ";
        $mysqlQuery .= "tipo.id_tipo_certificado,tipo.nombre_tipo_certificado, ";
        $mysqlQuery .= "cert.fecha_expedicion_certificado,cert.fecha_vencimiento_certificado, ";
        $mysqlQuery .= "usu.id_usuario, usu.nombre_usuario,usu.apellido_usuario, ";
        $mysqlQuery .= "cert.fecha_formulario ";
        $mysqlQuery .= "FROM certificado cert ";
        $mysqlQuery .= "LEFT JOIN entidad_certificado enti ON enti.id_entidad_certificado = cert.id_entidad_certificado ";
        $mysqlQuery .= "LEFT JOIN tipo_certificado tipo ON tipo.id_tipo_certificado = cert.id_tipo_certificado ";
        $mysqlQuery .= "LEFT JOIN usuario usu ON usu.id_usuario = cert.id_usuario ";
        $mysqlQuery .= "WHERE cert.id_vehiculo LIKE ? ";
        $mysqlQuery .= "AND cert.is_visible = 1  ";
        $mysqlQuery .= "ORDER BY cert.id_certificado DESC;";


        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_vehiculo_);
        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {
                    array_push(
                        $mysqlArray,
                        array(
                            "id" => htmlspecialchars($row['id_certificado']),
                            "numero" => htmlspecialchars($row['numero_certificado']),
                            "expedicion" => htmlspecialchars($row['fecha_expedicion_certificado']),
                            "vencimiento" => htmlspecialchars($row['fecha_vencimiento_certificado']),
                            "archivo" => htmlspecialchars($row['foto_certificado']),
                            "tipo" => array(
                                "id" => htmlspecialchars($row['id_tipo_certificado']),
                                "nombre" => htmlspecialchars($row['nombre_tipo_certificado']),
                            ),
                            "entidad" => array(
                                "id" => htmlspecialchars($row['id_entidad_certificado']),
                                "nombre" => htmlspecialchars($row['nombre_entidad_certificado']),
                            ),
                            "responsable" => htmlspecialchars($row['nombre_usuario'] . " " . $row['apellido_usuario']),
                            "creado" => htmlspecialchars($row['fecha_formulario']),
                        )
                    );
                }
                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Certificados(s) encontrado(s)',
                    'certificado' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}