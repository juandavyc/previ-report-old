<?php
class ReadVehiculo
{

    private $databaseConnection = null;

    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }
    public function getVehiculo(
        $_condicional_ = array(
            'TYPE' => 'ID',
            'VALUE' => 1,
        ),
        $_limite_ = '0,5',
        $_empresa_ = '%%'
    ) {

        $arrayCondicional = array(
            'ID' => 'veh.id_vehiculo',
            'PLACA' => 'veh.placa_vehiculo',
        );

        //$arrayCondicional = $arrayCondicional[];
        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        # VEHICULO
        $mysqlQuery .= "veh.id_vehiculo,veh.placa_vehiculo, ";
        $mysqlQuery .= "veh.fecha_matricula_vehiculo, ";
        $mysqlQuery .= "veh.numero_licencia_vehiculo, tveh.id_tipo_vehiculo, ";
        $mysqlQuery .= "veh.modelo_vehiculo, ";
        $mysqlQuery .= "veh.numero_serie_vehiculo, veh.numero_motor_vehiculo,  ";
        $mysqlQuery .= "veh.vin_vehiculo, veh.cilindraje_vehiculo,  ";
        $mysqlQuery .= "veh.gravamenes_vehiculo, veh.clasico_antiguo, veh.repotenciado ,veh.estado_vehiculo, ";
        $mysqlQuery .= "veh.ensenianza_vehiculo,  ";
        $mysqlQuery .= "veh.regrabacion_motor, veh.numero_regrabacion_motor, ";
        $mysqlQuery .= "veh.regrabacion_chasis, veh.numero_regrabacion_chasis, ";
        $mysqlQuery .= "veh.regrabacion_vin, veh.numero_regrabacion_vin, ";
        $mysqlQuery .= "veh.regrabacion_serie, veh.numero_regrabacion_serie, ";
        $mysqlQuery .= "veh.kilometraje_vehiculo, ";
        # AUTORIDAD
        $mysqlQuery .= "aut.id_autoridad_de_transito ,aut.nombre_autoridad_de_transito, ";

        # MARCA
        $mysqlQuery .= "mar.id_marca, mar.nombre_marca, ";
        # LINEA
        $mysqlQuery .= "lin.id_linea, lin.nombre_linea, ";
        # SERVICIO
        $mysqlQuery .= "ser.id_servicio, ser.nombre_servicio, ";
        # COLOR
        $mysqlQuery .= "col.id_color,col.nombre_color, ";
        # COMBUSTIBLE
        $mysqlQuery .= "tcom.id_combustible,tcom.nombre_combustible, ";
        # EMPRESA
        $mysqlQuery .= "empr.id_empresa,empr.nit,empr.nombre_empresa,  ";
        # CLASE
        $mysqlQuery .= "cla.id_clase, cla.nombre_clase, ";
        # TIPO
        $mysqlQuery .= "tveh.id_tipo_vehiculo, tveh.nombre_tipo_vehiculo, ";
        # CARROCERIA
        $mysqlQuery .= "car.id_tipo_carroceria,car.nombre_tipo_carroceria, ";
        # USUARIO
        $mysqlQuery .= "usu.id_usuario, usu.nombre_usuario,usu.apellido_usuario, ";
        # FOTOS
        $mysqlQuery .= "veh.foto_delantera,veh.foto_trasera,veh.foto_costado_izquierdo,veh.foto_costado_derecho, ";
        $mysqlQuery .= "veh.impronta_chasis,veh.impronta_serial,veh.impronta_motor, ";
        $mysqlQuery .= "veh.licencia_transito_delantera,veh.licencia_transito_trasera, ";
        $mysqlQuery .= "veh.fecha_formulario ";

        $mysqlQuery .= "FROM vehiculo veh ";
        $mysqlQuery .= "INNER JOIN clase cla ON cla.id_clase = veh.id_clase ";
        $mysqlQuery .= "INNER JOIN tipo_vehiculo tveh ON tveh.id_tipo_vehiculo = cla.id_tipo_vehiculo ";
        $mysqlQuery .= "INNER JOIN servicio ser ON ser.id_servicio = veh.id_servicio ";
        $mysqlQuery .= "INNER JOIN linea lin ON lin.id_linea = veh.id_linea ";
        $mysqlQuery .= "INNER JOIN marca mar ON mar.id_marca = lin.id_marca ";
        $mysqlQuery .= "INNER JOIN color col ON col.id_color = veh.id_color ";
        $mysqlQuery .= "INNER JOIN combustible tcom ON tcom.id_combustible = veh.id_combustible ";
        $mysqlQuery .= "INNER JOIN usuario usu ON usu.id_usuario = veh.id_usuario ";
        $mysqlQuery .= "INNER JOIN empresa empr ON empr.id_empresa = veh.id_empresa ";
        $mysqlQuery .= "LEFT JOIN tipo_carroceria car ON car.id_tipo_carroceria = veh.id_tipo_carroceria  ";
        $mysqlQuery .= "LEFT JOIN autoridad_de_transito aut ON aut.id_autoridad_de_transito = veh.id_autoridad_de_transito ";
        $mysqlQuery .= "WHERE ";
        $mysqlQuery .= $arrayCondicional[$_condicional_['TYPE']] . " LIKE ? ";
        $mysqlQuery .= "AND empr.id_empresa LIKE ? ";
        $mysqlQuery .= "ORDER BY veh.id_vehiculo DESC LIMIT " . $_limite_ . ";";

        //  echo $mysqlQuery;

        // class
        require_once DOCUMENT_ROOT . '/webservice/vehiculo/clases/datos_tecnicos/read.php';
        require_once DOCUMENT_ROOT . '/webservice/vehiculo/clases/certificado/read.php';
        require_once DOCUMENT_ROOT . '/webservice/vehiculo/clases/poliza/read.php';
        require_once DOCUMENT_ROOT . '/webservice/vehiculo/clases/preventiva/read.php';
        require_once DOCUMENT_ROOT . '/webservice/vehiculo/clases/rtm/read.php';
        require_once DOCUMENT_ROOT . '/webservice/vehiculo/clases/soat/read.php';
        require_once DOCUMENT_ROOT . '/webservice/vehiculo/clases/solicitud/read.php';
        require_once DOCUMENT_ROOT . '/webservice/vehiculo/clases/tarjeta_operacion/read.php';
        require_once DOCUMENT_ROOT . '/webservice/vehiculo/clases/vehiculo_asignado/read.php';

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('ss', $_condicional_['VALUE'], $_empresa_);
        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {

                while ($row = $mysqlResult->fetch_assoc()) {

                    $responseDatosTecnicos['datos_tecnicos'] = array();
                    $datosTecnicos = new ReadDatos($this->databaseConnection);
                    $arrayDatosTecnicos = $datosTecnicos->getDatosVehiculo(
                        $row['id_vehiculo']
                    );
                    if (strcmp($arrayDatosTecnicos['status'], 'bien') == 0) {
                        $responseDatosTecnicos['datos_tecnicos'] = $arrayDatosTecnicos['datos_tecnicos'];
                    }
                    // certificados ( general )

                    $responseCertificado['certificado'] = array();

                    $certficado = new ReadCertificado($this->databaseConnection);
                    $arrayCertificado = $certficado->getCertificado(
                        $row['id_vehiculo']
                    );
                    if (strcmp($arrayCertificado['status'], 'bien') == 0) {
                        $responseCertificado['certificado'] = $arrayCertificado['certificado'];
                    }
                    // poliza (general)

                    $responsePoliza['poliza'] = array();
                    $poliza = new ReadPoliza($this->databaseConnection);
                    $arrayPoliza = $poliza->getPoliza(
                        $row['id_vehiculo']
                    );
                    if (strcmp($arrayPoliza['status'], 'bien') == 0) {
                        $responsePoliza['poliza'] = $arrayPoliza['poliza'];
                    }
                    // preventiva (general)

                    $responsePreventiva['preventiva'] = array();
                    $preventiva = new ReadPreventiva($this->databaseConnection);
                    $arrayPreventiva = $preventiva->getPreventiva(
                        $row['id_vehiculo']
                    );
                    if (strcmp($arrayPreventiva['status'], 'bien') == 0) {
                        $responsePreventiva['preventiva'] = $arrayPreventiva['preventiva'];
                    }
                    // rtm (general)

                    $responseRTM['rtm'] = array();
                    $rtm = new ReadRTM($this->databaseConnection);
                    $arrayRTM = $rtm->getRTM(
                        $row['id_vehiculo']
                    );
                    if (strcmp($arrayRTM['status'], 'bien') == 0) {
                        $responseRTM['rtm'] = $arrayRTM['rtm'];
                    }
                    // soat (general)

                    $responseSoat['soat'] = array();
                    $soat = new ReadSoat($this->databaseConnection);
                    $arraySoat = $soat->getSoat(
                        $row['id_vehiculo']
                    );
                    if (strcmp($arraySoat['status'], 'bien') == 0) {
                        $responseSoat['soat'] = $arraySoat['soat'];
                    }
                    // solicitud (general)
                    $responseSolicitud['solicitud'] = array();
                    $solicitud = new ReadSolicitud($this->databaseConnection);
                    $arraySolicitud = $solicitud->getSolicitud(
                        $row['id_vehiculo']
                    );
                    if (strcmp($arraySoat['status'], 'bien') == 0) {
                        $responseSolicitud['solicitud'] = $arraySolicitud['solicitud'];
                    }
                    // tarjeta de operacion (general)

                    $responsetTarjetaOperacion['tarjeta_operacion'] = array();
                    $tarjetaOperacion = new ReadTarjetaOperacion($this->databaseConnection);
                    $arrayTarjetaOperacion = $tarjetaOperacion->getTarjetaOperacion(
                        $row['id_vehiculo']
                    );

                    if (strcmp($arrayTarjetaOperacion['status'], 'bien') == 0) {
                        $responsetTarjetaOperacion['tarjeta_operacion'] = $arrayTarjetaOperacion['tarjeta_operacion'];
                    }
                    // vehiculo asignado

                    $responseConductor['conductor_asignado'] = array();
                    $vehiculoAsignado = new ReadVehiculoAsignado($this->databaseConnection);
                    $arrayVehiculoAsignado = $vehiculoAsignado->getVehiculoAsignado(
                        $row['id_vehiculo']
                    );

                    if (strcmp($arrayVehiculoAsignado['status'], 'bien') == 0) {
                        $responseConductor['conductor_asignado'] = $arrayVehiculoAsignado['vehiculo_asignado'];
                    }

                    array_push(
                        $mysqlArray,
                        array(
                            "id" => htmlspecialchars($row['id_vehiculo']),
                            "placa" => htmlspecialchars($row['placa_vehiculo']),
                            "modelo" => htmlspecialchars($row['modelo_vehiculo']),
                            "kilometraje" => htmlspecialchars($row['kilometraje_vehiculo']),
                            "cilindraje" => htmlspecialchars($row['cilindraje_vehiculo']),
                            "numero_serie" => htmlspecialchars($row['numero_serie_vehiculo']),
                            "numero_motor" => htmlspecialchars($row['numero_motor_vehiculo']),
                            "vin" => htmlspecialchars($row['vin_vehiculo']),
                            "gravamene" => htmlspecialchars($row['gravamenes_vehiculo']),
                            "clasico_antiguo" => htmlspecialchars($row['clasico_antiguo']),
                            "repotenciado" => htmlspecialchars($row['repotenciado']),
                            "estado_vehiculo" => htmlspecialchars($row['estado_vehiculo']),
                            "ensenianza" => htmlspecialchars($row['ensenianza_vehiculo']),
                            "regrabacion_motor" => htmlspecialchars($row['regrabacion_motor']),
                            "numero_regrabacion_motor" => htmlspecialchars($row['numero_regrabacion_motor']),
                            "regrabacion_chasis" => htmlspecialchars($row['regrabacion_chasis']),
                            "numero_regrabacion_chasis" => htmlspecialchars($row['numero_regrabacion_chasis']),
                            "regrabacion_vin" => htmlspecialchars($row['regrabacion_vin']),
                            "numero_regrabacion_vin" => htmlspecialchars($row['numero_regrabacion_vin']),
                            "regrabacion_serie" => htmlspecialchars($row['regrabacion_serie']),
                            "numero_regrabacion_serie" => htmlspecialchars($row['numero_regrabacion_serie']),
                            "fecha_matricula" => htmlspecialchars($row['fecha_matricula_vehiculo']),
                            "numero_licencia" => htmlspecialchars($row['numero_licencia_vehiculo']),
                            "foto" => array(
                                "delantera" => htmlspecialchars($row['foto_delantera']),
                                "trasera" => htmlspecialchars($row['foto_trasera']),
                                "izquierda" => htmlspecialchars($row['foto_costado_izquierdo']),
                                "derecha" => htmlspecialchars($row['foto_costado_derecho']),
                            ),
                            "impronta" => array(
                                "serial" => htmlspecialchars($row['impronta_serial']),
                                "chasis" => htmlspecialchars($row['impronta_chasis']),
                                "motor" => htmlspecialchars($row['impronta_motor']),
                            ),
                            "licencia" => array(
                                "delantera" => htmlspecialchars($row['licencia_transito_delantera']),
                                "trasera" => htmlspecialchars($row['licencia_transito_trasera']),
                            ),
                            "tipo" => array(
                                "id" => htmlspecialchars($row['id_tipo_vehiculo']),
                                "nombre" => htmlspecialchars($row['nombre_tipo_vehiculo']),
                            ),
                            "servicio" => array(
                                "id" => htmlspecialchars($row['id_servicio']),
                                "nombre" => htmlspecialchars($row['nombre_servicio']),
                            ),
                            "clase" => array(
                                "id" => htmlspecialchars($row['id_clase']),
                                "nombre" => htmlspecialchars($row['nombre_clase']),
                            ),
                            "marca" => array(
                                "id" => htmlspecialchars($row['id_marca']),
                                "nombre" => htmlspecialchars($row['nombre_marca']),
                            ),
                            "linea" => array(
                                "id" => htmlspecialchars($row['id_linea']),
                                "nombre" => htmlspecialchars($row['nombre_linea']),
                            ),
                            "color" => array(
                                "id" => htmlspecialchars($row['id_color']),
                                "nombre" => htmlspecialchars($row['id_color']),
                            ),
                            "combustible" => array(
                                "id" => htmlspecialchars($row['id_combustible']),
                                "nombre" => htmlspecialchars($row['nombre_combustible']),
                            ),
                            "carroceria" => array(
                                "id" => htmlspecialchars($row['id_tipo_carroceria']),
                                "nombre" => htmlspecialchars($row['nombre_tipo_carroceria']),
                            ),
                            "empresa" => array(
                                "id" => htmlspecialchars($row['id_empresa']),
                                "nit" => htmlspecialchars($row['nit']),
                                "nombre" => htmlspecialchars($row['nombre_empresa']),
                            ),
                            "datos_tecnicos" => $responseDatosTecnicos['datos_tecnicos'],
                            "certificado" => $responseCertificado['certificado'],
                            "poliza" => $responsePoliza['poliza'],
                            "preventiva" => $responsePreventiva['preventiva'],
                            "rtm" => $responseRTM['rtm'],
                            "soat" => $responseSoat['soat'],
                            "solicitud" => $responseSolicitud['solicitud'],
                            "tarjeta_operacion" => $responsetTarjetaOperacion['tarjeta_operacion'],
                            "conductor_asignado" => $responseConductor['conductor_asignado'],
                            "autoridad_de_transito" => array(
                                "id" => htmlspecialchars($row['id_autoridad_de_transito']),
                                "nombre" => htmlspecialchars($row['nombre_autoridad_de_transito']),
                            ),
                            "responsable" => htmlspecialchars($row['nombre_usuario'] . " " . $row['apellido_usuario']),
                            "creado" => htmlspecialchars($row['fecha_formulario']),
                        )
                    );

                }

                // var_dump($row['nombre_ciudad']);

                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Vehiculo(s) encontrado(s)',
                    'vehiculo' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}