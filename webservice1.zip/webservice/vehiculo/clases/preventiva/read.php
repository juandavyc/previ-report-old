<?php
class ReadPreventiva
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getPreventiva(
        $_id_vehiculo_
    ) {

        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        $mysqlQuery .= "previ.id_revision_preventiva, ";
        $mysqlQuery .= "previ.numero_revision_preventiva,previ.foto_certificado_preventiva, ";
        $mysqlQuery .= "previ.fecha_expedicion_preventiva,previ.fecha_vencimiento_preventiva, ";
        $mysqlQuery .= "previ.fecha_formulario, ";
        $mysqlQuery .= "luga.id_lugar_preventiva, luga.nombre_lugar_preventiva, ";
        $mysqlQuery .= "usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";
        $mysqlQuery .= "FROM revision_preventiva previ ";
        $mysqlQuery .= "LEFT JOIN lugar_preventiva luga ON previ.id_lugar_preventiva = luga.id_lugar_preventiva ";
        $mysqlQuery .= "LEFT JOIN usuario usu ON usu.id_usuario = previ.id_usuario ";
        $mysqlQuery .= "WHERE previ.id_vehiculo LIKE ? ";
        $mysqlQuery .= "AND previ.is_visible = 1  ";
        $mysqlQuery .= "ORDER BY previ.id_revision_preventiva DESC;";


        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_vehiculo_);

        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {
                    array_push(
                        $mysqlArray,
                        array(
                            "id" => htmlspecialchars($row['id_revision_preventiva']),
                            "numero" => htmlspecialchars($row['numero_revision_preventiva']),
                            "expedicion" => htmlspecialchars($row['fecha_expedicion_preventiva']),
                            "vencimiento" => htmlspecialchars($row['fecha_vencimiento_preventiva']),
                            "archivo" => htmlspecialchars($row['foto_certificado_preventiva']),
                            "lugar" => array(
                                "id" => htmlspecialchars($row['id_lugar_preventiva']),
                                "nombre" => htmlspecialchars($row['nombre_lugar_preventiva']),
                            ),
                            "responsable" => htmlspecialchars($row['nombre_usuario'] . " " . $row['apellido_usuario']),
                            "creado" => htmlspecialchars($row['fecha_formulario']),
                        )
                    );
                }
                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Preventiva(s) encontrado(s)',
                    'preventiva' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}