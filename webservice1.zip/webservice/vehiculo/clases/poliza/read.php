<?php
class ReadPoliza
{


    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getPoliza($_id_vehiculo_)
    {


        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        $mysqlQuery .= "polz.id_poliza,polz.fecha_formulario,polz.numero_poliza, ";
        $mysqlQuery .= "polz.fecha_expedicion_poliza, polz.fecha_vencimiento_polzia, polz.id_tipo_poliza, ";
        $mysqlQuery .= "polz.foto_poliza, ";
        $mysqlQuery .= "asepolz.id_aseguradora_poliza, asepolz.nombre_aseguradora_poliza, ";
        $mysqlQuery .= "tipolz.id_tipo_poliza, tipolz.nombre_tipo_poliza, ";
        $mysqlQuery .= "usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";
        $mysqlQuery .= "FROM poliza polz ";
        $mysqlQuery .= "LEFT JOIN tipo_poliza tipolz ON polz.id_tipo_poliza = tipolz.id_tipo_poliza ";
        $mysqlQuery .= "LEFT JOIN aseguradora_poliza asepolz ON polz.id_aseguradora_poliza = asepolz.id_aseguradora_poliza ";
        $mysqlQuery .= "LEFT JOIN usuario usu ON usu.id_usuario = polz.id_usuario ";
        $mysqlQuery .= "WHERE polz.id_vehiculo LIKE ? ";
        $mysqlQuery .= "AND polz.is_visible = 1 ";
        $mysqlQuery .= "ORDER BY polz.id_poliza DESC; ";

        // echo $mysqlQuery;

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_vehiculo_);
        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {
                    array_push(
                        $mysqlArray,
                        array(
                            "id" => htmlspecialchars($row['id_poliza']),
                            "numero" => htmlspecialchars($row['numero_poliza']),
                            "expedicion" => htmlspecialchars($row['fecha_expedicion_poliza']),
                            "vencimiento" => htmlspecialchars($row['fecha_vencimiento_polzia']),
                            "archivo" => htmlspecialchars($row['foto_poliza']),
                            "tipo" => array(
                                "id" => htmlspecialchars($row['id_tipo_poliza']),
                                "nombre" => htmlspecialchars($row['nombre_tipo_poliza']),
                            ),
                            "aseguradora" => array(
                                "id" => htmlspecialchars($row['id_aseguradora_poliza']),
                                "nombre" => htmlspecialchars($row['nombre_aseguradora_poliza']),
                            ),
                            "responsable" => htmlspecialchars($row['nombre_usuario'] . " " . $row['apellido_usuario']),
                            "creado" => htmlspecialchars($row['fecha_formulario']),
                        )
                    );
                }
                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Poliza(s) encontrado(s)',
                    'poliza' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}