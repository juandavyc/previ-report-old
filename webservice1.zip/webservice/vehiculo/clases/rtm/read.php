<?php
class ReadRTM
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getRTM(
        $_id_vehiculo_
    ) {

        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        # CERTIFICADO
        $mysqlQuery .= "cer.id_certificado_rtm, ";
        $mysqlQuery .= "cer.numero_rtm,cer.foto_certificado_rtm, ";
        $mysqlQuery .= "cer.fecha_expedicion_rtm,cer.fecha_vencimiento_rtm, ";
        $mysqlQuery .= "cer.fecha_formulario, ";
        # CDA
        $mysqlQuery .= "cda.id_cda, cda.nombre_cda, ";
        # USUARIO
        $mysqlQuery .= "usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";

        $mysqlQuery .= "FROM certificado_rtm cer ";
        $mysqlQuery .= "LEFT JOIN cda ON cer.id_cda = cda.id_cda ";
        $mysqlQuery .= "LEFT JOIN usuario usu ON usu.id_usuario = cer.id_usuario ";
        $mysqlQuery .= "WHERE cer.id_vehiculo LIKE ? ";
        $mysqlQuery .= "AND cer.is_visible = 1  ";
        $mysqlQuery .= "ORDER BY cer.id_certificado_rtm DESC ;";

        // echo $mysqlQuery;
        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_vehiculo_);
        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {
                    array_push(
                        $mysqlArray,
                        array(
                            "id" => htmlspecialchars($row['id_certificado_rtm']),
                            "numero" => htmlspecialchars($row['numero_rtm']),
                            "expedicion" => htmlspecialchars($row['fecha_expedicion_rtm']),
                            "vencimiento" => htmlspecialchars($row['fecha_vencimiento_rtm']),
                            "archivo" => htmlspecialchars($row['foto_certificado_rtm']),
                            "cda" => array(
                                "id" => htmlspecialchars($row['id_cda']),
                                "nombre" => htmlspecialchars($row['nombre_cda']),
                            ),
                            "responsable" => htmlspecialchars($row['nombre_usuario'] . " " . $row['apellido_usuario']),
                            "creado" => htmlspecialchars($row['fecha_formulario']),
                        )
                    );
                }
                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'RTM(s) encontrado(s)',
                    'rtm' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}