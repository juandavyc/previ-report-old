<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'GET') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );
    # los obligatorios
    if (
        COUNT($_GET) >= 2 &&
        isset($_GET['acct']) &&
        isset($_GET['vehiculo'])
    ) {

        require '../auth_database.php';
        require '../auth_user.php';

        # usuario esta autorizado
        $_user = htmlspecialchars($_GET['acct']);

        $database = new dbconnection();
        $database->connect();
        if (strcmp($database->status(), "bien") == 0) {

            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            if (strcmp($responseAcct['status'], 'bien') == 0) {

                $_get_vehiculo = htmlspecialchars($_GET['vehiculo']);
                # determina si es por id o placa
                $condicionBusqueda = is_numeric($_GET['vehiculo']) ? 'ID' : 'PLACA';
                # si tiene empresa
                $_get_empresa = htmlspecialchars(isset($_GET['empresa']) ? $_GET['empresa'] : '%%');

                require DOCUMENT_ROOT . '/webservice/vehiculo/clases/vehiculo/read.php';

                $vehiculo = new ReadVehiculo($database->myconn);
                $arrayVehiculo = $vehiculo->getVehiculo(
                    array(
                        'TYPE' => $condicionBusqueda,
                        'VALUE' => $_get_vehiculo,

                    ),
                    '0,1000',
                    $_get_empresa
                );

                # vehiculo ENCONTRADO
                if (strcmp($arrayVehiculo['status'], 'bien') == 0) {
                    //$_array_response();
                    $_array_response = array(
                        'status' => $arrayVehiculo['status'],
                        'message' => $arrayVehiculo['message'],
                        'vehiculo' => $arrayVehiculo['vehiculo'],
                    );
                }
                # vehiculo NO ENCONTRADO
                else {
                    $_array_response = array(
                        'status' => $arrayVehiculo['status'],
                        'message' => $arrayVehiculo['message'],
                    );
                }
            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

            $database->close();
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}