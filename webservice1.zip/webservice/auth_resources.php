<?php

function getspecialdate($_fecha)
{
    return date('Y-m-d', strtotime(str_replace('/', '-', $_fecha)));
}