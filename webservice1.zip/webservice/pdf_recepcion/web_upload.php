<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');

require $_SERVER["DOCUMENT_ROOT"] . '/modulos/assets/php/hoja_private_config.php';
require DOCUMENT_ROOT . '/modulos/assets/php/hdv_resources.php';

# email error
ini_set( 'display_errors', 1 );
error_reporting( E_ALL );

if (
    isset($_FILES['archivo']) &&
    isset($_POST['fecha']) &&
    isset($_POST['correo']) &&
    isset($_POST['placa']) &&
    count($_POST) == 3 &&
    count($_FILES) == 1
) {

    $json_status = "error";
    $json_message = "sin iniciar";
    $_file_name = htmlspecialchars(time() . '_' . clean_file_name($_FILES['archivo']['name']));


    $_date_now = date('d-m-Y');
    $_my_folder_src = 'archivos/previautos/legal/' . $_date_now;
    $_my_folder = DOCUMENT_ROOT . '/' . $_my_folder_src;
    if (!file_exists($_my_folder)) {
        mkdir($_my_folder, 0777, true);
    }

    $_file_src = $_my_folder_src . '/' . $_file_name;

    $_is_moved = move_uploaded_file($_FILES['archivo']['tmp_name'], $_SERVER["DOCUMENT_ROOT"] . '/' . $_my_folder_src . '/' . $_file_name);

    if ($_is_moved) {
        
        $json_message = "archivo subido, ";
        
        $variables = array();

        $variables['placa_vehiculo_email'] = htmlspecialchars($_POST['placa']);
        $variables['fecha_vehiculo_email'] = htmlspecialchars($_POST['fecha']);
        
        $variables['url_pdf_email'] = ROOT."/".$_file_src;
        $variables['url_pdf_email_full_href'] = ROOT."/".$_file_src;
        $variables['url_pdf_email_full_name'] = ROOT."/".$_file_src;
        
        $template = file_get_contents("plantilla.html");
        
        foreach($variables as $key => $value)
        {
            $template = str_replace('{{'.$key.'}}', $value, $template);
        }
        
       
        $from = "informacion@previreport.com"; //
        $to = htmlspecialchars($_POST['correo']);
        $subject = "Clausulado Servicios PREVIAUTOS S.A.S";
        $message = "Términos y condiciones";
        $headers = "MIME-Version: 1.0" . "\r\n"; 
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
        $headers .= "From:" . $from;
        if(mail($to,$subject,$template, $headers)){
            $json_status = "bien";
            $json_message.= "email enviado.";
        }
        else{
            $json_status = "error";
            $json_message.= "email no enviado.";
        }
        
        
    } else {
        
        $json_status = "error";
        $json_message = "No se pudo subir el archivo, intente de nuevo";
    }


    echo json_encode(array(
        'status' =>  $json_status,
        'message' => $json_message,
    ), JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}