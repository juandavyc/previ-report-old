<?php
   
    
    /*$variables = array();

    $variables['placa_vehiculo_email'] = "ABC123";
    $variables['fecha_vehiculo_email'] = "20/12/2022";
    
    $variables['url_pdf_email'] = "https://previreport.com/archivos/previautos/terminos/1234354343_ABC123.pdf";
    $variables['url_pdf_email_full_href'] = "https://previreport.com/archivos/previautos/terminos/1234354343_ABC123.pdf";
    $variables['url_pdf_email_full_name'] = "https://previreport.com/archivos/previautos/terminos/1234354343_ABC123.pdf";
    
    $template = file_get_contents("plantilla.html");
    
    foreach($variables as $key => $value)
    {
        $template = str_replace('{{'.$key.'}}', $value, $template);
    }
    
    ini_set( 'display_errors', 1 );
    error_reporting( E_ALL );
    $from = "informacion@previreport.com"; //
    $to = "davidy0090011@gmail.com,deivides1@gmail.com,jadevia360@gmail.com";
    $subject = "Checking PHP mail";
    $message = "PHP mail works just fine";
    $headers = "MIME-Version: 1.0" . "\r\n"; 
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
    $headers .= "From:" . $from;
    mail($to,$subject,$template, $headers);
    echo "The email message was sent.";*/
?>