<?php
class ReadPreoperacional
{
    private $databaseConnection = null;

    private $arrayResponse = array();
    private $arrayUsuarios = array();
    private $arrayContador = 0;

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }

    public function getPreoperacional(
        $_condicional_ = array(
            'TYPE' => 'ID',
            'VALUE' => 1,
            'LIMITE' => '0',
        )
    ) {

        // var_dump($_condicional_);

        $_preoperacional_default = array(
            0 => array(
                'id' => 0,
            )

        );

        $arrayCondicional = array(
            'ID' => 'preo.id_preoperacional',
            'ID_VEHICULO' => 'preo.id_vehiculo',
            'PLACA_VEHICULO' => 'vehi.placa_vehiculo',
        );

        //$arrayCondicional = $arrayCondicional[];
        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        #tabla empresa
        $mysqlQuery .= "empr.id_empresa,empr.nit,empr.nombre_empresa, ";

        $mysqlQuery .= "preo.id_preoperacional, ";
        $mysqlQuery .= "preo.tarjeta_propiedad_vigencia,preo.tarjeta_propiedad_entidad,preo.tarjeta_propiedad_fecha, ";
        $mysqlQuery .= "preo.revision_rtm_vigencia, preo.revision_rtm_fecha, preo.revision_rtm_entidad, ";
        $mysqlQuery .= "preo.certificado_gases_vigencia, preo.certificado_gases_fecha, preo.certificado_gases_entidad, ";
        $mysqlQuery .= "preo.planilla_fuec_vigencia, preo.planilla_fuec_entidad, preo.planilla_fuec_fecha, ";
        $mysqlQuery .= "preo.licencia_conduccion_vigencia, preo.licencia_conduccion_fecha, preo.licencia_conduccion_entidad, ";
        $mysqlQuery .= "preo.poliza_vigencia, preo.poliza_fecha, preo.poliza_entidad, ";
        $mysqlQuery .= "preo.poliza_soat_vigencia, preo.poliza_soat_fecha, preo.poliza_soat_entidad, ";
        $mysqlQuery .= "preo.firma_usuario_autoriza,preo.firma_usuario_realiza, ";
        $mysqlQuery .= "preo.observaciones_usuario_autoriza,preo.observaciones_usuario_realiza, ";
        $mysqlQuery .= "preo.foto_vehiculo_uno,preo.foto_vehiculo_dos,preo.fecha_formulario, preo.datos_preoperacional, ";

        #tabla estado (resultado)
        $mysqlQuery .= "esta.id_estado_preoperacional,esta.nombre_estado_preoperacional, ";
        #tabla usuario # realiza
        $mysqlQuery .= "usur.id_usuario As id_usuario_realiza, CONCAT(usur.nombre_usuario,' ',usur.apellido_usuario) As nombre_usuario_realiza, ";
        #tabla usuario # autoriza
        $mysqlQuery .= "usua.id_usuario As id_usuario_autoriza, CONCAT(usua.nombre_usuario,' ',usua.apellido_usuario) As nombre_usuario_autoriza, ";
        #tabla # VEHICULO
        $mysqlQuery .= "vehi.id_vehiculo, vehi.placa_vehiculo ";

        ## FROM ##
        $mysqlQuery .= "FROM ";
        $mysqlQuery .= "preoperacional preo ";
        #JOIN
        $mysqlQuery .= "INNER JOIN vehiculo vehi ON vehi.id_vehiculo = preo.id_vehiculo ";
        $mysqlQuery .= "LEFT JOIN empresa empr ON empr.id_empresa = preo.id_empresa ";
        $mysqlQuery .= "LEFT JOIN estado_preoperacional esta ON esta.id_estado_preoperacional = preo.id_estado_preoperacional ";
        $mysqlQuery .= "LEFT JOIN usuario usur ON usur.id_usuario = preo.id_usuario_realiza ";
        $mysqlQuery .= "LEFT JOIN usuario usua ON usua.id_usuario = preo.id_usuario_autoriza ";
        #Condicion
        $mysqlQuery .= "WHERE ";
        $mysqlQuery .= $arrayCondicional[$_condicional_['TYPE']] . " LIKE ? ";
        #Ordenamiento
        $mysqlQuery .= "ORDER BY preo.id_preoperacional DESC LIMIT " . $_condicional_['LIMITE'] . "; ";

        // echo $mysqlQuery;

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_condicional_['VALUE']);
        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();

            // var_dump($mysqlResult);

            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {
                    array_push(
                        $mysqlArray,
                        array(
                            "id" => htmlspecialchars($row['id_preoperacional']),
                            // is_vigente
                            'vencimientos' => array(
                                'tarjeta_de_propiedad' => array(
                                    'vigencia' => htmlspecialchars($row['tarjeta_propiedad_vigencia']),
                                    'entidad_expide' => htmlspecialchars($row['tarjeta_propiedad_entidad']),
                                    'fecha_vencimiento' => htmlspecialchars($row['tarjeta_propiedad_fecha']),
                                ),
                                'revision_tecnicomecanica' => array(
                                    'vigencia' => htmlspecialchars($row['revision_rtm_vigencia']),
                                    'entidad_expide' => htmlspecialchars($row['revision_rtm_entidad']),
                                    'fecha_vencimiento' => htmlspecialchars($row['revision_rtm_fecha']),
                                ),
                                'gases' => array(
                                    'vigencia' => htmlspecialchars($row['certificado_gases_vigencia']),
                                    'entidad_expide' => htmlspecialchars($row['certificado_gases_entidad']),
                                    'fecha_vencimiento' => htmlspecialchars($row['certificado_gases_fecha']),
                                ),
                                'fuec' => array(
                                    'vigencia' => htmlspecialchars($row['planilla_fuec_vigencia']),
                                    'entidad_expide' => htmlspecialchars($row['planilla_fuec_entidad']),
                                    'fecha_vencimiento' => htmlspecialchars($row['planilla_fuec_fecha']),
                                ),
                                'licencia' => array(
                                    'vigencia' => htmlspecialchars($row['licencia_conduccion_vigencia']),
                                    'entidad_expide' => htmlspecialchars($row['licencia_conduccion_entidad']),
                                    'fecha_vencimiento' => htmlspecialchars($row['licencia_conduccion_fecha']),
                                ),
                                'poliza' => array(
                                    'vigencia' => htmlspecialchars($row['poliza_vigencia']),
                                    'entidad_expide' => htmlspecialchars($row['poliza_entidad']),
                                    'fecha_vencimiento' => htmlspecialchars($row['poliza_fecha']),
                                ),
                                'soat' => array(
                                    'vigencia' => htmlspecialchars($row['poliza_soat_vigencia']),
                                    'entidad_expide' => htmlspecialchars($row['poliza_soat_entidad']),
                                    'fecha_vencimiento' => htmlspecialchars($row['poliza_soat_fecha']),
                                ),
                            ),
                            // usuario autoriza
                            "autoriza" => array(
                                "id" => htmlspecialchars($row['id_usuario_autoriza']),
                                "nombre" => htmlspecialchars($row['nombre_usuario_autoriza']),
                                "firma" => htmlspecialchars($row['firma_usuario_autoriza']),
                                "observaciones" => htmlspecialchars($row['observaciones_usuario_autoriza']),
                            ),
                            // usuario realiza
                            "realiza" => array(
                                "id" => htmlspecialchars($row['id_usuario_realiza']),
                                "nombre" => htmlspecialchars($row['nombre_usuario_realiza']),
                                "firma" => htmlspecialchars($row['firma_usuario_realiza']),
                                "observaciones" => htmlspecialchars($row['observaciones_usuario_realiza']),
                            ),
                            // fotos
                            "foto_uno" => htmlspecialchars($row['foto_vehiculo_uno']),
                            "foto_dos" => htmlspecialchars($row['foto_vehiculo_dos']),
                            // estado (resultado)
                            "estado" => array(
                                "id" => htmlspecialchars($row['id_estado_preoperacional']),
                                "nombre" => htmlspecialchars($row['nombre_estado_preoperacional']),
                            ),
                            "vehiculo" => array(
                                "id" => htmlspecialchars($row['id_vehiculo']),
                                "placa" => htmlspecialchars($row['placa_vehiculo']),
                            ),
                            // formulario
                            "fecha" => htmlspecialchars($row['fecha_formulario']),
                            "datos_preoperacional" => json_decode($row['datos_preoperacional']),
                        )
                    );
                }

                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Resultados encontrados',
                    'preoperacional' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                    'preoperacional' => $_preoperacional_default,
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }

}