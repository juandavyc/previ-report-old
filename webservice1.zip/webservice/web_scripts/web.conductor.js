
const $tabs = $('#tab-visor');
$tabs.responsiveTabs({
    rotate: false,
    startCollapsed: 'accordion',
    collapsible: 'accordion',
    setHash: false,
});
$tabs.responsiveTabs('activate', 0);

const formCrearConductor = document.getElementById('form_2_crear_conductor');
const formCrearRespuestaConductor = document.getElementById('form_1_crear_respuesta');

const formCrearConductorSubmit = (e) => {

    fetch(PROTOCOL_HOST + '/webservice/conductor/create.php',{
        method: "post",
        body: new FormData(formCrearConductor),
    })
        .then((response) => response.text())
        .then((text) => {
            console.log(text);
            formCrearRespuestaConductor.textContent = text;
        })
        .catch(function (err) {
            console.log(err);
        });

        e.preventDefault();
}

formCrearConductor.addEventListener('submit', formCrearConductorSubmit);

const form2Respuesta = document.getElementById("");

document.getElementById("form_get").addEventListener("click", function (e){

    fetch(document.getElementById("form_url").value)
        .then((response) => response.text())
        .then((text) => {
            // console.log(text);
            document.getElementById("form_respuesta").value = text;
        });
    e.preventDefault();
},false)