const $tabs = $('#tab-visor');
$tabs.responsiveTabs({
  rotate: false,
  startCollapsed: 'accordion',
  collapsible: 'accordion',
  setHash: false,
});
$tabs.responsiveTabs('activate', 1);

const formClase = document.getElementById('form_2_subir');
const formRespuestaClase = document.getElementById('form_2_respuesta');

const formSubirBase64Clase = (e) => {
  fetch(PROTOCOL_HOST + '/webservice/web_html/base64/form.php', {
    method: 'post',
    body: new FormData(formClase),
  })
    .then((r) => r.json().then((data) => ({ status: r.status, body: data })))
    .then((obj) => {
      console.log(obj);
      formRespuestaClase.textContent =
        'status:: ' + obj.body.status + ' :: url :: ' + obj.body.message;
    })
    .catch(function (err) {
      console.log(err);
    });

  e.preventDefault();
};

formClase.addEventListener('submit', formSubirBase64Clase);

const formSubir = document.getElementById('form_1_subir');
const formRespuesta = document.getElementById('form_1_respuesta');

const formSubirBase64 = (e) => {
  fetch(PROTOCOL_HOST + '/webservice/uploader/base64.php', {
    method: 'post',
    body: new FormData(formSubir),
  })
    .then((r) => r.json().then((data) => ({ status: r.status, body: data })))
    .then((obj) => {
      console.log(obj);
      formRespuesta.textContent =
        'status:: ' + obj.body.status + ' :: url :: ' + obj.body.message;
    })
    .catch(function (err) {
      console.log(err);
    });

  e.preventDefault();
};

formSubir.addEventListener('submit', formSubirBase64);
