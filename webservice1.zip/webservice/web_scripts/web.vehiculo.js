// tabs

const $tabs = $('#tab-visor');
$tabs.responsiveTabs({
    rotate: false,
    startCollapsed: 'accordion',
    collapsible: 'accordion',
    setHash: false,
});
$tabs.responsiveTabs('activate', 0);

// formulario # 1 
const formCrear = document.getElementById('form_1_crear');
const formCrearRespuesta = document.getElementById('form_1_crear_respuesta');

const formCrearSubmit = (event) => {

    fetch(PROTOCOL_HOST + '/webservice/vehiculo/create.php', {
        method: 'post',
        body: new FormData(formCrear),
    })
        .then((response) => response.text())
        .then((text) => {
            console.log(text);
            formCrearRespuesta.textContent = text;
        });

    event.preventDefault();
}

formCrear.addEventListener('submit', formCrearSubmit);

// formuario # 2
const form2Respuesta = document.getElementById("");

document.getElementById("form_2_get_0").addEventListener("click", function (event) {
    fetch(document.getElementById("form_2_url_0").value)
        .then((response) => response.text())
        .then((text) => {
            console.log(text);
            document.getElementById("form_2_respuesta").value = text;
        });
    event.preventDefault();
}, false);

document.getElementById("form_2_get_1").addEventListener("click", function (event) {
    fetch(document.getElementById("form_2_url_1").value)
        .then((response) => response.text())
        .then((text) => {
            console.log(text);
            document.getElementById("form_2_respuesta").value = text;
        });

    event.preventDefault();
}, false);