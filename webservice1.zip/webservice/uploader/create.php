<?php
class CreateBase64
{
    private $user = 'sin_usuario';

    // usuario que sube la imagen nombre o id
    public function __construct($_usuario)
    {
        $this->user = $_usuario;
    }

    public function setBase64(
        $_base64 = '',
        $_folder = ''
    ) {
        $imageBase64 = $_base64;
        $folder = $_folder;
        $name = $this->user . '_' . time();
        //Elimina data:image/png;base64
        $imageBase64 = str_replace('data:image/png;base64,', '', $imageBase64);
        //Remplaza los espacios por un +
        $imageBase64 = str_replace(' ', '+', $imageBase64);
        //Decodifica el base64
        $php_data = base64_decode($imageBase64);
        // Ruta y nombre
        $php_archivo = DOCUMENT_ROOT . '/images/' . $folder . '/' . $name . '.png';
        // Subir la foto
        $php_success = file_put_contents($php_archivo, $php_data);
        // La imagen subio al seridor
        if ($php_success) {

            $this->arrayResponse = array(
                'status' => 'bien',
                'message' => '/images/' . $folder . '/' . $name . '.png',

            );
        } else {

            $this->arrayResponse = array(
                'status' => 'error_al_guardar',
                'message' => '/images/image_error.png',
            );
        }

        return $this->arrayResponse;
    }
}