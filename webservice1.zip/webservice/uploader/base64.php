<?php
header('Content-Type: application/json');
// configuracion
require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';

// INFLAVERGAS

$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'POST') == 0) {

    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );
    if (
        isset($_POST['acct']) &&
        isset($_POST['base64']) &&
        COUNT($_POST) == 2
    ) {
        require '../auth_database.php';
        require '../auth_user.php';

        $_user = htmlspecialchars($_POST['acct']);

        $database = new dbconnection();
        $database->connect();

        if (strcmp($database->status(), "bien") == 0) {

            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            if (strcmp($responseAcct['status'], 'bien') == 0) {
                // create image
                $imageBase64 = $_POST['base64'];
                $folder = 'webservice';
                $name = $_user . '_' . time();
                $json_image_src = "";
                //Elimina data:image/png;base64
                $imageBase64 = str_replace('data:image/png;base64,', '', $imageBase64);
                //Remplaza los espacios por un +
                $imageBase64 = str_replace(' ', '+', $imageBase64);
                //Decodifica el base64
                $php_data = base64_decode($imageBase64);
                // Ruta y nombre
                $php_archivo = DOCUMENT_ROOT . '/images/' . $folder . '/' . $name . '.png';
                // Subir la foto
                $php_success = file_put_contents($php_archivo, $php_data);
                // La imagen subio al seridor
                if ($php_success) {
                    $json_image_src = '/images/' . $folder . '/' . $name . '.png';

                    $_array_response = array(
                        'status' => 'bien',
                        'message' => $json_image_src,

                    );
                } else {

                    $_array_response = array(
                        'status' => 'error_al_guardar',
                        'message' => '/images/image_error.png',
                    );
                }

            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }
            $database->close();
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }
    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}