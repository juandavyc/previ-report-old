<!DOCTYPE HTML>
<html>

<head>
    <title>Web Service - base64</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="shortcut icon" type="image/jpg" href="../images/favicon.png" />
    <link rel="stylesheet" href="../assets/css/main.css" />
    <noscript>
        <link rel="stylesheet" href="assets/css/noscript.css" />
    </noscript>

</head>

<body>
    <div id="page-wrapper">
        <div class="container-loader">
            <div class="loader">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
            <h3><b>CARGANDO</b><br>Por favor espere</h3>
        </div>
        <header id="header">
            <h1 id="logo"><a href="../" class="icon solid fa-flag"> PreviReport <span>v 1.0</span></a></h1>
            <nav id="nav">
                <ul>
                    <li id="menu-inicio">
                        <a href="../">Inicio</a>
                    </li>
                    <li class="submenu" id="menu-web">
                        <a href="#">Web Service</a>
                        <ul>
                            <li><a href="web_vehiculo.php">Vehiculos</a></li>
                            <li><a href="web_conductor.php">Conductores</a></li>
                            <li><a href="web_base64.php"> Base64</a></li>
                        </ul>
                    </li>
            </nav>
        </header>
        <article id="main">
            <header class="special container">
                <span class="icon solid fas fa-handshake"></span>
                <h2>Web service base64</h2>
            </header>
            <div id="tab-visor">
                <ul>
                    <li><a href="#tab-0" class="icon solid fa-plus"> Crear </a></li>
                    <li><a href="#tab-1" class="icon solid fa-plus"> Clase </a></li>
                </ul>
                <div id="tab-0">
                    <?php require 'web_html/base64/crear.php';?>
                </div>
                <div id="tab-1">
                    <?php require 'web_html/base64/clase.php';?>
                </div>
            </div>
        </article>
        <footer id="footer">
            <ul class="icons">
                <li><a href="#" class="icon brands circle fa-twitter"><span class="label">Twitter</span></a></li>
                <li><a href="#" class="icon brands circle fa-facebook-f"><span class="label">Facebook</span></a></li>
                <li><a href="#" class="icon brands circle fa-github"><span class="label">Github</span></a></li>
                <li><a href="#" class="icon brands circle fa-dribbble"><span class="label">Dribbble</span></a></li>
            </ul>
            <ul class="copyright">
                <li>&copy; PREVIREPORT</li>
                <li>Design: <a href="https://jash.com.co/">J.A.S.H.</a></li>
            </ul>
        </footer>
    </div>

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/jquery.dropotron.min.js"></script>
    <script src="../assets/js/jquery.scrolly.min.js"></script>
    <script src="../assets/js/jquery.scrollex.min.js"></script>
    <script src="../assets/js/browser.min.js"></script>
    <script src="../assets/js/breakpoints.min.js"></script>
    <script src="../assets/js/util.js"></script>
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/jquery.tabs.js"></script>
    <script src="web_scripts/web.base64.js"></script>
    <script>

    </script>
</body>

</html>