<?php
// var_dump($_POST);
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'POST') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );

    if (
        isset($_POST["tipo"]) &&
        isset($_POST["fecha"]) &&
        isset($_POST["hora"]) &&
        isset($_POST["ciudad"]) &&
        isset($_POST["direccion"]) &&
        isset($_POST["heridos"]) &&
        isset($_POST["muertos"]) &&
        isset($_POST["implicados"]) &&
        isset($_POST["descripcion"]) &&
        isset($_POST["foto_1"]) &&
        isset($_POST["foto_2"]) &&
        isset($_POST["foto_3"]) &&
        isset($_POST["foto_4"]) &&
        isset($_POST["firma"]) &&
        isset($_POST["id"]) &&
        isset($_POST["acct"]) &&
        count($_POST) == 16
    ) {

        require DOCUMENT_ROOT . '/webservice/auth_resources.php';
        //db

        require DOCUMENT_ROOT . '/webservice/auth_database.php';
        require DOCUMENT_ROOT . '/webservice/auth_user.php';

        // photo64
        require DOCUMENT_ROOT . '/webservice/uploader/create.php';

        $database = new dbconnection();
        $database->connect();

        if (strcmp($database->status(), "bien") == 0) {

            $_user = htmlspecialchars($_POST['acct']);

            //user verify
            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);
            $_id_usuario = ($responseAcct['id_user']);

            // si existe el usuario
            if (strcmp($responseAcct['status'], 'bien') == 0) {

                // clase photo
                $base64 = new CreateBase64($_id_usuario);

                $responseFoto1 = $base64->setBase64($_POST["foto_1"], 'siniestro/foto');
                $responseFoto2 = $base64->setBase64($_POST["foto_2"], 'siniestro/foto');
                $responseFoto3 = $base64->setBase64($_POST["foto_3"], 'siniestro/foto');
                $responseFoto4 = $base64->setBase64($_POST["foto_4"], 'siniestro/foto');
                $responseFirma = $base64->setBase64($_POST["firma"], 'siniestro/firma');

                require DOCUMENT_ROOT . '/webservice/siniestro/clases/siniestro/update.php';

                $siniestro = new UpdateSiniestro($database->myconn);

                $arrayResponse = $siniestro->setInformacionSiniestro(
                    array(
                        'ID' => $_POST["id"],
                        'ID_TIPO' => $_POST["tipo"],
                        'FECHA' => getspecialdate($_POST["fecha"]),
                        'HORA' => $_POST["hora"],
                        'CIUDAD' => $_POST["ciudad"],
                        'DIRECCION' => htmlspecialchars($_POST["direccion"]),
                        'HERIDOS' => $_POST["heridos"],
                        'MUERTOS' => $_POST["muertos"],
                        'VEHICULOS' => $_POST["implicados"],
                        'DESCRIPCION' => htmlspecialchars($_POST["descripcion"]),
                        'FOTO_1' => $responseFoto1['message'],
                        'FOTO_2' => $responseFoto2['message'],
                        'FOTO_3' => $responseFoto3['message'],
                        'FOTO_4' => $responseFoto4['message'],
                        'FIRMA' => $responseFirma['message'],
                        'ID_USUARIO' => $_id_usuario,
                    )
                );

                if ($arrayResponse['status'] == 'bien') {

                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );

                } else {
                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );
                }

                $database->close();

            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'Error',
            'message' => 'Formulario Incompleto',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}