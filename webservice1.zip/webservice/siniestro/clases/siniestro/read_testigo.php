<?php
// echo "dsadasd";
class ReadTestigo
{

    private $databaseConnection = null;
    private $arrayResponse = array();

    public function __construct($_database_)
    {
        // var_dump($_database_);
        $this->databaseConnection = $_database_;
    }

    public function getTestigo(
        $_id_siniestro_ = 0
    ) {
        $_siniestro_default = array(
            0 => 'SIN RESULTADOS',
        );

        $arrayImplicados = array();

        $mysqlQuery = 'SELECT ';
        $mysqlQuery .= 'id_testigo_siniestro, nombre_testigo_siniestro, telefono_testigo_siniestro, correo_testigo_siniestro, ';
        $mysqlQuery .= 'direccion_testigo_siniestro ';
        $mysqlQuery .= 'FROM testigo_siniestro ';
        $mysqlQuery .= 'WHERE id_siniestro LIKE ? ORDER BY id_testigo_siniestro DESC;';

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_siniestro_);

        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {

                    array_push(
                        $arrayImplicados,
                        array(
                            'id' => ($row['id_testigo_siniestro']),
                            'nombre' => htmlspecialchars($row['nombre_testigo_siniestro']),
                            'telefono' => htmlspecialchars($row['telefono_testigo_siniestro']),
                            'correo' => htmlspecialchars($row['correo_testigo_siniestro']),
                            'direccion' => htmlspecialchars($row['direccion_testigo_siniestro']),
                        )
                    );
                }

                $this->arrayResponse = $arrayImplicados;

            } else {
                $this->arrayResponse = $_siniestro_default;
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}