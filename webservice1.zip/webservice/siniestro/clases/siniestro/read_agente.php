<?php
// echo "dsadasd";
class ReadAgente
{

    private $databaseConnection = null;
    private $arrayResponse = array();

    public function __construct($_database_)
    {
        // var_dump($_database_);
        $this->databaseConnection = $_database_;
    }

    public function getAgente(
        $_id_siniestro_ = 0
    ) {
        $_siniestro_default = array(
            0 => 'SIN RESULTADOS',
        );

        $arrayImplicados = array();

        $mysqlQuery = 'SELECT ';
        $mysqlQuery .= 'id_agente_transito, nombre_agente_transito, telefono_agente_transito, correo_agente_transito ';
        $mysqlQuery .= 'FROM agente_transito ';
        $mysqlQuery .= 'WHERE id_siniestro LIKE ? ORDER BY id_agente_transito DESC;';

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_siniestro_);

        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {

                    array_push(
                        $arrayImplicados,
                        array(
                            'id' => ($row['id_agente_transito']),
                            'nombre' => htmlspecialchars($row['nombre_agente_transito']),
                            'telefono' => htmlspecialchars($row['telefono_agente_transito']),
                            'correo' => htmlspecialchars($row['correo_agente_transito']),
                        )
                    );
                }

                $this->arrayResponse = $arrayImplicados;

            } else {
                $this->arrayResponse = $_siniestro_default;
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}