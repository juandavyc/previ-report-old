<?php
// echo "dsadasd";
class ReadImplicado
{

    private $databaseConnection = null;
    private $arrayResponse = array();

    public function __construct($_database_)
    {
        // var_dump($_database_);
        $this->databaseConnection = $_database_;
    }

    public function getImplicados(
        $_id_siniestro_ = 0
    ) {
        $_siniestro_default = array(
            0 => 'SIN RESULTADOS',
        );

        $arrayImplicados = array();

        $mysqlQuery = 'SELECT ';
        $mysqlQuery .= 'id_implicado_siniestro, placa_vehiculo_implicado, marca_implicado, modelo_vehiculo_implicado, telefono_implicado, ';
        $mysqlQuery .= 'correo_implicado, direccion_implicado, aseguradora_implicado, telefono_aseguradora_implicado, tipo_poliza_implicado, aseguradora_poliza_implicado, ';
        $mysqlQuery .= 'fecha_expedicion_poliza_implicado, fecha_vencimiento_poliza_implicado ';
        $mysqlQuery .= 'FROM vehiculo_implicado_siniestro ';
        $mysqlQuery .= 'WHERE id_siniestro LIKE ? ORDER BY id_implicado_siniestro DESC;';

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_siniestro_);

        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {

                    array_push(
                        $arrayImplicados,
                        array(
                            'id' => ($row['id_implicado_siniestro']),
                            'placa' => htmlspecialchars($row['placa_vehiculo_implicado']),
                            'marca' => htmlspecialchars($row['marca_implicado']),
                            'modelo' => htmlspecialchars($row['modelo_vehiculo_implicado']),
                            'telefono' => htmlspecialchars($row['telefono_implicado']),
                            'correo' => htmlspecialchars($row['correo_implicado']),
                            'direccion' => htmlspecialchars($row['direccion_implicado']),
                            'aseguradora' => htmlspecialchars($row['aseguradora_implicado']),
                            'telefono_aseguradora' => htmlspecialchars($row['telefono_aseguradora_implicado']),
                            'tipo_poliza' => htmlspecialchars($row['tipo_poliza_implicado']),
                            'aseguradora_poliza' => htmlspecialchars($row['aseguradora_poliza_implicado']),
                            'fecha_expedicion_poliza' => htmlspecialchars($row['fecha_expedicion_poliza_implicado']),
                            'fecha_vencimiento_poliza' => htmlspecialchars($row['fecha_vencimiento_poliza_implicado']),
                        )
                    );
                }

                $this->arrayResponse = $arrayImplicados;

            } else {
                $this->arrayResponse = $_siniestro_default;

            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}