<?php

class UpdateSiniestro
{
    private $databaseConnection = null;
    private $arrayResponse = array();

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }

    public function setInformacionSiniestro(
        $_datos_ = array(
            'ID' => 1,
            'ID_TIPO' => 1,
            'FECHA' => '2999-01-01',
            'HORA' => '00:00:01',
            'CIUDAD' => 1,
            'DIRECCION' => '',
            'HERIDOS' => 2,
            'MUERTOS' => 2,
            'VEHICULOS' => 2,
            'DESCRIPCION' => '...',
            'FOTO_1' => '/images/sin_firma.png',
            'FOTO_2' => '/images/sin_firma.png',
            'FOTO_3' => '/images/sin_firma.png',
            'FOTO_4' => '/images/sin_firma.png',
            'FIRMA' => '/images/sin_firma.png',
            'ID_USUARIO' => 1,
        )
    ) {

        $mysqlQuery = "UPDATE ";
        $mysqlQuery .= "siniestro ";
        $mysqlQuery .= "SET ";
        $mysqlQuery .= "id_tipo_siniestro = ?,fecha_siniestro = ?, ";
        $mysqlQuery .= "hora_siniestro = ?,direccion_siniestro = ?, ";
        $mysqlQuery .= "id_ciudad = ?,heridos_siniestro = ?, ";
        $mysqlQuery .= "muertos_siniestro = ?,vehiculos_implicados_siniestro = ?, ";
        $mysqlQuery .= "descripcion_siniestro = ?,firma_siniestro = ?, ";
        $mysqlQuery .= "foto_1_siniestro = ?,foto_2_siniestro = ?, ";
        $mysqlQuery .= "foto_3_siniestro = ?,foto_4_siniestro = ?, ";
        $mysqlQuery .= "id_usuario = ? ";
        $mysqlQuery .= "WHERE ";
        $mysqlQuery .= "id_siniestro = ?;";

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param(
            'isssiiiissssssii',
            $_datos_['ID_TIPO'],
            $_datos_['FECHA'],
            $_datos_['HORA'],
            $_datos_['DIRECCION'],
            $_datos_['CIUDAD'],
            $_datos_['HERIDOS'],
            $_datos_['MUERTOS'],
            $_datos_['VEHICULOS'],
            $_datos_['DESCRIPCION'],
            $_datos_['FIRMA'],
            $_datos_['FOTO_1'],
            $_datos_['FOTO_2'],
            $_datos_['FOTO_3'],
            $_datos_['FOTO_4'],
            $_datos_['ID_USUARIO'],
            $_datos_['ID']
        );

        if ($mysqlStmt->execute()) {
            $mysqlStmt->close();
            $this->arrayResponse = array(
                'status' => 'bien',
                'message' => 'Información del Siniestro Guardada',
            );
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta 1 : ' . htmlspecialchars($mysqlStmt->error),
            );
        }
        return $this->arrayResponse;
    }
    public function setAgenteSiniestro(
        $_datos_ = array(
            'ID_SINIESTRO' => 1,
            'NOMBRE' => 'SIN_NOMBRE',
            'TELEFONO' => 'sin_telefono',
            'CORREO' => 'sin@correo.com',
            'ID_USUARIO' => 1,
        )
    ) {

        $mysqlQuery = "CALL proc_siniestro_agente ";
        $mysqlQuery .= "(?,?,?,?,?,@respuesta); ";

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param(
            'sssii',
            $_datos_['NOMBRE'],
            $_datos_['TELEFONO'],
            $_datos_['CORREO'],
            $_datos_['ID_SINIESTRO'],
            $_datos_['ID_USUARIO'],
        );

        if ($mysqlStmt->execute()) {
            $mysqlStmt->close();

            $mysqlQuery = "SELECT @respuesta As JSON_PROC; ";
            $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
            if ($mysqlStmt->execute()) {

                $mysqlResult = $mysqlStmt->get_result();
                $row = $mysqlResult->fetch_assoc();
                $mysqlDecode = json_decode($row['JSON_PROC']);

                $mysqlStmt->close();

                $this->arrayResponse = array(
                    'status' => $mysqlDecode[0],
                    'message' => $mysqlDecode[1],
                    'id' => isset($mysqlDecode[2]) ? $mysqlDecode[2] : '',
                    'nombre' => isset($mysqlDecode[3]) ? $mysqlDecode[3] : '',
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'error',
                    'message' => 'Error en la consulta #2 : ' . htmlspecialchars($mysqlStmt->error),
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta #1 : ' . htmlspecialchars($mysqlStmt->error),
            );
        }
        return $this->arrayResponse;
    }

    public function setTestigoSiniestro(
        $_datos_ = array(
            'ID_SINIESTRO' => 1,
            'NOMBRE' => '',
            'TELEFONO' => '',
            'CORREO' => '',
            'DIRECCION' => '',
            'ID_USUARIO' => 1,
        )
    ) {

        $mysqlQuery = "CALL proc_siniestro_testigo ";
        $mysqlQuery .= "(?,?,?,?,?,?,@respuesta); ";

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param(
            'ssssii',
            $_datos_['NOMBRE'],
            $_datos_['TELEFONO'],
            $_datos_['CORREO'],
            $_datos_['DIRECCION'],
            $_datos_['ID_SINIESTRO'],
            $_datos_['ID_USUARIO'],
        );

        if ($mysqlStmt->execute()) {
            $mysqlStmt->close();

            $mysqlQuery = "SELECT @respuesta As JSON_PROC; ";
            $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
            if ($mysqlStmt->execute()) {

                $mysqlResult = $mysqlStmt->get_result();
                $row = $mysqlResult->fetch_assoc();
                $mysqlDecode = json_decode($row['JSON_PROC']);

                $mysqlStmt->close();

                $this->arrayResponse = array(
                    'status' => $mysqlDecode[0],
                    'message' => $mysqlDecode[1],
                    'id' => isset($mysqlDecode[2]) ? $mysqlDecode[2] : '',
                    'nombre' => isset($mysqlDecode[3]) ? $mysqlDecode[3] : '',
                );

            } else {
                $this->arrayResponse = array(
                    'status' => 'error',
                    'message' => 'Error en la consulta #2 : ' . htmlspecialchars($mysqlStmt->error),
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta #1 : ' . htmlspecialchars($mysqlStmt->error),
            );
        }
        return $this->arrayResponse;
    }

    public function setImplicadoSiniestro(
        $_datos_ = array(
            'PLACA' => '',
            'MARCA' => 1,
            'MODELO' => '2999',
            'CONDUCTOR' => '',
            'TELEFONO' => '',
            'CORREO' => '',
            'DIRECCION' => '',
            'ASEGURADORA' => '',
            'ASEGURADORA_TELEFONO' => '',
            'POLIZA' => '',
            'POLIZA_ASEGURADORA' => '',
            'FECHA_EXPEDICION' => '2999-01-01',
            'FECHA_VENCIMIENTO' => '2999-01-01',
            'ID_SINIESTRO' => 1,
            'ID_USUARIO' => 1,
        )
    ) {

        $mysqlQuery = "CALL proc_siniestro_vehiculo_implicado ";
        $mysqlQuery .= "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,@respuesta); ";

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param(
            'sssssssssssssii',
            $_datos_['PLACA'],
            $_datos_['MARCA'],
            $_datos_['MODELO'],
            $_datos_['CONDUCTOR'],
            $_datos_['TELEFONO'],
            $_datos_['CORREO'],
            $_datos_['DIRECCION'],
            $_datos_['ASEGURADORA'],
            $_datos_['ASEGURADORA_TELEFONO'],
            $_datos_['POLIZA'],
            $_datos_['POLIZA_ASEGURADORA'],
            $_datos_['FECHA_EXPEDICION'],
            $_datos_['FECHA_VENCIMIENTO'],
            $_datos_['ID_SINIESTRO'],
            $_datos_['ID_USUARIO'],
        );

        if ($mysqlStmt->execute()) {
            $mysqlStmt->close();

            $mysqlQuery = "SELECT @respuesta As JSON_PROC; ";
            $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
            if ($mysqlStmt->execute()) {

                $mysqlResult = $mysqlStmt->get_result();
                $row = $mysqlResult->fetch_assoc();
                $mysqlDecode = json_decode($row['JSON_PROC']);

                $mysqlStmt->close();

                $this->arrayResponse = array(
                    'status' => $mysqlDecode[0],
                    'message' => $mysqlDecode[1],
                    'id' => isset($mysqlDecode[2]) ? $mysqlDecode[2] : '',
                    'nombre' => isset($mysqlDecode[3]) ? $mysqlDecode[3] : '',
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'error',
                    'message' => 'Error en la consulta #2 : ' . htmlspecialchars($mysqlStmt->error),
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta #1 : ' . htmlspecialchars($mysqlStmt->error),
            );
        }
        return $this->arrayResponse;
    }

}