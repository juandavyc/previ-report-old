<?php
require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';

require_once 'read_implicado.php';
require_once 'read_agente.php';
require_once 'read_testigo.php';

class ReadSiniestro
{
    private $databaseConnection = null;

    private $arrayResponse = array();
    private $arrayUsuarios = array();
    private $arrayContador = 0;

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }

    public function getSiniestro(
        $_condicional_ = array(
            'TYPE' => 'ID',
            'VALUE' => 1,
            'LIMIT' => '0,1',
        )
    ) {

        $implicado = new ReadImplicado($this->databaseConnection);
        $agente = new ReadAgente($this->databaseConnection);
        $testigo = new ReadTestigo($this->databaseConnection);

        $_siniestro_default = array(
            0 => array(
                'id' => 0,
            ),
        );

        $arrayCondicional = array(
            'ID' => 'sini.id_siniestro',
            'CEDULA' => 'sini.cedula_usuario',
            'ID_VEHICULO' => 'veh.id_vehiculo',
            'PLACA_VEHICULO' => 'veh.placa_vehiculo',
        );

        //$arrayCondicional = $arrayCondicional[];
        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        #tabla empresa
        $mysqlQuery .= "empr.id_empresa,empr.nit,empr.nombre_empresa, ";
        #tabla SINIESTRO
        $mysqlQuery .= "sini.id_siniestro,sini.fecha_siniestro,TIME_FORMAT(sini.hora_siniestro, '%H:%i') As time_hora_siniestro, con.nombre_conductor, ";
        $mysqlQuery .= "sini.direccion_siniestro,sini.heridos_siniestro,sini.muertos_siniestro, usu.apellido_usuario, ";
        $mysqlQuery .= "sini.vehiculos_implicados_siniestro,sini.descripcion_siniestro,sini.foto_1_siniestro, ";
        $mysqlQuery .= "sini.foto_2_siniestro, sini.foto_3_siniestro,sini.foto_4_siniestro, ";
        $mysqlQuery .= "sini.firma_siniestro,sini.fecha_formulario, ";
        #tabla CIUDAD
        $mysqlQuery .= "ciu.id_ciudad,ciu.nombre_ciudad, ";
        #tabla CIUDAD
        $mysqlQuery .= "depa.id_departamento,depa.nombre_departamento, ";
        #tabla TIPO SINIESTRO
        $mysqlQuery .= " tsini.id_tipo_siniestro,tsini.nombre_tipo_siniestro, ";
        #tabla VEHICULO
        $mysqlQuery .= "veh.id_vehiculo,veh.placa_vehiculo, ";
        #tabla CONDUCTOR
        $mysqlQuery .= "con.id_conductor,con.numero_documento, ";
        #tabla USUARIO
        $mysqlQuery .= "usu.id_usuario, usu.nombre_usuario  ";
        ## FROM ##
        $mysqlQuery .= "FROM ";
        $mysqlQuery .= "siniestro sini ";
        #JOIN
        $mysqlQuery .= "INNER JOIN tipo_siniestro tsini ON tsini.id_tipo_siniestro = sini.id_tipo_siniestro ";
        $mysqlQuery .= "INNER JOIN vehiculo veh ON veh.id_vehiculo = sini.id_vehiculo ";
        $mysqlQuery .= "INNER JOIN conductor con ON con.id_conductor = sini.id_conductor ";
        $mysqlQuery .= "INNER JOIN usuario usu ON usu.id_usuario = sini.id_usuario ";
        $mysqlQuery .= "INNER JOIN empresa empr ON empr.id_empresa = sini.id_empresa ";
        $mysqlQuery .= "INNER JOIN ciudad ciu ON ciu.id_ciudad = sini.id_ciudad ";
        $mysqlQuery .= "INNER JOIN departamento depa ON depa.id_departamento = ciu.id_departamento ";
        #Condicion
        $mysqlQuery .= "WHERE ";
        $mysqlQuery .= $arrayCondicional[$_condicional_['TYPE']] . " LIKE ? ";
        #Ordenamiento
        $mysqlQuery .= "ORDER BY sini.id_siniestro DESC; ";

        // echo $mysqlQuery;

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_condicional_['VALUE']);

        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {

                    $arrayAgente = $agente->getAgente(($row['id_siniestro']));
                    $arrayImplicado = $implicado->getImplicados(($row['id_siniestro']));
                    $arrayTestigo = $testigo->getTestigo(($row['id_siniestro']));

                    array_push(
                        $mysqlArray,
                        array(
                            "id" => ($row['id_siniestro']),
                            "fecha_siniestro" => htmlspecialchars($row['fecha_siniestro']),
                            "hora" => ($row['time_hora_siniestro']),
                            "direccion" => htmlspecialchars($row['direccion_siniestro']),
                            'tipo_siniestro' => array(
                                "id" => ($row['id_tipo_siniestro']),
                                "nombre_tipo" => htmlspecialchars($row['nombre_tipo_siniestro']),
                            ),
                            "heridos" => (($row['heridos_siniestro'] == 1) ? 'SI' : 'NO'),
                            "muertos" => (($row['muertos_siniestro'] == 1) ? 'SI' : 'NO'),
                            "implicados" => (($row['vehiculos_implicados_siniestro'] == 1) ? 'SI' : 'NO'),
                            "agente_transito" => $arrayAgente,
                            "implicados_siniestro" => $arrayImplicado,
                            "testigos_siniestro" => $arrayTestigo,
                            "descripcion" => htmlspecialchars($row['descripcion_siniestro']),
                            "foto_1" => htmlspecialchars($row['foto_1_siniestro']),
                            "foto_2" => htmlspecialchars($row['foto_2_siniestro']),
                            "foto_3" => htmlspecialchars($row['foto_3_siniestro']),
                            "foto_4" => htmlspecialchars($row['foto_4_siniestro']),
                            "firma" => htmlspecialchars($row['firma_siniestro']),
                            'vehiculo' => array(
                                "id" => ($row['id_vehiculo']),
                                "placa" => htmlspecialchars($row['placa_vehiculo']),
                            ),
                            'conductor' => array(
                                "id" => ($row['id_conductor']),
                                "nombre_conductor" => htmlspecialchars($row['nombre_conductor']),
                            ),
                            'ciudad' => array(
                                "id" => ($row['id_ciudad']),
                                "ciudad" => htmlspecialchars($row['nombre_ciudad']),
                            ),
                            'departamento' => array(
                                "id" => ($row['id_departamento']),
                                "departamento" => htmlspecialchars($row['nombre_departamento']),
                            ),
                            'empresa' => array(
                                "id" => ($row['id_empresa']),
                                "nombre_empresa" => htmlspecialchars($row['nombre_empresa']),
                            ),
                            "usuario" => htmlspecialchars($row['nombre_usuario'] . " " . $row['apellido_usuario']),
                            "fecha" => ($row['fecha_formulario']),
                        )
                    );
                }

                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Resultados encontrados',
                    'siniestro' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                    'siniestro' => $_siniestro_default,
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}