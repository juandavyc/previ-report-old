<?php
class ReadImplicado 
{

    private $databaseConnection = null;
    private $arrayResponse = array();

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }

    public function getImplicados(
        $_id_siniestro_ = 0
    ){

        


    }



}