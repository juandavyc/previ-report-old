<?php
// var_dump($_POST);
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'POST') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );

    if (
        // vehiculo
        isset($_POST["veh_placa"]) &&
        isset($_POST["veh_marca"]) &&
        isset($_POST["veh_modelo"]) &&
        // conductor
        isset($_POST["con_nombre"]) &&
        isset($_POST["con_telefono"]) &&
        isset($_POST["con_correo"]) &&
        isset($_POST["con_direccion"]) &&
        //
        isset($_POST["ase_nombre"]) &&
        isset($_POST["ase_telefono"]) &&
        //
        isset($_POST["pol_tipo"]) &&
        isset($_POST["pol_aseguradora"]) &&
        isset($_POST["pol_expedicion"]) &&
        isset($_POST["pol_vencimiento"]) &&
        //
        isset($_POST["id"]) &&
        isset($_POST["acct"]) &&
        count($_POST) == 15
    ) {

        require DOCUMENT_ROOT . '/webservice/auth_resources.php';
        require DOCUMENT_ROOT . '/webservice/auth_database.php';
        require DOCUMENT_ROOT . '/webservice/auth_user.php';

        $database = new dbconnection();
        $database->connect();

        if (strcmp($database->status(), "bien") == 0) {

            $_user = htmlspecialchars($_POST['acct']);

            //user verify
            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);
            $_id_usuario = ($responseAcct['id_user']);

            // si existe el usuario
            if (strcmp($responseAcct['status'], 'bien') == 0) {

                require DOCUMENT_ROOT . '/webservice/siniestro/clases/siniestro/update.php';

                $siniestro = new UpdateSiniestro($database->myconn);

                $arrayResponse = $siniestro->setImplicadoSiniestro(
                    array(
                        'PLACA' => htmlspecialchars($_POST['veh_placa']),
                        'MARCA' => htmlspecialchars($_POST['veh_marca']),
                        'MODELO' => htmlspecialchars($_POST['veh_modelo']),
                        'CONDUCTOR' => htmlspecialchars($_POST['con_nombre']),
                        'TELEFONO' => htmlspecialchars($_POST['con_telefono']),
                        'CORREO' => htmlspecialchars($_POST['con_correo']),
                        'DIRECCION' => htmlspecialchars($_POST['con_direccion']),
                        'ASEGURADORA' => htmlspecialchars($_POST['ase_nombre']),
                        'ASEGURADORA_TELEFONO' => htmlspecialchars($_POST['ase_telefono']),
                        'POLIZA' => htmlspecialchars($_POST['pol_tipo']),
                        'POLIZA_ASEGURADORA' => htmlspecialchars($_POST['pol_aseguradora']),
                        'FECHA_EXPEDICION' => getspecialdate($_POST['pol_expedicion']),
                        'FECHA_VENCIMIENTO' => getspecialdate($_POST['pol_vencimiento']),
                        'ID_SINIESTRO' => $_POST["id"],
                        'ID_USUARIO' => $_id_usuario,
                    )
                );

                if ($arrayResponse['status'] == 'bien') {

                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );

                } else {
                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );
                }

                $database->close();

            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'Error',
            'message' => 'Formulario Incompleto',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}