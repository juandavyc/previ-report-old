<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'GET') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );
    # los obligatorios

    //PREOPERARCIONALES ID Ó POR ID_VEHICULO / PLACA

    if (COUNT($_GET) > 1 && isset($_GET['acct']) && isset($_GET['siniestro']) || isset($_GET['vehiculo'])
    ) {
        require '../auth_database.php';
        require '../auth_user.php';

        # usuario esta autorizado
        $_user = htmlspecialchars($_GET['acct']);

        $database = new dbconnection();
        $database->connect();
        if (strcmp($database->status(), "bien") == 0) {

            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            if (strcmp($responseAcct['status'], 'bien') == 0) {

                $condicionBusqueda = '';
                $get_value = '';
                $_limit = '0,1';

                if (isset($_GET['siniestro'])) {
                    if (is_numeric($_GET['siniestro'])) {
                        $condicionBusqueda = 'ID';
                        $get_value = htmlspecialchars($_GET['siniestro']);
                        $_limit = '0,1';
                        // echo "1";
                    }
                } else if (isset($_GET['vehiculo'])) {
                    if (is_numeric($_GET['vehiculo'])) {
                        $condicionBusqueda = 'ID_VEHICULO';
                        $get_value = htmlspecialchars($_GET['vehiculo']);
                        $_limit = '0,100';
                        // echo "2";
                    } else {
                        $condicionBusqueda = 'PLACA_VEHICULO';
                        $get_value = htmlspecialchars($_GET['vehiculo']);
                        $_limit = '0,100';
                        // echo "3";
                    }
                }

                // $condicionBusqueda = isset($_GET['siniestro']) ? (is_numeric($_GET['siniestro']) ? 'ID': 'MAL') : (isset($_GET['vehiculo']) ? (is_numeric($_GET['vehiculo']) ? 'ID_VEHICULO' : 'PLACA') : 'MAL');

                require DOCUMENT_ROOT . '/webservice/siniestro/clases/siniestro/read.php';

                $siniestro = new ReadSiniestro($database->myconn);
                $arraysiniestro = $siniestro->getSiniestro(
                    array(
                        'TYPE' => $condicionBusqueda,
                        'VALUE' => $get_value,
                        'LIMITE' => $_limit,
                    ),

                );

                # siniestro ENCONTRADO
                if (strcmp($arraysiniestro['status'], 'bien') == 0) {
                    //$_array_response();
                    $_array_response = array(
                        'status' => $arraysiniestro['status'],
                        'message' => $arraysiniestro['message'],
                        'siniestro' => $arraysiniestro['siniestro'],
                    );
                    // ID vehiculo
                    $_ID_siniestro = $arraysiniestro['siniestro']['0']['id'];
                }
                # vehiculo NO ENCONTRADO
                else {
                    $_array_response = array(
                        'status' => $arraysiniestro['status'],
                        'message' => $arraysiniestro['message'],
                    );
                }
            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

            $database->close();
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }
    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}