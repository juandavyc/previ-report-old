<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

// https://192.168.194.29/webservice/siniestro/create.php?acct=spartanggs&vehiculo=89&empresa=900123456789-0&type=nit

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

// CONFIRMA SI EL TIPO DE ENVIO DE DATOS ES GET
if (strcmp($methodRequest, 'GET') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );
    # los obligatorios
    if (
        COUNT($_GET) > 1 &&
        isset($_GET['acct']) &&
        isset($_GET['vehiculo']) &&
        isset($_GET['empresa']) &&
        isset($_GET['type'])
    ) {
        //db
        require '../auth_database.php';
        require '../auth_user.php';

        $_user = htmlspecialchars($_GET['acct']);

        $database = new dbconnection();
        $database->connect();
        // db connection
        if (strcmp($database->status(), "bien") == 0) {

            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            if (strcmp($responseAcct['status'], 'bien') == 0) {

                $_id_usuario = ($responseAcct['id_user']);

                $_empresa = htmlspecialchars($_GET['empresa']);
                $_typeEmpresa = strtoupper(htmlspecialchars($_GET['type']));
                $_vehiculo = htmlspecialchars($_GET['vehiculo']);
                $_typeVehiculo = is_numeric($_vehiculo) ? 'ID' : 'PLACA';

                // SI EL TYPE ES VALIDO O NO
                if ($_typeEmpresa === 'NOMBRE' || $_typeEmpresa === 'NIT') {
                    // CONSULTA EMPRESA
                    require DOCUMENT_ROOT . '/webservice/empresa/clases/empresa/read.php';
                    $ResponseEmpresa = new ReadEmpresa($database->myconn);
                    $arrayEmpresa = $ResponseEmpresa->getEmpresa(
                        array(
                            'TYPE' => $_typeEmpresa,
                            'VALUE' => $_empresa,
                            'LIMIT' => '0,1',
                        ),
                    );

                    if (strcmp($arrayEmpresa['status'], 'bien') == 0) {

                        $_id_empresa = $arrayEmpresa['empresa']['0']['id'];

                        require DOCUMENT_ROOT . '/webservice/vehiculo/clases/vehiculo/read.php';
                        $ResponseVehiculo = new ReadVehiculo($database->myconn);
                        $arrayVehiculo = $ResponseVehiculo->getVehiculo(
                            array(
                                'TYPE' => $_typeVehiculo,
                                'VALUE' => $_vehiculo,
                            ),
                            '0,1',
                            $_id_empresa
                        );

                        if (strcmp($arrayVehiculo['status'], 'bien') == 0) {

                            $_id_vehiculo = $arrayVehiculo['vehiculo']['0']['id'];

                            if (!empty($arrayVehiculo['vehiculo']['0']['conductor_asignado']['0']['conductor']['id'])) {

                                $_id_conductor = $arrayVehiculo['vehiculo']['0']['conductor_asignado']['0']['conductor']['id'];

                                require DOCUMENT_ROOT . '/webservice/siniestro/clases/siniestro/create.php';
                                // crear el siniestro
                                $responseSiniestro = new CreateSiniestro($database->myconn);
                                $arraySiniestro = $responseSiniestro->setSinestro(
                                    $_id_vehiculo,
                                    $_id_conductor,
                                    $_id_empresa,
                                    $_id_usuario
                                );

                                if (strcmp($arraySiniestro['status'], 'bien') == 0) {

                                    $_array_response = array(
                                        'status' => $arraySiniestro['status'],
                                        'message' => $arraySiniestro['message'],
                                        'id' => $arraySiniestro['id'],
                                    );
                                } else {
                                    $_array_response = array(
                                        'status' => $arraySiniestro['status'],
                                        'message' => $arraySiniestro['message'],
                                    );
                                }
                            } else {
                                $_array_response = array(
                                    'status' => 'error',
                                    'message' => 'Vehículo sin conductor asignado, no debería circular.',
                                    'id' => 0,
                                );
                            }

                        } else {
                            $_array_response = array(
                                'status' => $arrayVehiculo['status'],
                                'message' => $arrayVehiculo['message'],
                                'id' => 0,
                            );
                        }
                    }
                    # EMPRESA NO ENCONTRADA(SIN RESULTADOS)
                    else {
                        $_array_response = array(
                            'status' => $arrayEmpresa['status'],
                            'message' => $arrayEmpresa['message'],
                            'id' => 0,
                        );
                    }
                } else {
                    $_array_response = array(
                        'status' => 'URL_ERROR',
                        'message' => 'PARAMETRO (TYPE) INVALIDO',
                    );
                }
            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

            $database->close();
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }
    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}