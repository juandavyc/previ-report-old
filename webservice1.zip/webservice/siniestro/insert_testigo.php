<?php
// var_dump($_POST);
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'POST') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );

    if (
        isset($_POST["nombre"]) &&
        isset($_POST["telefono"]) &&
        isset($_POST["correo"]) &&
        isset($_POST["direccion"]) &&
        isset($_POST["id"]) &&
        isset($_POST["acct"]) &&
        count($_POST) == 6
    ) {

        require DOCUMENT_ROOT . '/webservice/auth_database.php';
        require DOCUMENT_ROOT . '/webservice/auth_user.php';

        $database = new dbconnection();
        $database->connect();

        if (strcmp($database->status(), "bien") == 0) {

            $_user = htmlspecialchars($_POST['acct']);

            //user verify
            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);
            $_id_usuario = ($responseAcct['id_user']);

            // si existe el usuario
            if (strcmp($responseAcct['status'], 'bien') == 0) {

                require DOCUMENT_ROOT . '/webservice/siniestro/clases/siniestro/update.php';

                $siniestro = new UpdateSiniestro($database->myconn);

                $arrayResponse = $siniestro->setTestigoSiniestro(
                    array(
                        'ID_SINIESTRO' => $_POST["id"],
                        'NOMBRE' => htmlspecialchars($_POST["nombre"]),
                        'TELEFONO' => htmlspecialchars($_POST["telefono"]),
                        'CORREO' => htmlspecialchars($_POST["correo"]),
                        'DIRECCION' => htmlspecialchars($_POST["direccion"]),
                        'ID_USUARIO' => $_id_usuario,
                    )
                );

                if ($arrayResponse['status'] == 'bien') {

                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );

                } else {
                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );
                }

                $database->close();

            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'Error',
            'message' => 'Formulario Incompleto',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}