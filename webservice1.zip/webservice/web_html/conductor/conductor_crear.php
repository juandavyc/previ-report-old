<!-- create -->
<h2> - Formulario para Crear Conductor</h2>
<form id="form_2_crear_conductor" name="form_2_crear_conductor">
    <div class="row gtr-25 gtr-uniform">
        <div class="col-3 col-12-small">
            <label class="label-important label-datos">
                acct
            </label>
        </div>
        <div class="col-9 col-12-small">
            <div class="input-container">
                <i class="fas fa-align-left icon-input"></i>
                <input type="text" name="acct" id="form_1_acct" maxlength="20" placeholder="Su cuenta" required />
            </div>
</div>
        <div class="col-3 col-12-small">
            <label class="label-important label-datos">
                Cedula
            </label>
        </div>
        <div class="col-9 col-12-small">
            <div class="input-container">
                <i class="fas fa-align-left icon-input"></i>
                <input type="text" name="cedula" id="form_1_cedula_conductor" placeholder="Numero de documento"
                    required />
            </div>
        </div>
        <div class="col-3 col-12-small">
            <label class="label-important label-datos">
                Empresa: ( id o nombre )
            </label>
        </div>
        <div class="col-9 col-12-small">
            <div class="input-container">
                <i class="fas fa-align-left icon-input"></i>
                <input type="text" name="empresa" id="form_1_empresa" maxlength="45"
                    placeholder=" Empresa: ( id o nit )" required />
            </div>
        </div>
        <div class="col-3 col-12-small"></div>
        <div class="col-9 col-12-small">
            <button type="submit" class="primary small fit">Verificar y guardar</button>
        </div>

    </div>
</form>
 <h3> - Respuesta del Servidor</h3>
<p id="form_1_crear_respuesta"></p>
