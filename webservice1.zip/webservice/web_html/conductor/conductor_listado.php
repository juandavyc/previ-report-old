<!-- create -->
<h2> - Ejemplo de como solicitar datos de CONDUCTOR</h2>
<div class="row gtr-25 gtr-uniform">
    <div class="col-12">
        <label>Solicitud por ID CONDUCTOR</label>
    </div>
    <div class="col-9 col-12-small">
        <div class="input-container">
            <i class="fas fa-align-left icon-input"></i>
            <input type="text" name="acct" id="form_url"
                value="https://previreport.com/webservice/conductor/read.php?acct=SU_ACCT&conductor=ID" maxlength="100"
                placeholder="url" required />
        </div>
    </div>
    <div class="col-3 col-12-small">
        <button id="form_get" class="primary small fit"> GET</button>
    </div>
    <div class="col-12 col-12-small">
        <label>Respuesta del servidor</label>
        <textarea rows="10" id="form_respuesta" form style="resize:vertical ;"></textarea>
    </div>
</div> 