<?php session_start();
header('Content-Type: application/json');
require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
if (
    isset($_POST['acct']) &&
    isset($_POST['folder']) &&
    isset($_POST['base64'])
) {
    require '../../uploader/create.php';

    $base64 = new CreateBase64($_POST['acct']);
    $responseAcct = $base64->setBase64($_POST['base64'], $_POST['folder']);

    $_array_response = array(
        'status' => $responseAcct['status'],
        'message' => $responseAcct['message'],
    );
    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    $json_response = array(
        'status' => "Error",
        'body' => "Formulario incompleto",
    );
    echo json_encode($json_response, JSON_FORCE_OBJECT);
    exit;
}