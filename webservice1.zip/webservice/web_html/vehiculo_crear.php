<!-- create -->
<h2> - Formulario para Crear</h2>
<form id="form_1_crear" name="form_1_crear">
    <div class="row gtr-25 gtr-uniform">
        <div class="col-3 col-12-small">
            <label class="label-important label-datos">
                Acct
            </label>
        </div>
        <div class="col-9 col-12-small">
            <div class="input-container">
                <i class="fas fa-align-left icon-input"></i>
                <input type="text" name="acct" id="form_1_acct" maxlength="20" placeholder="Su cuenta" required />
            </div>
        </div>
        <div class="col-3 col-12-small">
            <label class="label-important label-datos">
                Placa
            </label>
        </div>
        <div class="col-9 col-12-small">
            <div class="input-container">
                <i class="fas fa-align-left icon-input"></i>
                <input type="text" name="placa" id="form_1_placa" maxlength="6" placeholder="Placa del vehiculo"
                    required />
            </div>
        </div>
        <div class="col-3 col-12-small">
            <label class="label-important label-datos">
                Empresa: ( id o nombre )
            </label>
        </div>
        <div class="col-9 col-12-small">
            <div class="input-container">
                <i class="fas fa-align-left icon-input"></i>
                <input type="text" name="empresa" id="form_1_empresa" maxlength="45"
                    placeholder=" Empresa: ( id o nit )" required />
            </div>
        </div>
        <div class="col-3 col-12-small"></div>
        <div class="col-9 col-12-small">
            <button type="submit" class="primary small fit">Verificar y guardar</button>
        </div>

    </div>
</form>
<h3> - Respuesta del Servidor</h3>
<p id="form_1_crear_respuesta"></p>
<div class="row gtr-25 gtr-uniform">
    <div class="col-6 col-12-small">
        <h3> - Ejemplo Javascript</h3>
        <textarea rows="10" style="resize:vertical ;">
const formCrear = document.getElementById('id_formulario');
const formCrearRespuesta = document.getElementById('id_texarea_respuesta');

const formCrearSubmit = (event) => {

    fetch('https://previreport.com/webservice/vehiculo/create.php', {
        method: 'post',
        body: new FormData(formCrear),
    })
        .then((response) => response.text())
        .then((text) => {
            console.log(text);
            formCrearRespuesta.textContent = text;
        });

    event.preventDefault();
}

formCrear.addEventListener('submit', formCrearSubmit);
                            </textarea>
    </div>
    <div class="col-6 col-12-small">
        <h3> - Ejemplo HTML</h3>
        <textarea rows="10" style="resize:vertical ;">
<form id="form_1_crear" name="form_1_crear">

<input type="text" name="acct" maxlength="20" placeholder="Su cuenta" required />

<input type="text" name="placa" maxlength="6" placeholder="Placa del vehiculo" required />

<input type="text" name="empresa" maxlength="45" placeholder=" Empresa: ( id o nombre )" required />

<button type="submit">Verificar y guardar</button>
</form>
                            </textarea>
    </div>
</div>


<h3> - Ejemplo de respuesta</h3>
<textarea rows="10" style="resize:vertical ;">
1) 
Response: {"status":"bien","message":"Vehiculo creado Correctamente","id":82,"placa":"SSX00D"}
2)
Response: {"status":"error","message":"El Vehiculo ya Existe"}
3)
Response: {"status":"error","message":"La empresa no existe"}
4)
Response: {"status":"error","message":"usuario no autorizado"}
5)
Response: {"status":"DATABASE","message":"IMPOSIBLE CONECTAR A LA BASE DE DATOS"}
</textarea>