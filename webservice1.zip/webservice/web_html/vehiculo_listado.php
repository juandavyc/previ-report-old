<!-- create -->
<h2> - Ejemplo de como solicitar datos</h2>
<div class="row gtr-25 gtr-uniform">
    <div class="col-12">
        <label>Solicitud por PLACA</label>
    </div>
    <div class="col-9 col-12-small">
        <div class="input-container">
            <i class="fas fa-align-left icon-input"></i>
            <input type="text" name="acct" id="form_2_url_0"
                value="https://previreport.com/webservice/vehiculo/read.php?acct=SU_ACCT&vehiculo=PLACA" maxlength="100"
                placeholder="url" required />
        </div>
    </div>
    <div class="col-3 col-12-small">
        <button id="form_2_get_0" class="primary small fit"> GET</button>
    </div>
    <div class="col-12">
        <label>Solicitud por ID</label>
    </div>
    <div class="col-9 col-12-small">
        <div class="input-container">
            <i class="fas fa-align-left icon-input"></i>
            <input type="text" name="acct" id="form_2_url_1"
                value="https://previreport.com/webservice/vehiculo/read.php?acct=SU_ACCT&vehiculo=ID" maxlength="100"
                placeholder="url" required />
        </div>
    </div>
    <div class="col-3 col-12-small">
        <button id="form_2_get_1" class="primary small fit"> GET</button>
    </div>
    <div class="col-6 col-12-small">
        <label>Respuesta del servidor</label>
        <textarea rows="10" id="form_2_respuesta" form style="resize:vertical ;"></textarea>
    </div>
    <div class="col-6 col-12-small">
        <label> Ejemplo javascript</label>
        <textarea rows="10" form style="resize:vertical ;">
document.getElementById("id_boton").addEventListener("click", function (event) {
    fetch(document.getElementById("id_input_url").value)
        .then((response) => response.text())
        .then((text) => {
            console.log(text);
            document.getElementById("id_texarea_respuesta").value = text;
        });
    event.preventDefault();
}, false);
        </textarea>
    </div>

</div>