<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
*/
// var_dump($_POST);
require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'POST') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );



    if (
        isset($_POST["form_3_foto"]) &&
        isset($_POST["form_3_categoria_foto"]) &&
        isset($_POST["form_3_descripcion_foto"]) &&
        isset($_POST["id_mantenimiento"]) &&
        isset($_POST['acct']) &&
        count($_POST) == 5 
    ) {

        //db
        require  '../auth_database.php';
        require  '../auth_user.php';

        $database = new dbconnection();
        $database->connect();

        if (strcmp($database->status(), "bien") == 0) {

            $_user = htmlspecialchars($_POST['acct']);

            //user verify
            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);


            // si existe el usuario
            if (strcmp($responseAcct['status'], 'bien') == 0) {

                require DOCUMENT_ROOT . '/webservice/mantenimiento/clases/mantenimiento/update.php';

                require '../uploader/create.php';

                $mantenimiento = new UpdateMantenimiento($database->myconn);

                $foto = ($_POST['form_3_foto']);
                
                $base64 = new CreateBase64($_POST['acct']);
                $responseFoto = $base64->setBase64($foto, 'mantenimiento');

                $arrayResponse = $mantenimiento->setFotoMantenimiento(
                    array(
                    'ID' => htmlspecialchars($_POST['id_mantenimiento']),
                    'FOTO' => $responseFoto['message'],
                    'CATEGORIA_FOTO' => htmlspecialchars($_POST["form_3_categoria_foto"]),
                    'DESCRIPCION' => htmlspecialchars($_POST["form_3_descripcion_foto"]),
                    'ID_USUARIO' => 57,
                ) 
                );
    
                if ($arrayResponse['status'] == 'bien') {

                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );

                } else {
                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );
                }

                $database->close();

            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

           
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
        // FORM
    } else {
        $_array_response = array(
            'status' => 'Error',
            'message' => 'Formulario Incompleto',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}





