


<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
*/

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];


if (strcmp($methodRequest, 'POST') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );



    if (
        isset($_POST["form_4_nombre_repuesto"]) &&
        isset($_POST["form_4_cantidad_repuesto"]) &&
        isset($_POST["form_4_valor_repuesto"]) &&
        isset($_POST["form_4_notas_repuesto_mantenimiento"]) &&
        isset($_POST["id_mantenimiento"]) &&
        isset($_POST['acct']) &&
        count($_POST) == 6 
    ) {

        //db
        require  '../auth_database.php';
        require  '../auth_user.php';

        $database = new dbconnection();
        $database->connect();

        if (strcmp($database->status(), "bien") == 0) {

            $_user = htmlspecialchars($_POST['acct']);

            //user verify
            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);


            // si existe el usuario
            if (strcmp($responseAcct['status'], 'bien') == 0) {

                require DOCUMENT_ROOT . '/webservice/mantenimiento/clases/mantenimiento/update.php';

                $mantenimiento = new UpdateMantenimiento($database->myconn);
    
                $arrayResponse = $mantenimiento->setRepuestoMantenimiento(
                    array(
                        'ID' => htmlspecialchars($_POST['id_mantenimiento']),
                        'NOMBRE_REPUESTO' => htmlspecialchars($_POST['form_4_nombre_repuesto']),
                        'CANTIDAD_REPUESTO' => htmlspecialchars($_POST["form_4_cantidad_repuesto"]),
                        'VALOR_REPUESTO' => htmlspecialchars($_POST["form_4_valor_repuesto"]),
                        'NOTAS_REPUESTO' => htmlspecialchars($_POST["form_4_notas_repuesto_mantenimiento"]),
                        'ID_USUARIO' => 57,
                    ) 
                );
    
    
                if ($arrayResponse['status'] == 'bien') {

                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );

                } else {
                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );
                }

                $database->close();

            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

           
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
        // FORM
    } else {
        $_array_response = array(
            'status' => 'Error',
            'message' => 'Formulario Incompleto',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}

