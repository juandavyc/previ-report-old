<?php 
// var_dump($_POST);
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
*/

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];



if (strcmp($methodRequest, 'POST') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );


    if (
        isset($_POST["form_1_tipo_mantenimiento"]) &&
        isset($_POST["form_1_periodo_mantenimiento"]) &&
        isset($_POST["form_1_fecha_mantenimiento"]) &&
        isset($_POST["form_1_direccion_mantenimiento"]) &&
        isset($_POST["form_1_precio_mano_obra_mantenimiento"]) &&
        isset($_POST["form_1_precio_repuestos_obra_mantenimiento"]) &&
        isset($_POST["form_1_cantidad_repuestos_obra_mantenimiento"]) &&
        isset($_POST["id_mantenimiento"]) &&
        isset($_POST["acct"]) &&
        count($_POST) == 9
    ) {


        include DOCUMENT_ROOT . '/modulos/assets/php/hdv_resources.php';

        //db


        require_once  '../auth_database.php';
        require  '../auth_user.php';

        $database = new dbconnection();
        $database->connect();
 
        if (strcmp($database->status(), "bien") == 0) {

            $_user = htmlspecialchars($_POST['acct']);

            //user verify
            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);


            // si existe el usuario
            if (strcmp($responseAcct['status'], 'bien') == 0) {

                require DOCUMENT_ROOT . '/webservice/mantenimiento/clases/mantenimiento/update.php';

                $mantenimiento = new UpdateMantenimiento($database->myconn);
                
                $arrayResponse = $mantenimiento->setInformacionMantenimiento(
                    array(
                        'ID' => htmlspecialchars($_POST['id_mantenimiento']),
                        'ID_TIPO' => htmlspecialchars($_POST['form_1_tipo_mantenimiento']),
                        'PERIODO' => htmlspecialchars($_POST['form_1_periodo_mantenimiento']),
                        'FECHA' => getspecialdate($_POST['form_1_fecha_mantenimiento']),
                        'DIRECCION' => htmlspecialchars($_POST['form_1_direccion_mantenimiento']),
                        'PRECIO_MANO' => htmlspecialchars($_POST['form_1_precio_mano_obra_mantenimiento']),
                        'PRECIO_REPUESTOS' => htmlspecialchars($_POST['form_1_precio_repuestos_obra_mantenimiento']),
                        'CANTIDAD' => htmlspecialchars($_POST['form_1_cantidad_repuestos_obra_mantenimiento']),
                        'ID_USUARIO' => 57,
                    )
                );
    
                // $arrayResponse = $mantenimiento->setProcedimientoMantenimiento(
                //     array(
                //         'ID' => htmlspecialchars($_POST['id_mantenimiento']),
                //         'REPUESTO' => htmlspecialchars($_POST['form_2_repuesto_mantenimiento']),
                //         'FECHA_INICIAL' => getspecialdate($_POST['form_2_fecha_inicial_mantenimiento']),
                //         'HORA_INICIAL' => htmlspecialchars($_POST['form_2_hora_inicio_mantenimiento']),
                //         'FECHA_FINAL' => getspecialdate($_POST['form_2_fecha_final_mantenimiento']),
                //         'FIRMA' => getSRCImage64($_POST['form_1_canvas'], 'firmas/mantenimiento_mecanico', $form_id_usuario . '_' . time()),
                //         //  getSRCImage64($_POST['form_0_firma'], 'firmas/usuarios', $form_id_usuario . '_' . $id_usuario . '_' . time());
                //         'HORA_FINAL' => htmlspecialchars($_POST['form_2_hora_final_mantenimiento']),
                //         'DESCRIPCION_REALIZAR' => htmlspecialchars($_POST['form_2_descripcion_trabajo_a_realizar']),
                //         'DESCRIPCION_REALIZADO' => htmlspecialchars($_POST['form_2_descripcion_procedimiento_realizado']),
                //         'ID_USUARIO' => 57,
                //     )
                // );
    
    
                // $arrayResponse = $mantenimiento->setFotoMantenimiento(
                //     array(
                //     'ID' => htmlspecialchars($_POST['id_mantenimiento']),
                //     'FOTO' => htmlspecialchars($_POST['form_3_foto']),
                //     'CATEGORIA_FOTO' => htmlspecialchars($_POST["form_3_categoria_foto"]),
                //     'DESCRIPCION' => htmlspecialchars($_POST["form_3_descripcion_foto"]),
                //     'ID_USUARIO' => 57,
                // ) 
                // );
    
                // $arrayResponse = $mantenimiento->setRepuestoMantenimiento(
                //     array(
                //         'ID' => htmlspecialchars($_POST['id_mantenimiento']),
                //         'NOMBRE_REPUESTO' => htmlspecialchars($_POST['form_4_nombre_repuesto']),
                //         'CANTIDAD_REPUESTO' => htmlspecialchars($_POST["form_4_cantidad_repuesto"]),
                //         'VALOR_REPUESTO' => htmlspecialchars($_POST["form_4_valor_repuesto"]),
                //         'NOTAS_REPUESTO' => htmlspecialchars($_POST["form_4_notas_repuesto_mantenimiento"]),
                //         'ID_USUARIO' => 57,
                //     ) 
                // );
    
    
                if ($arrayResponse['status'] == 'bien') {

                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );

                } else {
                    $_array_response = array(
                        'status' => $arrayResponse['status'],
                        'message' => $arrayResponse['message'],
                    );
                }

                $database->close();

            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

           
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
        // FORM
    } else {
        $_array_response = array(
            'status' => 'Error',
            'message' => 'Formulario Incompleto',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}
