<?php
class ReadTaller
{
    private $databaseConnection = null;

    private $arrayResponse = array();
    private $arraytallesas = array();
    private $arrayContador = 0;

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }

    public function getTaller(
        $_condicional_ = array(
            'VALUE' => 1,
            'TYPE' => 'ID',
            'LIMIT' => '0,1',
            'EMPRESA' => '%%',
        )
    ) {

    
        $_array_taller_default = array(
            0 => array(
                'id' => 0,
            ),
        );

        $arrayCondicional = array(
            'ID' => 'tall.id_taller',
            'NIT' => 'tall.nit_taller',
            'NOMBRE' => 'tall.nombre_taller',
        );

        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        #tabla tallesa
        $mysqlQuery .= "tall.id_taller,tall.nit_taller,tall.nombre_taller,tall.direccion_taller, ";
        $mysqlQuery .= "tall.fecha_formulario,tall.telefono_taller,tall.correo_taller,";
        #tabla ciudad
        $mysqlQuery .= "ciud.nombre_ciudad,ciud.id_ciudad, ";
        #tabla departamento
        $mysqlQuery .= "dept.nombre_departamento,dept.id_departamento, ";
        #tabla usuario
        $mysqlQuery .= "usua.id_usuario,usua.nombre_usuario,usua.apellido_usuario, ";
        #tabla EMPRESA
        $mysqlQuery .= "emp.id_empresa,emp.nombre_empresa ";
        ## FROM ##
        $mysqlQuery .= "FROM ";
        $mysqlQuery .= "taller tall ";
        #JOIN
        $mysqlQuery .= "LEFT JOIN ciudad ciud ON tall.id_ciudad = ciud.id_ciudad ";
        $mysqlQuery .= "LEFT JOIN departamento dept ON dept.id_departamento = ciud.id_departamento ";
        $mysqlQuery .= "LEFT JOIN usuario usua ON tall.id_usuario = usua.id_usuario ";
        $mysqlQuery .= "LEFT JOIN empresa emp ON tall.id_empresa = emp.id_empresa ";
        #Condicion
        $mysqlQuery .= "WHERE ";
        $mysqlQuery .= $arrayCondicional[$_condicional_['TYPE']] . " LIKE ? AND ";
        $mysqlQuery .= "tall.id_empresa LIKE ? ";
        #Ordenamiento
        $mysqlQuery .= "ORDER BY tall.id_taller DESC; ";

        // echo $mysqlQuery;


        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('ss', $_condicional_['VALUE'], $_condicional_['EMPRESA']);
        if ($mysqlStmt->execute()) {
            $mysqlResult = $mysqlStmt->get_result();
            if (intval($mysqlResult->num_rows) > 0) {
                while ($row = $mysqlResult->fetch_assoc()) {
                    array_push(
                        $mysqlArray,
                        array(
                            "id" => htmlspecialchars($row['id_taller']),
                            "nit" => htmlspecialchars($row['nit_taller']),
                            "nombre" => htmlspecialchars($row['nombre_taller']),
                            "telefono" => htmlspecialchars($row['telefono_taller']),
                            "direccion" => htmlspecialchars($row['direccion_taller']),
                            "correo" => htmlspecialchars($row['correo_taller']),
                            'ciudad' => array(
                                "id_ciudad" => htmlspecialchars($row['id_ciudad']),
                                 "ciudad" => htmlspecialchars($row['nombre_ciudad']),
                            ),
                            'departamento' => array(
                                "id_departamento" => htmlspecialchars($row['id_departamento']),
                                "departamento" => htmlspecialchars($row['nombre_departamento']),
                            ),
                            "usuario" =>array(
                                'id' => htmlspecialchars($row['id_usuario']),
                                'nombre' => htmlspecialchars($row['nombre_usuario'] . ' ' . $row['apellido_usuario']),
                            ),
                             
                            "fecha" => htmlspecialchars($row['fecha_formulario']),
                            'empresa' => array(
                                "id" => htmlspecialchars($row['id_empresa']),
                                "nombre_empresa" => htmlspecialchars($row['nombre_empresa']),
                            ),
                        )
                    );
                }
                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Resultados encontrados',
                    'taller' => $mysqlArray,
                );
            } else {
                $this->arrayResponse = array(
                    'status' => 'sin_resultados',
                    'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                    'taller' => $_array_taller_default,
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}