<?php
class ReadContactoEmergencia
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getContacto(
       $_id_conductor
    ) {

        $_default_contacto = array(
            'status' => 'SIN CONTACTO DE EMERGENCIA'
        );

        

        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        $mysqlQuery .= "cec.id_contacto_de_emergencia_conductor , cec.nombre_contacto_de_emergencia_conductor, cec.telefono_contacto_de_emergencia_conductor , 
        cec.parentesco_contacto_de_emergencia_conductor , cec.fecha_formulario, usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";
        $mysqlQuery .= "FROM contacto_de_emergencia_conductor cec ";
        $mysqlQuery .= "LEFT JOIN usuario usu ON usu.id_usuario = cec.id_usuario ";
        $mysqlQuery .= "WHERE id_conductor LIKE ? ";
        $mysqlQuery .= "AND is_visible = 1  ";
        $mysqlQuery .= "ORDER BY id_contacto_de_emergencia_conductor DESC ;";

        // var_dump($mysqlQuery);

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(
                                "id" => htmlspecialchars($row['id_contacto_de_emergencia_conductor']),
                                "nombre" => htmlspecialchars($row['nombre_contacto_de_emergencia_conductor']),
                                "telefono" => htmlspecialchars($row['telefono_contacto_de_emergencia_conductor']),
                                "parentesco" => htmlspecialchars($row['parentesco_contacto_de_emergencia_conductor']),
                                "fecha" => htmlspecialchars($row['fecha_formulario']),
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'].' '.$row['apellido_usuario']),
                                )

                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'contacto' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'contacto' => $_default_contacto, 
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}