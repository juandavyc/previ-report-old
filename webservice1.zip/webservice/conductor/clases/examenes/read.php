<?php
class ReadExamen
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getExamen(
        $_id_vehiculo
    ) {
  
        $_default_examen = array(
            'status' => 'SIN EXAMENES'
        );

        $mysqlArray = array();

        $mysql_query = "SELECT ";
        $mysql_query .= "veh.id_vehiculo,con.id_conductor, tiex.nombre_tipo_examen, enex.nombre_entidad_examen, ex.recomendaciones, ex.fecha_expedicion_examen, ex.fecha_vencimiento_examen, ";
        $mysql_query .= "tiex.id_tipo_examen,tiex.nombre_tipo_examen, ex.foto_examen, usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario, enex.id_entidad_examen ";
        $mysql_query .= "FROM examen ex ";
        $mysql_query .= "LEFT JOIN conductor con ON ex.id_conductor = con.id_conductor ";
        $mysql_query .= "LEFT JOIN tipo_examen tiex ON ex.id_tipo_examen = tiex.id_tipo_examen ";
        $mysql_query .= "LEFT JOIN entidad_examen enex ON ex.id_entidad_examen = enex.id_entidad_examen ";
        $mysql_query .= "LEFT JOIN vehiculo_conductor vehco ON con.id_conductor = vehco.id_conductor ";
        $mysql_query .= "LEFT JOIN vehiculo veh ON vehco.id_vehiculo = veh.id_vehiculo ";
        $mysql_query .= "LEFT JOIN usuario usu ON usu.id_usuario = ex.id_usuario ";
        $mysql_query .= "WHERE ex.id_conductor LIKE ? ;";

        $mysql_stmt = mysqli_prepare($this->databaseConnection, $mysql_query);

        $mysql_stmt->bind_param('s', $_id_conductor);

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysql_query);
        $mysqlStmt->bind_param('s', $_id_vehiculo);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(
                                'entidad' => array(
                                    'id' => htmlspecialchars($row['id_entidad_examen']),
                                    'nombre' => htmlspecialchars($row['nombre_entidad_examen']),
                                ),
                                'tipo_examen' => array(
                                    'id' => htmlspecialchars($row['id_tipo_examen']),
                                    'nombre' => htmlspecialchars($row['nombre_tipo_examen']),
                                ),
                                'recomendacion' => $row['recomendaciones'],
                                'expedicion' => $row['fecha_expedicion_examen'],
                                'vencimiento' => $row['fecha_vencimiento_examen'],
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'] . ' ' . $row['apellido_usuario']),
                                )
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'examenes' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'examenes' => $_default_examen,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}
