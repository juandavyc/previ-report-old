<?php
class ReadEps
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getEps(
        $_id_conductor
    ) {

        $_default_eps = array(
            'status' => 'SIN EPS'
        );

        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        $mysqlQuery .= "epsc.id_eps_conductor , epss.nombre_eps, epsc.fecha_afiliacion_eps , eeps.id_estado_eps, 
        eeps.nombre_estado_eps, epsc.fecha_formulario,epsc.foto_eps_conductor,usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario  ";
        $mysqlQuery .= "FROM eps_conductor epsc ";
        $mysqlQuery .= "LEFT JOIN eps epss ON epss.id_eps = epsc.id_eps ";
        $mysqlQuery .= "LEFT JOIN estado_eps eeps ON eeps.id_estado_eps = epsc.id_estado_eps ";
        $mysqlQuery .= "LEFT JOIN usuario usu ON usu.id_usuario = epsc.id_usuario ";
        $mysqlQuery .= "WHERE epsc.id_conductor LIKE ? ";
        $mysqlQuery .= "AND epsc.is_visible = 1  ";
        $mysqlQuery .= "ORDER BY epsc.id_eps_conductor DESC ;";
 
        // var_dump($mysqlQuery);

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(
                                "id" => htmlspecialchars($row['id_eps_conductor']),
                                "nombre" => htmlspecialchars($row['nombre_eps']),
                                "fecha_afiliacion" => htmlspecialchars($row['fecha_afiliacion_eps']),
                                "estado" => array(
                                    'id' => htmlspecialchars($row['id_estado_eps']),
                                    'nombre' => htmlspecialchars($row['nombre_estado_eps']),
                                ),
                                "fecha" => htmlspecialchars($row['fecha_formulario']),
                                "foto" => htmlspecialchars($row['foto_eps_conductor']),
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'].' '.$row['apellido_usuario']),
                                )
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'eps' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'eps' => $_default_eps,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}
