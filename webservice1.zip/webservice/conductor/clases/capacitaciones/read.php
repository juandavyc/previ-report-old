<?php
class ReadCapacitacion
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getCapacitacion(
        $_id_conductor
    ) {

        $_default_capacitaciones = array(
            'status' => 'SIN CAPACITACIONES'
        );

        $mysqlArray = array();

        $mysql_query = "SELECT ";
        $mysql_query .= "veh.id_vehiculo,con.id_conductor, encap.nombre_entidad_capacitacion, ticap.nombre_tipo_capacitacion, cap.nombre_capacitacion, cap.duracion_capacitacion,cap.fecha_realizacion_capacitacion, cap.fecha_refuerzo_capacitacion, encap.id_entidad_capacitacion, ticap.id_tipo_capacitacion, cap.refuerzo_si_no, ";
        $mysql_query .= "usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario, cap.foto_capacitacion ";
        $mysql_query .= "FROM capacitacion cap ";
        $mysql_query .= "LEFT JOIN conductor con ON cap.id_conductor = con.id_conductor ";
        $mysql_query .= "LEFT JOIN entidad_capacitacion encap ON cap.id_entidad_capacitacion = encap.id_entidad_capacitacion ";
        $mysql_query .= "LEFT JOIN tipo_capacitacion ticap ON cap.id_tipo_capacitacion = ticap.id_tipo_capacitacion ";
        $mysql_query .= "LEFT JOIN vehiculo_conductor vehco ON con.id_conductor = vehco.id_conductor ";
        $mysql_query .= "LEFT JOIN usuario usu ON usu.id_usuario = cap.id_usuario ";
        $mysql_query .= "LEFT JOIN vehiculo veh ON vehco.id_vehiculo = veh.id_vehiculo ";
        $mysql_query .= "WHERE cap.id_conductor LIKE ? ; ";

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysql_query);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(
                                'entidad' => array(
                                    'id' =>  htmlspecialchars($row['id_entidad_capacitacion']),
                                    'nombre' =>  htmlspecialchars($row['nombre_entidad_capacitacion']),
                                ),
                                'nombre' =>  htmlspecialchars($row['nombre_capacitacion']),
                                'tipo' => array(
                                    'id' =>  htmlspecialchars($row['id_tipo_capacitacion']),
                                    'nombre' =>  htmlspecialchars($row['nombre_tipo_capacitacion']),
                                ),
                                'duracion' =>  htmlspecialchars($row['duracion_capacitacion']),
                                'fecha_realizacion' =>  htmlspecialchars($row['fecha_realizacion_capacitacion']),
                                'fecha_refuerzo' =>  htmlspecialchars($row['fecha_refuerzo_capacitacion']),
                                'refuerzo' =>  htmlspecialchars($row['refuerzo_si_no']),
                                'foto' =>  htmlspecialchars($row['foto_capacitacion']),
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'].' '.$row['apellido_usuario']),
                                )
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'capacitaciones' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'capacitaciones' => $_default_capacitaciones,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}
