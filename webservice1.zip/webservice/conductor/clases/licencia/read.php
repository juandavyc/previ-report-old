<?php
class ReadLicencia
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getLicencia(
$_id_conductor
    ) {

        $_default_licencia = array(
            'status' => 'SIN INCAPACIDADES'
        );

        $mysqlArray = array();

        $mysql_query = "SELECT ";
        $mysql_query .= "licc.numero_licencia_conduccion, licc.fecha_expedicion_licencia_conduccion, licc.fecha_vencimiento_licencia_conduccion, ";
        $mysql_query .= "licc.restricciones_del_conductor, licc.foto_delantera_licencia_conduccion, licc.foto_trasera_licencia_conduccion, ";
        $mysql_query .= "usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario, ";
        $mysql_query .= "catlic1.id_categoria_licencia_conduccion AS cat1,catlic1.nombre_categoria_licencia_conduccion AS nombre1, ";
        $mysql_query .= "catlic2.id_categoria_licencia_conduccion AS cat2,catlic2.nombre_categoria_licencia_conduccion AS nombre2, ";
        $mysql_query .= "catlic3.id_categoria_licencia_conduccion AS cat3,catlic3.nombre_categoria_licencia_conduccion AS nombre3, ";
        $mysql_query .= "catlic4.id_categoria_licencia_conduccion AS cat4,catlic4.nombre_categoria_licencia_conduccion AS nombre4, ";
        $mysql_query .= "estlic.id_estado_licencia, estlic.nombre_estado_licencia ";
        $mysql_query .= "FROM licencia_conduccion licc ";
        $mysql_query .= "LEFT JOIN usuario usu ON usu.id_usuario = licc.id_usuario ";
        $mysql_query .= "LEFT JOIN categoria_licencia_conduccion catlic1 ON catlic1.id_categoria_licencia_conduccion = licc.id_categoria_1 ";
        $mysql_query .= "LEFT JOIN categoria_licencia_conduccion catlic2 ON catlic2.id_categoria_licencia_conduccion = licc.id_categoria_2 ";
        $mysql_query .= "LEFT JOIN categoria_licencia_conduccion catlic3 ON catlic3.id_categoria_licencia_conduccion = licc.id_categoria_3 ";
        $mysql_query .= "LEFT JOIN categoria_licencia_conduccion catlic4 ON catlic4.id_categoria_licencia_conduccion = licc.id_categoria_4 ";
        $mysql_query .= "LEFT JOIN estado_licencia estlic ON estlic.id_estado_licencia = licc.id_estado_licencia ";
        $mysql_query .= "where licc.id_conductor LIKE ? ;";
        
     
        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysql_query);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(  
                                'numero_licencia' => htmlspecialchars($row['numero_licencia_conduccion']),
                                'fecha_expedicion' => htmlspecialchars($row['fecha_expedicion_licencia_conduccion']),
                                'fecha_vencimiento' => htmlspecialchars($row['fecha_vencimiento_licencia_conduccion']),
                                'restricciones' => htmlspecialchars($row['restricciones_del_conductor']),
                                'foto_delantera' => htmlspecialchars($row['foto_delantera_licencia_conduccion']),
                                'foto_trasera' => htmlspecialchars($row['foto_trasera_licencia_conduccion']),
                                'categorias' => array(
                                    'categoria_1' => array(
                                        'id' => htmlspecialchars($row['cat1']),
                                        'nombre' => htmlspecialchars($row['nombre1']),
                                    ),
                                    'categoria_2' => array(
                                        'id' => htmlspecialchars($row['cat2']),
                                        'nombre' => htmlspecialchars($row['nombre2']),
                                    ),
                                    'categoria_3' => array(
                                        'id' => htmlspecialchars($row['cat3']),
                                        'nombre' => htmlspecialchars($row['nombre3']),
                                    ),
                                    'categoria_4' => array(
                                        'id' => htmlspecialchars($row['cat4']),
                                        'nombre' => htmlspecialchars($row['nombre4']),
                                    ),
                                ),
                                'estado' => array(
                                    'id' => htmlspecialchars($row['id_estado_licencia']),
                                    'nombre' => htmlspecialchars($row['nombre_estado_licencia']),
                                ),
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'].' '.$row['apellido_usuario']),
                                )
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'licencia' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'licencia' => $_default_licencia,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}


/*  
*/