<?php
class ReadIncapacidad
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getIncapacidad(
$_id_conductor
    ) {

                  
        $_default_incapacidad = array(
            'status' => 'SIN INCAPACIDADES'
        );

        $mysqlArray = array();

        $mysql_query = "SELECT ";
        $mysql_query .= "veh.id_vehiculo,con.id_conductor, inco.numero_dias_incapacidad_conductor, eps.id_eps, eps.nombre_eps, arl.id_arl, arl.nombre_arl, inco.concepto_incapacidad_conductor, inco.numero_dias_incapacidad_conductor,inco.foto_incapacidad_conductor, ";
        $mysql_query .= "usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";
        $mysql_query .= "FROM incapacidad_conductor inco ";
        $mysql_query .= "LEFT JOIN conductor con ON inco.id_conductor = con.id_conductor ";
        $mysql_query .= "LEFT JOIN eps eps ON inco.id_eps = eps.id_eps ";
        $mysql_query .= "LEFT JOIN arl arl ON inco.id_arl = arl.id_arl ";
        $mysql_query .= "LEFT JOIN vehiculo_conductor vehco ON con.id_conductor = vehco.id_conductor ";
        $mysql_query .= "LEFT JOIN vehiculo veh ON vehco.id_vehiculo = veh.id_vehiculo ";
        $mysql_query .= "LEFT JOIN usuario usu ON usu.id_usuario = inco.id_usuario ";
        $mysql_query .= "WHERE inco.id_conductor LIKE ? ".";";
        
     
        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysql_query);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(  
                                'dias' => htmlspecialchars($row['numero_dias_incapacidad_conductor']),
                                'concepto' => htmlspecialchars($row['concepto_incapacidad_conductor']),
                                'eps' => array (
                                    'id' => htmlspecialchars($row['id_eps']),
                                    'nombre' => htmlspecialchars($row['nombre_eps']),
                                ), 
                                'arl' => array(
                                    'id' => htmlspecialchars($row['id_arl']),
                                    'nombre' => htmlspecialchars($row['nombre_arl']),

                                ),
                                'foto' => htmlspecialchars($row['foto_incapacidad_conductor']),
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'].' '.$row['apellido_usuario']),
                                )
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'incapacidad' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'incapacidad' => $_default_incapacidad,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}


/*  
*/