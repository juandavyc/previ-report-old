<?php
class ReadVehiculoAsignado
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getVehiculoAsignado(
        $_id_conductor
    ) {

        $_default_vehiculo_asignado = array(
            'status' => 'SIN VEHICULOS ASIGNADOS',
        );

        $mysqlArray = array();
        $mysql_query = "SELECT ";
        $mysql_query .= "veh.id_vehiculo,veh.id_vehiculo, con.id_conductor,con.nombre_conductor, veh.placa_vehiculo, veh.numero_vehiculo_interno, vehco.fecha_asignacion, ";
        $mysql_query .= "usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";
        $mysql_query .= "FROM vehiculo_conductor vehco ";
        $mysql_query .= "LEFT JOIN conductor con ON vehco.id_conductor = con.id_conductor ";
        $mysql_query .= "LEFT JOIN vehiculo veh ON vehco.id_vehiculo = veh.id_vehiculo ";
        $mysql_query .= "LEFT JOIN usuario usu ON usu.id_usuario = vehco.id_usuario ";
        $mysql_query .= "WHERE vehco.id_conductor LIKE ? ";
        $mysql_query .= "AND vehco.is_visible = 1 ";
        $mysql_query .= "ORDER BY vehco.id_vehiculo_conductor DESC LIMIT 0,1;";

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysql_query);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(
                                'vehiculo' => array(
                                    'id' => htmlspecialchars($row['id_vehiculo']),
                                    'placa' => htmlspecialchars($row['placa_vehiculo']),
                                ),
                                'conductor' => array(
                                    'id' => htmlspecialchars($row['id_conductor']),
                                    'nombre' => htmlspecialchars($row['nombre_conductor']),
                                ),
                                'numero' => $row['numero_vehiculo_interno'],
                                'fecha' => $row['fecha_asignacion'],
                                'responsable' => array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'] . ' ' . $row['apellido_usuario']),
                                ),
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'vehiculo_asignado' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'vehiculo_asignado' => $_default_vehiculo_asignado,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}

/*
 */