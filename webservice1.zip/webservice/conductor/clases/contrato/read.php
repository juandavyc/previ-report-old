<?php
class ReadContrato
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0; 

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getContrato(
       $_id_conductor
    ) {

        $_default_contrato = array(
            'status' => 'SIN CONTRATOS'
        );

        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        $mysqlQuery .= "cec.id_contrato_empresa_conductor,cec.fecha_ingreso_empresa_conductor, cec.tiempo_en_empresa_conductor, tcon.id_tipo_contrato, tcon.nombre_tipo_contrato, ";
        $mysqlQuery .= "cec.fecha_vencimiento_contrato_empresa_conductor, usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario,emp.id_empresa, emp.nombre_empresa ";
        $mysqlQuery .= "FROM contrato_empresa_conductor cec  ";
        $mysqlQuery .= "LEFT JOIN usuario usu ON usu.id_usuario = cec.id_usuario ";
        $mysqlQuery .= "LEFT JOIN tipo_contrato tcon ON tcon.id_tipo_contrato = cec.id_tipo_contrato ";
        $mysqlQuery .= "LEFT JOIN empresa emp ON emp.id_empresa = cec.id_empresa ";
        $mysqlQuery .= "WHERE id_conductor LIKE ? ";
        $mysqlQuery .= "AND is_visible = 1  ";
        $mysqlQuery .= "ORDER BY cec.id_contrato_empresa_conductor DESC ;";

        // var_dump($mysqlQuery);

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(
                                "id" => htmlspecialchars($row['id_contrato_empresa_conductor']),
                                "fecha_ingreso" => htmlspecialchars($row['fecha_ingreso_empresa_conductor']),
                                "tiempo" => htmlspecialchars($row['tiempo_en_empresa_conductor']),
                                "tipo_contrato" => array(
                                    'id' => htmlspecialchars($row['id_tipo_contrato']),
                                    'nombre' => htmlspecialchars($row['nombre_tipo_contrato']),
                                ),
                                "fecha_vencimiento" => htmlspecialchars($row['fecha_vencimiento_contrato_empresa_conductor']),
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'].' '.$row['apellido_usuario']),
                                ),
                                'empresa' =>  array(
                                    'id' => htmlspecialchars($row['id_empresa']),
                                    'nombre' => htmlspecialchars($row['nombre_empresa']),
                                ),
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'contrato' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'contrato' => $_default_contrato,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}