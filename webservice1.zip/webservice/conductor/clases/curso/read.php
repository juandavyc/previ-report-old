<?php
class ReadCurso
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0; 

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getCurso(
       $_id_conductor
    ) {

        $_default_contrato = array(
            'status' => 'SIN CURSOS'
        );

        $mysqlArray = array();


        $mysql_query = "SELECT ";
        $mysql_query .= "veh.id_vehiculo, con.id_conductor, encur.nombre_entidad_curso, encur.id_entidad_curso, cur.nombre_curso, cur.logro_obtenido, cur.fecha_realizacion_curso, cur.fecha_expiracion_curso, ";
        $mysql_query .= "cur.foto_curso, usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";
        $mysql_query .= "FROM curso cur ";
        $mysql_query .= "LEFT JOIN conductor con ON cur.id_conductor = con.id_conductor  ";
        $mysql_query .= "LEFT JOIN entidad_curso encur ON cur.id_entidad_curso = encur.id_entidad_curso ";
        $mysql_query .= "LEFT JOIN vehiculo_conductor vehco ON con.id_conductor = vehco.id_conductor ";
        $mysql_query .= "LEFT JOIN vehiculo veh ON vehco.id_vehiculo = veh.id_vehiculo ";
        $mysql_query .= "LEFT JOIN usuario usu ON usu.id_usuario = cur.id_usuario ";
        $mysql_query .= "WHERE cur.id_conductor LIKE ? ;";
        
        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysql_query);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(
                                'entidad' => array(
                                    'id' => htmlspecialchars($row['id_entidad_curso']),
                                    'nombre' => htmlspecialchars($row['nombre_entidad_curso']),
                                ),
                                'nombre_curso' => $row['nombre_curso'],
                                'logro' => $row['logro_obtenido'],     
                                'fecha_realizacion' => $row['fecha_realizacion_curso'], 
                                'fecha_expiracion' => $row['fecha_expiracion_curso'],  
                                'foto' => htmlspecialchars($row['foto_curso']), 
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'].' '.$row['apellido_usuario']),
                                )
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'curso' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'curso' => $_default_contrato,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}

/* 'entidad' => $row['nombre_entidad_curso'],
                    'nombre_curso' => $row['nombre_curso'],
                    'logro' => $row['logro_obtenido'],     
                    'expedicion' => $row['fecha_realizacion_curso'], 
                    'vencimiento' => $row['fecha_expiracion_curso'],  
                    */