<?php
class ReadFondoDePension
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getFondoDePension(
$_id_conductor
    ) {

          
        $_default_fondo = array(
            'status' => 'SIN FONDOS DE PENSION'
        );

        $mysqlArray = array();

        $mysqlQuery = "SELECT ";
        $mysqlQuery .= "fdpc.id_fondo_pension_conductor, fdpc.fecha_afiliacion_fondo_pension, fdpc.foto_fondo_pension_conductor,  ";
        $mysqlQuery .= "fdp.id_fondo_pension, fdp.nombre_fondo_pension, efdp.id_estado_fondo_pension, efdp.nombre_estado_fondo_pension, ";
        $mysqlQuery .= "usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";
        $mysqlQuery .= "FROM fondo_pension_conductor fdpc  ";
        $mysqlQuery .= "LEFT JOIN fondo_pension fdp ON fdpc.id_fondo_pension = fdp.id_fondo_pension ";
        $mysqlQuery .= "LEFT JOIN estado_fondo_pension efdp ON efdp.id_estado_fondo_pension = fdpc.id_estado_fondo_pension ";
        $mysqlQuery .= "LEFT JOIN usuario usu ON usu.id_usuario = fdpc.id_usuario  ";
        $mysqlQuery .= "WHERE fdpc.id_conductor LIKE ? ";
        $mysqlQuery .= "AND fdpc.is_visible = 1  ";
        $mysqlQuery .= "ORDER BY fdpc.id_fondo_pension_conductor DESC ;";
 
        // var_dump($mysqlQuery);

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(  
                                "id" => htmlspecialchars($row['id_fondo_pension_conductor']),
                                "nombre" => htmlspecialchars($row['nombre_fondo_pension']),
                                "fecha_afiliacion" => htmlspecialchars($row['fecha_afiliacion_fondo_pension']),
                                "estado" => array(
                                  'id' => htmlspecialchars($row['id_estado_fondo_pension']),
                                  'nombre' => htmlspecialchars($row['nombre_estado_fondo_pension']),
                                ),
                                "foto" => htmlspecialchars($row['foto_fondo_pension_conductor']),
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'].' '.$row['apellido_usuario']),
                                ),
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'fondo_de_pension' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'fondo_de_pension' => $_default_fondo,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}
