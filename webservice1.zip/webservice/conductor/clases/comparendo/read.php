




<?php
class ReadComparendo
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    private $arrayContador = 0;

    public function __construct($_database)
    {
        $this->databaseConnection = $_database;
    }
    public function getComparendo(
        $_id_conductor
    ) {

        $_default_comparendo = array(
            'status' => 'SIN COMPARENDOS'
        );

        $mysqlArray = array();

        $mysql_query = "SELECT ";
        $mysql_query .= "veh.id_vehiculo, comco.fecha_comparendo_conductor, ticomco.nombre_tipo_comparendo_conductor, con.id_conductor, comco.motivo_comparendo_conductor, ";
        $mysql_query .= "ticomco.id_tipo_comparendo_conductor,usu.id_usuario, usu.nombre_usuario, usu.apellido_usuario ";

        $mysql_query .= "FROM comparendo_conductor comco ";

        $mysql_query .= "LEFT JOIN tipo_comparendo_conductor ticomco ON comco.id_tipo_comparendo_conductor = ticomco.id_tipo_comparendo_conductor ";
        $mysql_query .= "LEFT JOIN conductor con ON comco.id_conductor = con.id_conductor ";
        $mysql_query .= "LEFT JOIN vehiculo_conductor vehco ON con.id_conductor = vehco.id_conductor ";
        $mysql_query .= "LEFT JOIN vehiculo veh ON vehco.id_vehiculo = veh.id_vehiculo ";
        $mysql_query .= "LEFT JOIN usuario usu ON comco.id_usuario = usu.id_usuario ";
        $mysql_query .= "WHERE comco.id_conductor LIKE ? ; ";

        

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysql_query);
        $mysqlStmt->bind_param('s', $_id_conductor);
        if ($mysqlStmt->execute()) {
            if ($mysqlStmt->execute()) {
                $mysqlResult = $mysqlStmt->get_result();
                if (intval($mysqlResult->num_rows) > 0) {
                    while ($row = $mysqlResult->fetch_assoc()) {
                        array_push(
                            $mysqlArray,
                            array(
                                'tipo' => array(
                                    'id' => htmlspecialchars($row['id_tipo_comparendo_conductor']),
                                    'nombre' => htmlspecialchars($row['nombre_tipo_comparendo_conductor']),
                            ),
                                'fecha' => $row['fecha_comparendo_conductor'],
                                'motivo' => $row['motivo_comparendo_conductor'],
                                'responsable' =>  array(
                                    'id' => htmlspecialchars($row['id_usuario']),
                                    'nombre' => htmlspecialchars($row['nombre_usuario'].' '.$row['apellido_usuario']),
                                )
                            )
                        );
                    }

                    $this->arrayResponse = array(
                        'status' => 'bien',
                        'message' => 'Resultados encontrados',
                        'comparendos' => $mysqlArray,
                    );
                } else {
                    $this->arrayResponse = array(
                        'status' => 'sin_resultados',
                        'message' => 'La búsqueda no arrojo ningún resultado, por favor inténtelo de nuevo más tarde',
                        'comparendos' => $_default_comparendo,
                    );
                }
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}








