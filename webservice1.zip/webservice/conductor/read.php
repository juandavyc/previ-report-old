<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

if (strcmp($methodRequest, 'GET') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );
    # los obligatorios

    if (COUNT($_GET) >= 3 &&
        isset($_GET['acct']) &&
        isset($_GET['conductor']) &&
        isset($_GET['type'])) {

        require '../auth_database.php';
        require '../auth_user.php';

        # usuario esta autorizado
        $_user = htmlspecialchars($_GET['acct']);

        $database = new dbconnection();
        $database->connect();
        if (strcmp($database->status(), "bien") == 0) {

            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            if (strcmp($responseAcct['status'], 'bien') == 0) {

                $_type = strtoupper(htmlspecialchars($_GET['type']));
                $_get_conductor = htmlspecialchars($_GET['conductor']);

                $_get_empresa = htmlspecialchars(isset($_GET['empresa']) ? $_GET['empresa'] : '%%');

                require DOCUMENT_ROOT . '/webservice/conductor/clases/conductor/read.php';

                // var_dump($condicionBusqueda);

                $conductor = new ReadConductor($database->myconn);
                $arrayConductor = $conductor->getConductor(
                    array(
                        'TYPE' => $_type,
                        'VALUE' => $_get_conductor,
                    ),
                    '0,1000',
                    $_get_empresa
                );

                # CONDUCTOR ENCONTRADO
                if (strcmp($arrayConductor['status'], 'bien' == 0)) {
                    //$_array_response();
                    $_array_response = array(
                        'status' => $arrayConductor['status'],
                        'message' => $arrayConductor['message'],
                        'conductor' => $arrayConductor['conductor'],
                    );
                    // ID vehiculo
                    /* $_ID_CONDUCTOR = $arrayConductor['conductor']['0']['id'];

                // ARL
                require DOCUMENT_ROOT . '/webservice/conductor/clases/capacitaciones/read.php';
                $_array_response['capacitaciones'] = array();
                $capacitaciones = new ReadCapacitacion($database->myconn);
                $arrayCapacitaciones = $capacitaciones->getCapacitacion(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayCapacitaciones['status'], 'bien' == 0)) {
                $_array_response['capacitaciones'] = $arrayCapacitaciones['capacitaciones'];
                }

                // CAPACITACIONES
                require DOCUMENT_ROOT . '/webservice/conductor/clases/arl/read.php';
                $_array_response['arl'] = array();
                $arl = new ReadArl($database->myconn);
                $arrayArl = $arl->getArl(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayArl['status'], 'bien' == 0)) {
                $_array_response['arl'] = $arrayArl['arl'];
                }

                // COMPARENDOS
                require DOCUMENT_ROOT . '/webservice/conductor/clases/comparendo/read.php';
                $_array_response['comparendos'] = array();
                $comparendos = new ReadComparendo($database->myconn);
                $arrayComparendos = $comparendos->getComparendo(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayComparendos['status'], 'bien' == 0)) {
                $_array_response['comparendos'] = $arrayComparendos['comparendos'];
                }

                // CONTACTO DE EMERGENCIA
                require DOCUMENT_ROOT . '/webservice/conductor/clases/contacto/read.php';
                $_array_response['contacto'] = array();
                $contacto = new ReadContactoEmergencia($database->myconn);
                $arrayContacto = $contacto->getContacto(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayContacto['status'], 'bien' == 0)) {
                $_array_response['contacto'] = $arrayContacto['contacto'];
                }

                // CONTRATO
                require DOCUMENT_ROOT . '/webservice/conductor/clases/contrato/read.php';
                $_array_response['contrato'] = array();
                $contrato = new ReadContrato($database->myconn);
                $arrayContrato = $contrato->getContrato(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayContrato['status'], 'bien' == 0)) {
                $_array_response['contrato'] = $arrayContrato['contrato'];
                }

                // CURSO
                require DOCUMENT_ROOT . '/webservice/conductor/clases/curso/read.php';
                $_array_response['curso'] = array();
                $curso = new ReadCurso($database->myconn);
                $arrayCurso = $curso->getCurso(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayCurso['status'], 'bien' == 0)) {
                $_array_response['curso'] = $arrayCurso['curso'];
                }
                // EPS
                require DOCUMENT_ROOT . '/webservice/conductor/clases/eps/read.php';
                $_array_response['eps'] = array();
                $eps = new ReadEps($database->myconn);
                $arrayEps = $eps->getEps(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayEps['status'], 'bien' == 0)) {
                $_array_response['eps'] = $arrayEps['eps'];
                }

                // EXAMENES
                require DOCUMENT_ROOT . '/webservice/conductor/clases/examenes/read.php';
                $_array_response['examenes'] = array();
                $examenes = new ReadExamen($database->myconn);
                $arrayExamenes = $examenes->getExamen(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayExamenes['status'], 'bien' == 0)) {
                $_array_response['examenes'] = $arrayExamenes['examenes'];
                }

                // FONDO DE PENSION
                require DOCUMENT_ROOT . '/webservice/conductor/clases/fondo_de_pension/read.php';
                $_array_response['fondo_de_pension'] = array();
                $fondo = new ReadFondoDePension($database->myconn);
                $arrayFondo = $fondo->getFondoDePension(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayFondo['status'], 'bien' == 0)) {
                $_array_response['fondo_de_pension'] = $arrayFondo['fondo_de_pension'];
                }

                // INCAPACIDADES
                require DOCUMENT_ROOT . '/webservice/conductor/clases/incapacidad/read.php';
                $_array_response['incapacidad'] = array();
                $incapacidad = new ReadIncapacidad($database->myconn);
                $arrayIncapacidad = $incapacidad->getIncapacidad(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayFondo['status'], 'bien' == 0)) {
                $_array_response['incapacidad'] = $arrayIncapacidad['incapacidad'];
                }

                // LICENCIA DE CONDUCCION
                require DOCUMENT_ROOT . '/webservice/conductor/clases/licencia/read.php';
                $_array_response['licencia'] = array();
                $licencia = new ReadLicencia($database->myconn);
                $arrayLicencia = $licencia->getLicencia(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayFondo['status'], 'bien' == 0)) {
                $_array_response['licencia'] = $arrayLicencia['licencia'];
                }

                // VEHICULO ASIGNADO
                require DOCUMENT_ROOT . '/webservice/conductor/clases/vehiculo_asignado/read.php';
                $_array_response['vehiculo_asignado'] = array();
                $vehiculo_asignado = new ReadVehiculoAsignado($database->myconn);
                $arrayVehiculoAsignado = $vehiculo_asignado->getVehiculoAsignado(
                $_ID_CONDUCTOR
                );
                if (strcmp($arrayVehiculoAsignado['status'], 'bien' == 0)) {
                $_array_response['vehiculo_asignado'] = $arrayVehiculoAsignado['vehiculo_asignado'];
                }*/

                }
                # vehiculo NO ENCONTRADO
                else {
                    $_array_response = array(
                        'status' => $arrayVehiculo['status'],
                        'message' => $arrayVehiculo['message'],
                    );
                }
            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

            $database->close();
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}