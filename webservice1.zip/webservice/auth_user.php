<?php
class AccountVerify
# author : juan david yara cifuentes 
# no me pagan lo suficiente para comentar el codigo
{
    private $databaseConnection = null;
    private $arrayResponse = array();
    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }


    public function isAuthorized($_user_)
    {


        $this->arrayResponse = array(
            'status' => 'error',
            'message' => 'usuario no autorizado',
        );

        $mysqlQuery = "SELECT ";
        $mysqlQuery .= "id_usuario_asignado ";
        $mysqlQuery .= "FROM ";
        $mysqlQuery .= "web_service ";
        $mysqlQuery .= "WHERE ";
        $mysqlQuery .= "usuario_web_service = ? ";
        $mysqlQuery .= "ORDER BY ";
        $mysqlQuery .= "id_web_service DESC ";
        $mysqlQuery .= "LIMIT 0,1;";


        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('s', $_user_);

        if ($mysqlStmt->execute()) {

            $mysqlResult = $mysqlStmt->get_result();
            $mysqlRowCount = mysqli_num_rows($mysqlResult);

            if ($mysqlRowCount > 0) {
                $temp_row = (mysqli_fetch_all($mysqlResult, MYSQLI_ASSOC));
                $this->arrayResponse = array(
                    'status' => 'bien',
                    'message' => 'Usuario autorizado',
                    'id_user' => ($temp_row[0]['id_usuario_asignado'])
                );

                $mysqlStmt->close();
            } else {

                $this->arrayResponse = array(
                    'status' => 'error',
                    'message' => 'usuario no autorizado',
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta: ' . htmlspecialchars($mysqlStmt->error),
            );
        }

        return $this->arrayResponse;
    }
}