<?php

class UsuarioInicioSesion {

    private $databaseConnection = null;
    private $arrayResponse = array();

    public function __construct($_database_)
    {
        $this->databaseConnection = $_database_;
    }

    public function verifyUsuario(
        $_empresa='',$_usuario='',$_contrasenia='' 
    ) {
        $mysqlQuery = "CALL proc_iniciar_sesion_webservice (?,?,?, @respuesta);";

        $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
        $mysqlStmt->bind_param('iss',$_empresa, $_usuario, $_contrasenia);
        

        if ($mysqlStmt->execute()) {
            $mysqlStmt->close();
            $mysqlQuery = "SELECT @respuesta As JSON_PROC; ";
            $mysqlStmt = mysqli_prepare($this->databaseConnection, $mysqlQuery);
            if ($mysqlStmt->execute()) {

                $mysqlResult = $mysqlStmt->get_result();
                $row = $mysqlResult->fetch_assoc();
                $mysqlDecode = json_decode($row['JSON_PROC']);
                
                $mysqlStmt->close();

                if(strcmp($mysqlDecode[0], "bien") == 0){

                    $this->arrayResponse = array(
                        'status' => $mysqlDecode[0],
                        'message' => $mysqlDecode[1],
                        'usuario' => array(
                            'status' => 'EXISTENTE',
                            'id_usuario' => $mysqlDecode[2],
                            'cedula' => $mysqlDecode[3],
                            'nombre' => $mysqlDecode[4],
                            'apellido' => $mysqlDecode[5],
                            'correo' => $mysqlDecode[6],
                            'telefono' => $mysqlDecode[7],
                            'firma' => $mysqlDecode[8],
                            'fecha_nacimiento' => $mysqlDecode[9],
                            'id_taller' => $mysqlDecode[10],
                            'fecha_contrasenia' => $mysqlDecode[11],
                            'id_estado' => $mysqlDecode[12],
                            'id_rango' => $mysqlDecode[13],
                            'id_empresa' => $mysqlDecode[14],
                                                              ),

                    );
                } else 
                {
                    $this->arrayResponse = array(
                        'status' => $mysqlDecode[0],
                        'message' => $mysqlDecode[1],
                    );

                }

                // $this->arrayResponse = array(s
                //     'status' => $mysqlDecode[0],
                //     'message' => $mysqlDecode[1],
                //     'id' => isset($mysqlDecode[2]) ? $mysqlDecode[2] : '',
                // );
            } else {
                $this->arrayResponse = array(
                    'status' => 'error',
                    'message' => 'Error en la consulta #2 : ' . htmlspecialchars($mysqlStmt->error),
                );
            }
        } else {
            $this->arrayResponse = array(
                'status' => 'error',
                'message' => 'Error en la consulta #1 : ' . htmlspecialchars($mysqlStmt->error),
            );
        }
        return $this->arrayResponse;
    }

}