<?php
header("Content-Type: application/json; charset=UTF-8");
/*header("Access-Control-Allow-Origin: *");
//
// header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 */

require $_SERVER["DOCUMENT_ROOT"] . '/hoja_config.php';
$methodRequest = $_SERVER['REQUEST_METHOD'];

// CONFIRMA SI EL TIPO DE ENVIO DE DATOS ES GET
if (strcmp($methodRequest, 'GET') == 0) {
    // explode url
    $_array_response = array(
        'status' => 'ERROR',
        'message' => 'SIN_INICIAR',
    );
    # los obligatorios

    // VERIFICA LOS PARAMETROS
    if (
        COUNT($_GET) > 1 &&
        isset($_GET['acct']) &&
        isset($_GET['usuario']) &&
        isset($_GET['empresa']) &&
        isset($_GET['contrasenia'])
    ) {
        //db
        require '../auth_database.php';
        require '../auth_user.php';

        # usuario esta autorizado
        $_user = htmlspecialchars($_GET['acct']);

        $database = new dbconnection();
        $database->connect();

        // db connection
        if (strcmp($database->status(), "bien") == 0) {

            //user verify
            $AccountVerify = new AccountVerify($database->myconn);
            $responseAcct = $AccountVerify->isAuthorized($_user);

            // si existe el usuario
            if (strcmp($responseAcct['status'], 'bien') == 0) {
                // TYPE en la url (NOMBRE Ó NIT)
                $_empresa = htmlspecialchars($_GET['empresa']); 
                $_usuario = htmlspecialchars($_GET['usuario']);
                $_contrasenia = htmlspecialchars($_GET['contrasenia']);

                    require DOCUMENT_ROOT . '/webservice/inicio_sesion/clases/inicio_sesion.php';
                    $Response = new UsuarioInicioSesion($database->myconn);
                    $arrayInicioSesion = $Response->verifyUsuario(
                      
                            $_empresa,
                             $_usuario,
                            $_contrasenia,
                     
                    );
                    // var_dump($arrayInicioSesion);

                    $_array_response = array(
                        'status' => $arrayInicioSesion['status'],
                        'message' => $arrayInicioSesion['message'],
                        'usuario' => $arrayInicioSesion['status'] == 'bien' ? $arrayInicioSesion['usuario'] : array('status' => 'NO EXISTENTE'),
                    );

                //NO EXISTE EL USUARIO
            } else {
                $_array_response = array(
                    'status' => $responseAcct['status'],
                    'message' => $responseAcct['message'],
                );
            }

            $database->close();

            // BASE DE DATOS
        } else {
            $_array_response = array(
                'status' => 'DATABASE',
                'message' => 'IMPOSIBLE CONECTAR A LA BASE DE DATOSS',
            );
        }
        //  ERROR DE PETICION GET
    } else {
        $_array_response = array(
            'status' => 'URL',
            'message' => 'LA PETICION NO CUMPLE LOS REQUISITOS',
        );
    }

    echo json_encode($_array_response, JSON_FORCE_OBJECT);
    exit;
} else {
    echo json_encode(array(
        'status' => "REQUEST_METHOD",
        'message' => "REQUEST_METHOD NO VALIDO",
    ), JSON_FORCE_OBJECT);
    exit;
}